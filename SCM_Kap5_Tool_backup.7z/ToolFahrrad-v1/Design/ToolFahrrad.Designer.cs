﻿namespace ToolFahrrad_v1.Design
{
    partial class Fahrrad
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Fahrrad));
            this.tabs = new System.Windows.Forms.TabControl();
            this.tab_xml = new System.Windows.Forms.TabPage();
            this.prognose1 = new System.Windows.Forms.Label();
            this.pufferP3 = new System.Windows.Forms.NumericUpDown();
            this.pufferP2 = new System.Windows.Forms.NumericUpDown();
            this.pufferP1 = new System.Windows.Forms.NumericUpDown();
            this.label1 = new System.Windows.Forms.Label();
            this.panelXML = new System.Windows.Forms.Panel();
            this.save = new System.Windows.Forms.PictureBox();
            this.xmlOffenOK = new System.Windows.Forms.PictureBox();
            this.toolAusfueren = new System.Windows.Forms.PictureBox();
            this.xmlTextBox = new System.Windows.Forms.TextBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.titleXmlLaden = new System.Windows.Forms.Label();
            this.xml_suchen = new System.Windows.Forms.Button();
            this.bildSpeichOk = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.prognoseSpeichern = new System.Windows.Forms.Button();
            this.upDownP33 = new System.Windows.Forms.NumericUpDown();
            this.upDownP23 = new System.Windows.Forms.NumericUpDown();
            this.upDownP13 = new System.Windows.Forms.NumericUpDown();
            this.upDownAW3 = new System.Windows.Forms.NumericUpDown();
            this.upDownP32 = new System.Windows.Forms.NumericUpDown();
            this.upDownP22 = new System.Windows.Forms.NumericUpDown();
            this.upDownP12 = new System.Windows.Forms.NumericUpDown();
            this.upDownAW2 = new System.Windows.Forms.NumericUpDown();
            this.upDownP31 = new System.Windows.Forms.NumericUpDown();
            this.upDownP21 = new System.Windows.Forms.NumericUpDown();
            this.upDownP11 = new System.Windows.Forms.NumericUpDown();
            this.upDownAW1 = new System.Windows.Forms.NumericUpDown();
            this.prognose2 = new System.Windows.Forms.Label();
            this.prognose3 = new System.Windows.Forms.Label();
            this.aktulleWoche = new System.Windows.Forms.Label();
            this.p3 = new System.Windows.Forms.Label();
            this.p2 = new System.Windows.Forms.Label();
            this.p1 = new System.Windows.Forms.Label();
            this.titlePrognose = new System.Windows.Forms.Label();
            this.tab_produktion = new System.Windows.Forms.TabPage();
            this.tab1 = new System.Windows.Forms.TabControl();
            this.tab_P1 = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label91 = new System.Windows.Forms.Label();
            this.label90 = new System.Windows.Forms.Label();
            this.label89 = new System.Windows.Forms.Label();
            this.label88 = new System.Windows.Forms.Label();
            this.label87 = new System.Windows.Forms.Label();
            this.label86 = new System.Windows.Forms.Label();
            this.label74 = new System.Windows.Forms.Label();
            this.label75 = new System.Windows.Forms.Label();
            this.label76 = new System.Windows.Forms.Label();
            this.label77 = new System.Windows.Forms.Label();
            this.label78 = new System.Windows.Forms.Label();
            this.label79 = new System.Windows.Forms.Label();
            this.label80 = new System.Windows.Forms.Label();
            this.label81 = new System.Windows.Forms.Label();
            this.label82 = new System.Windows.Forms.Label();
            this.label83 = new System.Windows.Forms.Label();
            this.label84 = new System.Windows.Forms.Label();
            this.label85 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label72 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.label61 = new System.Windows.Forms.Label();
            this.label62 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.label64 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.label68 = new System.Windows.Forms.Label();
            this.label69 = new System.Windows.Forms.Label();
            this.label70 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.p1plus_18 = new System.Windows.Forms.TextBox();
            this.p1r_18 = new System.Windows.Forms.TextBox();
            this.p1ls_18 = new System.Windows.Forms.TextBox();
            this.p1iws_18 = new System.Windows.Forms.TextBox();
            this.p1ib_18 = new System.Windows.Forms.TextBox();
            this.p1pm_18 = new System.Windows.Forms.TextBox();
            this.p1vw_18 = new System.Windows.Forms.TextBox();
            this.p1plus_7 = new System.Windows.Forms.TextBox();
            this.p1r_7 = new System.Windows.Forms.TextBox();
            this.p1ls_7 = new System.Windows.Forms.TextBox();
            this.p1iws_7 = new System.Windows.Forms.TextBox();
            this.p1ib_7 = new System.Windows.Forms.TextBox();
            this.p1pm_7 = new System.Windows.Forms.TextBox();
            this.p1vw_7 = new System.Windows.Forms.TextBox();
            this.p1plus_13 = new System.Windows.Forms.TextBox();
            this.p1r_13 = new System.Windows.Forms.TextBox();
            this.p1ls_13 = new System.Windows.Forms.TextBox();
            this.p1iws_13 = new System.Windows.Forms.TextBox();
            this.p1ib_13 = new System.Windows.Forms.TextBox();
            this.p1pm_13 = new System.Windows.Forms.TextBox();
            this.p1vw_13 = new System.Windows.Forms.TextBox();
            this.p1plus_49 = new System.Windows.Forms.TextBox();
            this.p1r_49 = new System.Windows.Forms.TextBox();
            this.p1ls_49 = new System.Windows.Forms.TextBox();
            this.p1iws_49 = new System.Windows.Forms.TextBox();
            this.p1ib_49 = new System.Windows.Forms.TextBox();
            this.p1pm_49 = new System.Windows.Forms.TextBox();
            this.p1vw_49 = new System.Windows.Forms.TextBox();
            this.p1plus_4 = new System.Windows.Forms.TextBox();
            this.p1r_4 = new System.Windows.Forms.TextBox();
            this.p1ls_4 = new System.Windows.Forms.TextBox();
            this.p1iws_4 = new System.Windows.Forms.TextBox();
            this.p1ib_4 = new System.Windows.Forms.TextBox();
            this.p1pm_4 = new System.Windows.Forms.TextBox();
            this.p1vw_4 = new System.Windows.Forms.TextBox();
            this.p1plus_10 = new System.Windows.Forms.TextBox();
            this.p1r_10 = new System.Windows.Forms.TextBox();
            this.p1ls_10 = new System.Windows.Forms.TextBox();
            this.p1iws_10 = new System.Windows.Forms.TextBox();
            this.p1ib_10 = new System.Windows.Forms.TextBox();
            this.p1pm_10 = new System.Windows.Forms.TextBox();
            this.p1vw_10 = new System.Windows.Forms.TextBox();
            this.p1plus_50 = new System.Windows.Forms.TextBox();
            this.p1r_50 = new System.Windows.Forms.TextBox();
            this.p1ls_50 = new System.Windows.Forms.TextBox();
            this.p1iws_50 = new System.Windows.Forms.TextBox();
            this.p1ib_50 = new System.Windows.Forms.TextBox();
            this.p1pm_50 = new System.Windows.Forms.TextBox();
            this.p1vw_50 = new System.Windows.Forms.TextBox();
            this.p1plus_16 = new System.Windows.Forms.TextBox();
            this.p1r_16 = new System.Windows.Forms.TextBox();
            this.p1ls_16 = new System.Windows.Forms.TextBox();
            this.p1iws_16 = new System.Windows.Forms.TextBox();
            this.p1ib_16 = new System.Windows.Forms.TextBox();
            this.p1pm_16 = new System.Windows.Forms.TextBox();
            this.p1vw_16 = new System.Windows.Forms.TextBox();
            this.p1plus_17 = new System.Windows.Forms.TextBox();
            this.p1r_17 = new System.Windows.Forms.TextBox();
            this.p1ls_17 = new System.Windows.Forms.TextBox();
            this.p1iws_17 = new System.Windows.Forms.TextBox();
            this.p1ib_17 = new System.Windows.Forms.TextBox();
            this.p1pm_17 = new System.Windows.Forms.TextBox();
            this.p1vw_17 = new System.Windows.Forms.TextBox();
            this.p1plus_26 = new System.Windows.Forms.TextBox();
            this.p1r_26 = new System.Windows.Forms.TextBox();
            this.p1ls_26 = new System.Windows.Forms.TextBox();
            this.p1iws_26 = new System.Windows.Forms.TextBox();
            this.p1ib_26 = new System.Windows.Forms.TextBox();
            this.p1pm_26 = new System.Windows.Forms.TextBox();
            this.p1vw_26 = new System.Windows.Forms.TextBox();
            this.p1plus_51 = new System.Windows.Forms.TextBox();
            this.p1r_51 = new System.Windows.Forms.TextBox();
            this.p1ls_51 = new System.Windows.Forms.TextBox();
            this.p1iws_51 = new System.Windows.Forms.TextBox();
            this.p1ib_51 = new System.Windows.Forms.TextBox();
            this.p1pm_51 = new System.Windows.Forms.TextBox();
            this.p1vw_51 = new System.Windows.Forms.TextBox();
            this.p1r_0 = new System.Windows.Forms.TextBox();
            this.p1ls_0 = new System.Windows.Forms.TextBox();
            this.p1iws_0 = new System.Windows.Forms.TextBox();
            this.p1ib_0 = new System.Windows.Forms.TextBox();
            this.p1pm_0 = new System.Windows.Forms.TextBox();
            this.p1vw_0 = new System.Windows.Forms.TextBox();
            this.p1ETAusfueren = new System.Windows.Forms.PictureBox();
            this.tab_P2 = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.p2ETAusfueren = new System.Windows.Forms.PictureBox();
            this.label92 = new System.Windows.Forms.Label();
            this.label93 = new System.Windows.Forms.Label();
            this.label94 = new System.Windows.Forms.Label();
            this.label95 = new System.Windows.Forms.Label();
            this.label96 = new System.Windows.Forms.Label();
            this.label97 = new System.Windows.Forms.Label();
            this.label98 = new System.Windows.Forms.Label();
            this.label99 = new System.Windows.Forms.Label();
            this.label100 = new System.Windows.Forms.Label();
            this.label101 = new System.Windows.Forms.Label();
            this.label102 = new System.Windows.Forms.Label();
            this.label103 = new System.Windows.Forms.Label();
            this.label104 = new System.Windows.Forms.Label();
            this.label105 = new System.Windows.Forms.Label();
            this.label106 = new System.Windows.Forms.Label();
            this.label107 = new System.Windows.Forms.Label();
            this.label108 = new System.Windows.Forms.Label();
            this.label109 = new System.Windows.Forms.Label();
            this.label110 = new System.Windows.Forms.Label();
            this.label111 = new System.Windows.Forms.Label();
            this.label112 = new System.Windows.Forms.Label();
            this.label113 = new System.Windows.Forms.Label();
            this.label114 = new System.Windows.Forms.Label();
            this.label115 = new System.Windows.Forms.Label();
            this.label116 = new System.Windows.Forms.Label();
            this.label117 = new System.Windows.Forms.Label();
            this.label118 = new System.Windows.Forms.Label();
            this.label119 = new System.Windows.Forms.Label();
            this.label120 = new System.Windows.Forms.Label();
            this.label121 = new System.Windows.Forms.Label();
            this.label122 = new System.Windows.Forms.Label();
            this.label123 = new System.Windows.Forms.Label();
            this.label124 = new System.Windows.Forms.Label();
            this.label125 = new System.Windows.Forms.Label();
            this.label126 = new System.Windows.Forms.Label();
            this.label127 = new System.Windows.Forms.Label();
            this.label128 = new System.Windows.Forms.Label();
            this.label129 = new System.Windows.Forms.Label();
            this.label130 = new System.Windows.Forms.Label();
            this.label131 = new System.Windows.Forms.Label();
            this.label132 = new System.Windows.Forms.Label();
            this.label133 = new System.Windows.Forms.Label();
            this.label134 = new System.Windows.Forms.Label();
            this.label135 = new System.Windows.Forms.Label();
            this.label136 = new System.Windows.Forms.Label();
            this.label137 = new System.Windows.Forms.Label();
            this.label138 = new System.Windows.Forms.Label();
            this.label139 = new System.Windows.Forms.Label();
            this.label140 = new System.Windows.Forms.Label();
            this.label141 = new System.Windows.Forms.Label();
            this.label142 = new System.Windows.Forms.Label();
            this.label143 = new System.Windows.Forms.Label();
            this.label144 = new System.Windows.Forms.Label();
            this.label145 = new System.Windows.Forms.Label();
            this.label146 = new System.Windows.Forms.Label();
            this.label147 = new System.Windows.Forms.Label();
            this.label148 = new System.Windows.Forms.Label();
            this.label149 = new System.Windows.Forms.Label();
            this.label150 = new System.Windows.Forms.Label();
            this.label151 = new System.Windows.Forms.Label();
            this.label152 = new System.Windows.Forms.Label();
            this.label153 = new System.Windows.Forms.Label();
            this.label154 = new System.Windows.Forms.Label();
            this.label155 = new System.Windows.Forms.Label();
            this.label156 = new System.Windows.Forms.Label();
            this.label157 = new System.Windows.Forms.Label();
            this.label158 = new System.Windows.Forms.Label();
            this.label159 = new System.Windows.Forms.Label();
            this.label160 = new System.Windows.Forms.Label();
            this.label161 = new System.Windows.Forms.Label();
            this.label162 = new System.Windows.Forms.Label();
            this.label163 = new System.Windows.Forms.Label();
            this.label164 = new System.Windows.Forms.Label();
            this.label165 = new System.Windows.Forms.Label();
            this.label166 = new System.Windows.Forms.Label();
            this.label167 = new System.Windows.Forms.Label();
            this.label168 = new System.Windows.Forms.Label();
            this.label169 = new System.Windows.Forms.Label();
            this.label170 = new System.Windows.Forms.Label();
            this.label171 = new System.Windows.Forms.Label();
            this.label172 = new System.Windows.Forms.Label();
            this.label173 = new System.Windows.Forms.Label();
            this.label174 = new System.Windows.Forms.Label();
            this.label175 = new System.Windows.Forms.Label();
            this.label176 = new System.Windows.Forms.Label();
            this.label177 = new System.Windows.Forms.Label();
            this.label178 = new System.Windows.Forms.Label();
            this.label179 = new System.Windows.Forms.Label();
            this.label180 = new System.Windows.Forms.Label();
            this.p2plus_19 = new System.Windows.Forms.TextBox();
            this.p2r_19 = new System.Windows.Forms.TextBox();
            this.p2ls_19 = new System.Windows.Forms.TextBox();
            this.p2iws_19 = new System.Windows.Forms.TextBox();
            this.p2ib_19 = new System.Windows.Forms.TextBox();
            this.p2pm_19 = new System.Windows.Forms.TextBox();
            this.p2vw_19 = new System.Windows.Forms.TextBox();
            this.p2plus_8 = new System.Windows.Forms.TextBox();
            this.p2r_8 = new System.Windows.Forms.TextBox();
            this.p2ls_8 = new System.Windows.Forms.TextBox();
            this.p2iws_8 = new System.Windows.Forms.TextBox();
            this.p2ib_8 = new System.Windows.Forms.TextBox();
            this.p2pm_8 = new System.Windows.Forms.TextBox();
            this.p2vw_8 = new System.Windows.Forms.TextBox();
            this.p2plus_14 = new System.Windows.Forms.TextBox();
            this.p2r_14 = new System.Windows.Forms.TextBox();
            this.p2ls_14 = new System.Windows.Forms.TextBox();
            this.p2iws_14 = new System.Windows.Forms.TextBox();
            this.p2ib_14 = new System.Windows.Forms.TextBox();
            this.p2pm_14 = new System.Windows.Forms.TextBox();
            this.p2vw_14 = new System.Windows.Forms.TextBox();
            this.p2plus_54 = new System.Windows.Forms.TextBox();
            this.p2r_54 = new System.Windows.Forms.TextBox();
            this.p2ls_54 = new System.Windows.Forms.TextBox();
            this.p2iws_54 = new System.Windows.Forms.TextBox();
            this.p2ib_54 = new System.Windows.Forms.TextBox();
            this.p2pm_54 = new System.Windows.Forms.TextBox();
            this.p2vw_54 = new System.Windows.Forms.TextBox();
            this.p2plus_5 = new System.Windows.Forms.TextBox();
            this.p2r_5 = new System.Windows.Forms.TextBox();
            this.p2ls_5 = new System.Windows.Forms.TextBox();
            this.p2iws_5 = new System.Windows.Forms.TextBox();
            this.p2ib_5 = new System.Windows.Forms.TextBox();
            this.p2pm_5 = new System.Windows.Forms.TextBox();
            this.p2vw_5 = new System.Windows.Forms.TextBox();
            this.p2plus_11 = new System.Windows.Forms.TextBox();
            this.p2r_11 = new System.Windows.Forms.TextBox();
            this.p2ls_11 = new System.Windows.Forms.TextBox();
            this.p2iws_11 = new System.Windows.Forms.TextBox();
            this.p2ib_11 = new System.Windows.Forms.TextBox();
            this.p2pm_11 = new System.Windows.Forms.TextBox();
            this.p2vw_11 = new System.Windows.Forms.TextBox();
            this.p2plus_55 = new System.Windows.Forms.TextBox();
            this.p2r_55 = new System.Windows.Forms.TextBox();
            this.p2ls_55 = new System.Windows.Forms.TextBox();
            this.p2iws_55 = new System.Windows.Forms.TextBox();
            this.p2ib_55 = new System.Windows.Forms.TextBox();
            this.p2pm_55 = new System.Windows.Forms.TextBox();
            this.p2vw_55 = new System.Windows.Forms.TextBox();
            this.p2plus_16 = new System.Windows.Forms.TextBox();
            this.p2r_16 = new System.Windows.Forms.TextBox();
            this.p2ls_16 = new System.Windows.Forms.TextBox();
            this.p2iws_16 = new System.Windows.Forms.TextBox();
            this.p2ib_16 = new System.Windows.Forms.TextBox();
            this.p2pm_16 = new System.Windows.Forms.TextBox();
            this.p2vw_16 = new System.Windows.Forms.TextBox();
            this.p2plus_17 = new System.Windows.Forms.TextBox();
            this.p2r_17 = new System.Windows.Forms.TextBox();
            this.p2ls_17 = new System.Windows.Forms.TextBox();
            this.p2iws_17 = new System.Windows.Forms.TextBox();
            this.p2ib_17 = new System.Windows.Forms.TextBox();
            this.p2pm_17 = new System.Windows.Forms.TextBox();
            this.p2vw_17 = new System.Windows.Forms.TextBox();
            this.p2plus_26 = new System.Windows.Forms.TextBox();
            this.p2r_26 = new System.Windows.Forms.TextBox();
            this.p2ls_26 = new System.Windows.Forms.TextBox();
            this.p2iws_26 = new System.Windows.Forms.TextBox();
            this.p2ib_26 = new System.Windows.Forms.TextBox();
            this.p2pm_26 = new System.Windows.Forms.TextBox();
            this.p2vw_26 = new System.Windows.Forms.TextBox();
            this.p2plus_56 = new System.Windows.Forms.TextBox();
            this.p2r_56 = new System.Windows.Forms.TextBox();
            this.p2ls_56 = new System.Windows.Forms.TextBox();
            this.p2iws_56 = new System.Windows.Forms.TextBox();
            this.p2ib_56 = new System.Windows.Forms.TextBox();
            this.p2pm_56 = new System.Windows.Forms.TextBox();
            this.p2vw_56 = new System.Windows.Forms.TextBox();
            this.p2r_0 = new System.Windows.Forms.TextBox();
            this.p2ls_0 = new System.Windows.Forms.TextBox();
            this.p2iws_0 = new System.Windows.Forms.TextBox();
            this.p2ib_0 = new System.Windows.Forms.TextBox();
            this.p2pm_0 = new System.Windows.Forms.TextBox();
            this.p2vw_0 = new System.Windows.Forms.TextBox();
            this.tab_P3 = new System.Windows.Forms.TabPage();
            this.panel3 = new System.Windows.Forms.Panel();
            this.p3ETAusfueren = new System.Windows.Forms.PictureBox();
            this.label181 = new System.Windows.Forms.Label();
            this.label182 = new System.Windows.Forms.Label();
            this.label183 = new System.Windows.Forms.Label();
            this.label184 = new System.Windows.Forms.Label();
            this.label185 = new System.Windows.Forms.Label();
            this.label186 = new System.Windows.Forms.Label();
            this.label187 = new System.Windows.Forms.Label();
            this.label188 = new System.Windows.Forms.Label();
            this.label189 = new System.Windows.Forms.Label();
            this.label190 = new System.Windows.Forms.Label();
            this.label191 = new System.Windows.Forms.Label();
            this.label192 = new System.Windows.Forms.Label();
            this.label193 = new System.Windows.Forms.Label();
            this.label194 = new System.Windows.Forms.Label();
            this.label195 = new System.Windows.Forms.Label();
            this.label196 = new System.Windows.Forms.Label();
            this.label197 = new System.Windows.Forms.Label();
            this.label198 = new System.Windows.Forms.Label();
            this.label199 = new System.Windows.Forms.Label();
            this.label200 = new System.Windows.Forms.Label();
            this.label201 = new System.Windows.Forms.Label();
            this.label202 = new System.Windows.Forms.Label();
            this.label203 = new System.Windows.Forms.Label();
            this.label204 = new System.Windows.Forms.Label();
            this.label205 = new System.Windows.Forms.Label();
            this.label206 = new System.Windows.Forms.Label();
            this.label207 = new System.Windows.Forms.Label();
            this.label208 = new System.Windows.Forms.Label();
            this.label209 = new System.Windows.Forms.Label();
            this.label210 = new System.Windows.Forms.Label();
            this.label211 = new System.Windows.Forms.Label();
            this.label212 = new System.Windows.Forms.Label();
            this.label213 = new System.Windows.Forms.Label();
            this.label214 = new System.Windows.Forms.Label();
            this.label215 = new System.Windows.Forms.Label();
            this.label216 = new System.Windows.Forms.Label();
            this.label217 = new System.Windows.Forms.Label();
            this.label218 = new System.Windows.Forms.Label();
            this.label219 = new System.Windows.Forms.Label();
            this.label220 = new System.Windows.Forms.Label();
            this.label221 = new System.Windows.Forms.Label();
            this.label222 = new System.Windows.Forms.Label();
            this.label223 = new System.Windows.Forms.Label();
            this.label224 = new System.Windows.Forms.Label();
            this.label225 = new System.Windows.Forms.Label();
            this.label226 = new System.Windows.Forms.Label();
            this.label227 = new System.Windows.Forms.Label();
            this.label228 = new System.Windows.Forms.Label();
            this.label229 = new System.Windows.Forms.Label();
            this.label230 = new System.Windows.Forms.Label();
            this.label231 = new System.Windows.Forms.Label();
            this.label232 = new System.Windows.Forms.Label();
            this.label233 = new System.Windows.Forms.Label();
            this.label234 = new System.Windows.Forms.Label();
            this.label235 = new System.Windows.Forms.Label();
            this.label236 = new System.Windows.Forms.Label();
            this.label237 = new System.Windows.Forms.Label();
            this.label238 = new System.Windows.Forms.Label();
            this.label239 = new System.Windows.Forms.Label();
            this.label240 = new System.Windows.Forms.Label();
            this.label241 = new System.Windows.Forms.Label();
            this.label242 = new System.Windows.Forms.Label();
            this.label243 = new System.Windows.Forms.Label();
            this.label244 = new System.Windows.Forms.Label();
            this.label245 = new System.Windows.Forms.Label();
            this.label246 = new System.Windows.Forms.Label();
            this.label247 = new System.Windows.Forms.Label();
            this.label248 = new System.Windows.Forms.Label();
            this.label249 = new System.Windows.Forms.Label();
            this.label250 = new System.Windows.Forms.Label();
            this.label251 = new System.Windows.Forms.Label();
            this.label252 = new System.Windows.Forms.Label();
            this.label253 = new System.Windows.Forms.Label();
            this.label254 = new System.Windows.Forms.Label();
            this.label255 = new System.Windows.Forms.Label();
            this.label256 = new System.Windows.Forms.Label();
            this.label257 = new System.Windows.Forms.Label();
            this.label258 = new System.Windows.Forms.Label();
            this.label259 = new System.Windows.Forms.Label();
            this.label260 = new System.Windows.Forms.Label();
            this.label261 = new System.Windows.Forms.Label();
            this.label262 = new System.Windows.Forms.Label();
            this.label263 = new System.Windows.Forms.Label();
            this.label264 = new System.Windows.Forms.Label();
            this.label265 = new System.Windows.Forms.Label();
            this.label266 = new System.Windows.Forms.Label();
            this.label267 = new System.Windows.Forms.Label();
            this.label268 = new System.Windows.Forms.Label();
            this.label269 = new System.Windows.Forms.Label();
            this.p3plus_20 = new System.Windows.Forms.TextBox();
            this.p3r_20 = new System.Windows.Forms.TextBox();
            this.p3ls_20 = new System.Windows.Forms.TextBox();
            this.p3iws_20 = new System.Windows.Forms.TextBox();
            this.p3ib_20 = new System.Windows.Forms.TextBox();
            this.p3pm_20 = new System.Windows.Forms.TextBox();
            this.p3vw_20 = new System.Windows.Forms.TextBox();
            this.p3plus_9 = new System.Windows.Forms.TextBox();
            this.p3r_9 = new System.Windows.Forms.TextBox();
            this.p3ls_9 = new System.Windows.Forms.TextBox();
            this.p3iws_9 = new System.Windows.Forms.TextBox();
            this.p3ib_9 = new System.Windows.Forms.TextBox();
            this.p3pm_9 = new System.Windows.Forms.TextBox();
            this.p3vw_9 = new System.Windows.Forms.TextBox();
            this.p3plus_15 = new System.Windows.Forms.TextBox();
            this.p3r_15 = new System.Windows.Forms.TextBox();
            this.p3ls_15 = new System.Windows.Forms.TextBox();
            this.p3iws_15 = new System.Windows.Forms.TextBox();
            this.p3ib_15 = new System.Windows.Forms.TextBox();
            this.p3pm_15 = new System.Windows.Forms.TextBox();
            this.p3vw_15 = new System.Windows.Forms.TextBox();
            this.p3plus_29 = new System.Windows.Forms.TextBox();
            this.p3r_29 = new System.Windows.Forms.TextBox();
            this.p3ls_29 = new System.Windows.Forms.TextBox();
            this.p3iws_29 = new System.Windows.Forms.TextBox();
            this.p3ib_29 = new System.Windows.Forms.TextBox();
            this.p3pm_29 = new System.Windows.Forms.TextBox();
            this.p3vw_29 = new System.Windows.Forms.TextBox();
            this.p3plus_6 = new System.Windows.Forms.TextBox();
            this.p3r_6 = new System.Windows.Forms.TextBox();
            this.p3ls_6 = new System.Windows.Forms.TextBox();
            this.p3iws_6 = new System.Windows.Forms.TextBox();
            this.p3ib_6 = new System.Windows.Forms.TextBox();
            this.p3pm_6 = new System.Windows.Forms.TextBox();
            this.p3vw_6 = new System.Windows.Forms.TextBox();
            this.p3plus_12 = new System.Windows.Forms.TextBox();
            this.p3r_12 = new System.Windows.Forms.TextBox();
            this.p3ls_12 = new System.Windows.Forms.TextBox();
            this.p3iws_12 = new System.Windows.Forms.TextBox();
            this.p3ib_12 = new System.Windows.Forms.TextBox();
            this.p3pm_12 = new System.Windows.Forms.TextBox();
            this.p3vw_12 = new System.Windows.Forms.TextBox();
            this.p3plus_30 = new System.Windows.Forms.TextBox();
            this.p3r_30 = new System.Windows.Forms.TextBox();
            this.p3ls_30 = new System.Windows.Forms.TextBox();
            this.p3iws_30 = new System.Windows.Forms.TextBox();
            this.p3ib_30 = new System.Windows.Forms.TextBox();
            this.p3pm_30 = new System.Windows.Forms.TextBox();
            this.p3vw_30 = new System.Windows.Forms.TextBox();
            this.p3plus_16 = new System.Windows.Forms.TextBox();
            this.p3r_16 = new System.Windows.Forms.TextBox();
            this.p3ls_16 = new System.Windows.Forms.TextBox();
            this.p3iws_16 = new System.Windows.Forms.TextBox();
            this.p3ib_16 = new System.Windows.Forms.TextBox();
            this.p3pm_16 = new System.Windows.Forms.TextBox();
            this.p3vw_16 = new System.Windows.Forms.TextBox();
            this.p3plus_17 = new System.Windows.Forms.TextBox();
            this.p3r_17 = new System.Windows.Forms.TextBox();
            this.p3ls_17 = new System.Windows.Forms.TextBox();
            this.p3iws_17 = new System.Windows.Forms.TextBox();
            this.p3ib_17 = new System.Windows.Forms.TextBox();
            this.p3pm_17 = new System.Windows.Forms.TextBox();
            this.p3vw_17 = new System.Windows.Forms.TextBox();
            this.p3plus_26 = new System.Windows.Forms.TextBox();
            this.p3r_26 = new System.Windows.Forms.TextBox();
            this.p3ls_26 = new System.Windows.Forms.TextBox();
            this.p3iws_26 = new System.Windows.Forms.TextBox();
            this.p3ib_26 = new System.Windows.Forms.TextBox();
            this.p3pm_26 = new System.Windows.Forms.TextBox();
            this.p3vw_26 = new System.Windows.Forms.TextBox();
            this.p3plus_31 = new System.Windows.Forms.TextBox();
            this.p3r_31 = new System.Windows.Forms.TextBox();
            this.p3ls_31 = new System.Windows.Forms.TextBox();
            this.p3iws_31 = new System.Windows.Forms.TextBox();
            this.p3ib_31 = new System.Windows.Forms.TextBox();
            this.p3pm_31 = new System.Windows.Forms.TextBox();
            this.p3vw_31 = new System.Windows.Forms.TextBox();
            this.p3r_0 = new System.Windows.Forms.TextBox();
            this.p3ls_0 = new System.Windows.Forms.TextBox();
            this.p3iws_0 = new System.Windows.Forms.TextBox();
            this.p3ib_0 = new System.Windows.Forms.TextBox();
            this.p3pm_0 = new System.Windows.Forms.TextBox();
            this.p3vw_0 = new System.Windows.Forms.TextBox();
            this.tab_eTeil = new System.Windows.Forms.TabPage();
            this.dataGridViewETeil = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn1 = new System.Windows.Forms.DataGridViewImageColumn();
            this.colWarteschlange = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBearbeitung = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colPlanung = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.dataGridViewProduktAuftrag = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab_arbeitzeit = new System.Windows.Forms.TabPage();
            this.arbPlatzAusfueren = new System.Windows.Forms.PictureBox();
            this.DataGridViewAP = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.minus = new System.Windows.Forms.DataGridViewImageColumn();
            this.plus = new System.Windows.Forms.DataGridViewImageColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewImageColumn2 = new System.Windows.Forms.DataGridViewImageColumn();
            this.s1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.s3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.ueber = new System.Windows.Forms.DataGridViewImageColumn();
            this.tab_bestellverwaltung = new System.Windows.Forms.TabPage();
            this.tab2 = new System.Windows.Forms.TabControl();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.dataGridViewKTeil = new System.Windows.Forms.DataGridView();
            this.dataGridViewLinkColumn1 = new System.Windows.Forms.DataGridViewLinkColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tab_bestellung = new System.Windows.Forms.TabPage();
            this.dvVerwenden = new System.Windows.Forms.CheckBox();
            this.addNr2 = new System.Windows.Forms.PictureBox();
            this.zurueck2 = new System.Windows.Forms.PictureBox();
            this.saveAenderungen2 = new System.Windows.Forms.PictureBox();
            this.label275 = new System.Windows.Forms.Label();
            this.dataGridViewDirektverkauf = new System.Windows.Forms.DataGridView();
            this.knr2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.str = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.addNr = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.uebernehmenXML = new System.Windows.Forms.PictureBox();
            this.zurueck = new System.Windows.Forms.PictureBox();
            this.saveAenderungen = new System.Windows.Forms.PictureBox();
            this.dataGridViewBestellung = new System.Windows.Forms.DataGridView();
            this.kNr = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.menge = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eil = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.del = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.xmlOutput = new System.Windows.Forms.TabPage();
            this.panelXMLerstellen = new System.Windows.Forms.Panel();
            this.dataGridViewPrAuftraege = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lb12 = new System.Windows.Forms.Label();
            this.dataGridViewProduktKapazit = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ueberStunden = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label274 = new System.Windows.Forms.Label();
            this.dataGridViewEinkauf = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label272 = new System.Windows.Forms.Label();
            this.dataGridViewDirekt = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.straf = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label271 = new System.Windows.Forms.Label();
            this.dataGridViewVertrieb = new System.Windows.Forms.DataGridView();
            this.dg_p1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_p2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dg_p3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label270 = new System.Windows.Forms.Label();
            this.Spache = new System.Windows.Forms.TabPage();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_abweichung = new System.Windows.Forms.TabPage();
            this.LabelAbweichung = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_info = new System.Windows.Forms.Label();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.lbl_100 = new System.Windows.Forms.Label();
            this.lbl_50 = new System.Windows.Forms.Label();
            this.btn_ok = new System.Windows.Forms.Button();
            this.lbl_10 = new System.Windows.Forms.Label();
            this.trackBarAbweichung = new System.Windows.Forms.TrackBar();
            this.tab_diskount = new System.Windows.Forms.TabPage();
            this.LabelDiskont = new System.Windows.Forms.Label();
            this.label273 = new System.Windows.Forms.Label();
            this.mengeGrenze = new System.Windows.Forms.NumericUpDown();
            this.diskGrenze = new System.Windows.Forms.NumericUpDown();
            this.label276 = new System.Windows.Forms.Label();
            this.label277 = new System.Windows.Forms.Label();
            this.label278 = new System.Windows.Forms.Label();
            this.label279 = new System.Windows.Forms.Label();
            this.label280 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label281 = new System.Windows.Forms.Label();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.diskSpeichern = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.tab_schicht = new System.Windows.Forms.TabPage();
            this.LabelSchichten = new System.Windows.Forms.Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.label282 = new System.Windows.Forms.Label();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btn_schicht_save = new System.Windows.Forms.Button();
            this.lbl_3schicht = new System.Windows.Forms.Label();
            this.lbl_2schicht = new System.Windows.Forms.Label();
            this.Sprache = new System.Windows.Forms.TabPage();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.menu = new System.Windows.Forms.MenuStrip();
            this.dateiToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateiÖffnenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.xMLexportToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.schließenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.einstellungenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hilfeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.handbuchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.videoF2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.spracheToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.deutschToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.englischToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.gewichtungToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scimToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.startSeiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.xml_export = new System.Windows.Forms.PictureBox();
            this.info = new System.Windows.Forms.Label();
            this.imageListAmpel = new System.Windows.Forms.ImageList(this.components);
            this.helpProvider1 = new System.Windows.Forms.HelpProvider();
            this.imageListPlusMinus = new System.Windows.Forms.ImageList(this.components);
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button3 = new System.Windows.Forms.Button();
            this.tabs.SuspendLayout();
            this.tab_xml.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pufferP3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pufferP2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pufferP1)).BeginInit();
            this.panelXML.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.save)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xmlOffenOK)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolAusfueren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildSpeichOk)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP33)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownAW3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP32)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownAW2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP31)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownAW1)).BeginInit();
            this.tab_produktion.SuspendLayout();
            this.tab1.SuspendLayout();
            this.tab_P1.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p1ETAusfueren)).BeginInit();
            this.tab_P2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p2ETAusfueren)).BeginInit();
            this.tab_P3.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p3ETAusfueren)).BeginInit();
            this.tab_eTeil.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewETeil)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktAuftrag)).BeginInit();
            this.tab_arbeitzeit.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.arbPlatzAusfueren)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewAP)).BeginInit();
            this.tab_bestellverwaltung.SuspendLayout();
            this.tab2.SuspendLayout();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKTeil)).BeginInit();
            this.tab_bestellung.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.addNr2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zurueck2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveAenderungen2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDirektverkauf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.addNr)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.uebernehmenXML)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.zurueck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveAenderungen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBestellung)).BeginInit();
            this.xmlOutput.SuspendLayout();
            this.panelXMLerstellen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrAuftraege)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktKapazit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEinkauf)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDirekt)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVertrieb)).BeginInit();
            this.Spache.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tab_abweichung.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAbweichung)).BeginInit();
            this.tab_diskount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mengeGrenze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diskGrenze)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.tab_schicht.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.Sprache.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.menu.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xml_export)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabs
            // 
            this.tabs.Controls.Add(this.tab_xml);
            this.tabs.Controls.Add(this.tab_produktion);
            this.tabs.Controls.Add(this.tab_arbeitzeit);
            this.tabs.Controls.Add(this.tab_bestellverwaltung);
            this.tabs.Controls.Add(this.xmlOutput);
            this.tabs.Controls.Add(this.Spache);
            resources.ApplyResources(this.tabs, "tabs");
            this.tabs.Name = "tabs";
            this.tabs.SelectedIndex = 0;
            this.helpProvider1.SetShowHelp(this.tabs, ((bool)(resources.GetObject("tabs.ShowHelp"))));
            // 
            // tab_xml
            // 
            this.tab_xml.BackColor = System.Drawing.Color.Transparent;
            this.tab_xml.Controls.Add(this.prognose1);
            this.tab_xml.Controls.Add(this.pufferP3);
            this.tab_xml.Controls.Add(this.pufferP2);
            this.tab_xml.Controls.Add(this.pufferP1);
            this.tab_xml.Controls.Add(this.label1);
            this.tab_xml.Controls.Add(this.panelXML);
            this.tab_xml.Controls.Add(this.bildSpeichOk);
            this.tab_xml.Controls.Add(this.pictureBox1);
            this.tab_xml.Controls.Add(this.prognoseSpeichern);
            this.tab_xml.Controls.Add(this.upDownP33);
            this.tab_xml.Controls.Add(this.upDownP23);
            this.tab_xml.Controls.Add(this.upDownP13);
            this.tab_xml.Controls.Add(this.upDownAW3);
            this.tab_xml.Controls.Add(this.upDownP32);
            this.tab_xml.Controls.Add(this.upDownP22);
            this.tab_xml.Controls.Add(this.upDownP12);
            this.tab_xml.Controls.Add(this.upDownAW2);
            this.tab_xml.Controls.Add(this.upDownP31);
            this.tab_xml.Controls.Add(this.upDownP21);
            this.tab_xml.Controls.Add(this.upDownP11);
            this.tab_xml.Controls.Add(this.upDownAW1);
            this.tab_xml.Controls.Add(this.prognose2);
            this.tab_xml.Controls.Add(this.prognose3);
            this.tab_xml.Controls.Add(this.aktulleWoche);
            this.tab_xml.Controls.Add(this.p3);
            this.tab_xml.Controls.Add(this.p2);
            this.tab_xml.Controls.Add(this.p1);
            this.tab_xml.Controls.Add(this.titlePrognose);
            resources.ApplyResources(this.tab_xml, "tab_xml");
            this.tab_xml.Name = "tab_xml";
            this.helpProvider1.SetShowHelp(this.tab_xml, ((bool)(resources.GetObject("tab_xml.ShowHelp"))));
            // 
            // prognose1
            // 
            resources.ApplyResources(this.prognose1, "prognose1");
            this.prognose1.Name = "prognose1";
            this.helpProvider1.SetShowHelp(this.prognose1, ((bool)(resources.GetObject("prognose1.ShowHelp"))));
            // 
            // pufferP3
            // 
            this.pufferP3.BackColor = System.Drawing.Color.MistyRose;
            resources.ApplyResources(this.pufferP3, "pufferP3");
            this.pufferP3.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.pufferP3.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.pufferP3.Name = "pufferP3";
            this.helpProvider1.SetShowHelp(this.pufferP3, ((bool)(resources.GetObject("pufferP3.ShowHelp"))));
            this.pufferP3.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // pufferP2
            // 
            this.pufferP2.BackColor = System.Drawing.Color.MistyRose;
            resources.ApplyResources(this.pufferP2, "pufferP2");
            this.pufferP2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.pufferP2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.pufferP2.Name = "pufferP2";
            this.helpProvider1.SetShowHelp(this.pufferP2, ((bool)(resources.GetObject("pufferP2.ShowHelp"))));
            this.pufferP2.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            // 
            // pufferP1
            // 
            this.pufferP1.BackColor = System.Drawing.Color.MistyRose;
            resources.ApplyResources(this.pufferP1, "pufferP1");
            this.pufferP1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.pufferP1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.pufferP1.Name = "pufferP1";
            this.helpProvider1.SetShowHelp(this.pufferP1, ((bool)(resources.GetObject("pufferP1.ShowHelp"))));
            this.pufferP1.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.pufferP1.ValueChanged += new System.EventHandler(this.pufferP1_ValueChanged);
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            this.helpProvider1.SetShowHelp(this.label1, ((bool)(resources.GetObject("label1.ShowHelp"))));
            // 
            // panelXML
            // 
            this.panelXML.Controls.Add(this.save);
            this.panelXML.Controls.Add(this.xmlOffenOK);
            this.panelXML.Controls.Add(this.toolAusfueren);
            this.panelXML.Controls.Add(this.xmlTextBox);
            this.panelXML.Controls.Add(this.pictureBox2);
            this.panelXML.Controls.Add(this.titleXmlLaden);
            this.panelXML.Controls.Add(this.xml_suchen);
            resources.ApplyResources(this.panelXML, "panelXML");
            this.panelXML.Name = "panelXML";
            this.helpProvider1.SetShowHelp(this.panelXML, ((bool)(resources.GetObject("panelXML.ShowHelp"))));
            // 
            // save
            // 
            this.save.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.save, "save");
            this.save.Name = "save";
            this.helpProvider1.SetShowHelp(this.save, ((bool)(resources.GetObject("save.ShowHelp"))));
            this.save.TabStop = false;
            this.toolTip.SetToolTip(this.save, resources.GetString("save.ToolTip"));
            // 
            // xmlOffenOK
            // 
            resources.ApplyResources(this.xmlOffenOK, "xmlOffenOK");
            this.xmlOffenOK.Name = "xmlOffenOK";
            this.helpProvider1.SetShowHelp(this.xmlOffenOK, ((bool)(resources.GetObject("xmlOffenOK.ShowHelp"))));
            this.xmlOffenOK.TabStop = false;
            this.toolTip.SetToolTip(this.xmlOffenOK, resources.GetString("xmlOffenOK.ToolTip"));
            // 
            // toolAusfueren
            // 
            this.toolAusfueren.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.toolAusfueren, "toolAusfueren");
            this.toolAusfueren.Name = "toolAusfueren";
            this.helpProvider1.SetShowHelp(this.toolAusfueren, ((bool)(resources.GetObject("toolAusfueren.ShowHelp"))));
            this.toolAusfueren.TabStop = false;
            this.toolTip.SetToolTip(this.toolAusfueren, resources.GetString("toolAusfueren.ToolTip"));
            this.toolAusfueren.Click += new System.EventHandler(this.toolAusfueren_Click);
            // 
            // xmlTextBox
            // 
            resources.ApplyResources(this.xmlTextBox, "xmlTextBox");
            this.xmlTextBox.Name = "xmlTextBox";
            this.helpProvider1.SetShowHelp(this.xmlTextBox, ((bool)(resources.GetObject("xmlTextBox.ShowHelp"))));
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.helpProvider1.SetShowHelp(this.pictureBox2, ((bool)(resources.GetObject("pictureBox2.ShowHelp"))));
            this.pictureBox2.TabStop = false;
            // 
            // titleXmlLaden
            // 
            resources.ApplyResources(this.titleXmlLaden, "titleXmlLaden");
            this.titleXmlLaden.Name = "titleXmlLaden";
            this.helpProvider1.SetShowHelp(this.titleXmlLaden, ((bool)(resources.GetObject("titleXmlLaden.ShowHelp"))));
            // 
            // xml_suchen
            // 
            resources.ApplyResources(this.xml_suchen, "xml_suchen");
            this.xml_suchen.Name = "xml_suchen";
            this.helpProvider1.SetShowHelp(this.xml_suchen, ((bool)(resources.GetObject("xml_suchen.ShowHelp"))));
            this.toolTip.SetToolTip(this.xml_suchen, resources.GetString("xml_suchen.ToolTip"));
            this.xml_suchen.UseVisualStyleBackColor = true;
            this.xml_suchen.Click += new System.EventHandler(this.xml_suchen_Click);
            // 
            // bildSpeichOk
            // 
            resources.ApplyResources(this.bildSpeichOk, "bildSpeichOk");
            this.bildSpeichOk.Name = "bildSpeichOk";
            this.helpProvider1.SetShowHelp(this.bildSpeichOk, ((bool)(resources.GetObject("bildSpeichOk.ShowHelp"))));
            this.bildSpeichOk.TabStop = false;
            this.toolTip.SetToolTip(this.bildSpeichOk, resources.GetString("bildSpeichOk.ToolTip"));
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.helpProvider1.SetShowHelp(this.pictureBox1, ((bool)(resources.GetObject("pictureBox1.ShowHelp"))));
            this.pictureBox1.TabStop = false;
            // 
            // prognoseSpeichern
            // 
            resources.ApplyResources(this.prognoseSpeichern, "prognoseSpeichern");
            this.prognoseSpeichern.Name = "prognoseSpeichern";
            this.helpProvider1.SetShowHelp(this.prognoseSpeichern, ((bool)(resources.GetObject("prognoseSpeichern.ShowHelp"))));
            this.toolTip.SetToolTip(this.prognoseSpeichern, resources.GetString("prognoseSpeichern.ToolTip"));
            this.prognoseSpeichern.UseVisualStyleBackColor = true;
            this.prognoseSpeichern.Click += new System.EventHandler(this.prognoseSpeichern_Click);
            // 
            // upDownP33
            // 
            this.upDownP33.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP33, "upDownP33");
            this.upDownP33.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP33.Name = "upDownP33";
            this.helpProvider1.SetShowHelp(this.upDownP33, ((bool)(resources.GetObject("upDownP33.ShowHelp"))));
            this.upDownP33.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP33.ValueChanged += new System.EventHandler(this.upDownP33_ValueChanged);
            // 
            // upDownP23
            // 
            this.upDownP23.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP23, "upDownP23");
            this.upDownP23.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP23.Name = "upDownP23";
            this.helpProvider1.SetShowHelp(this.upDownP23, ((bool)(resources.GetObject("upDownP23.ShowHelp"))));
            this.upDownP23.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP23.ValueChanged += new System.EventHandler(this.upDownP23_ValueChanged);
            // 
            // upDownP13
            // 
            this.upDownP13.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP13, "upDownP13");
            this.upDownP13.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP13.Name = "upDownP13";
            this.helpProvider1.SetShowHelp(this.upDownP13, ((bool)(resources.GetObject("upDownP13.ShowHelp"))));
            this.upDownP13.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP13.ValueChanged += new System.EventHandler(this.upDownP13_ValueChanged);
            // 
            // upDownAW3
            // 
            this.upDownAW3.BackColor = System.Drawing.Color.Honeydew;
            this.upDownAW3.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownAW3, "upDownAW3");
            this.upDownAW3.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownAW3.Name = "upDownAW3";
            this.helpProvider1.SetShowHelp(this.upDownAW3, ((bool)(resources.GetObject("upDownAW3.ShowHelp"))));
            this.upDownAW3.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownAW3.ValueChanged += new System.EventHandler(this.upDownAW3_ValueChanged);
            // 
            // upDownP32
            // 
            this.upDownP32.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP32, "upDownP32");
            this.upDownP32.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP32.Name = "upDownP32";
            this.helpProvider1.SetShowHelp(this.upDownP32, ((bool)(resources.GetObject("upDownP32.ShowHelp"))));
            this.upDownP32.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP32.ValueChanged += new System.EventHandler(this.upDownP32_ValueChanged);
            // 
            // upDownP22
            // 
            this.upDownP22.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP22, "upDownP22");
            this.upDownP22.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP22.Name = "upDownP22";
            this.helpProvider1.SetShowHelp(this.upDownP22, ((bool)(resources.GetObject("upDownP22.ShowHelp"))));
            this.upDownP22.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP22.ValueChanged += new System.EventHandler(this.upDownP22_ValueChanged);
            // 
            // upDownP12
            // 
            this.upDownP12.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP12, "upDownP12");
            this.upDownP12.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP12.Name = "upDownP12";
            this.helpProvider1.SetShowHelp(this.upDownP12, ((bool)(resources.GetObject("upDownP12.ShowHelp"))));
            this.upDownP12.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP12.ValueChanged += new System.EventHandler(this.upDownP12_ValueChanged);
            // 
            // upDownAW2
            // 
            this.upDownAW2.BackColor = System.Drawing.Color.Honeydew;
            this.upDownAW2.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownAW2, "upDownAW2");
            this.upDownAW2.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownAW2.Name = "upDownAW2";
            this.helpProvider1.SetShowHelp(this.upDownAW2, ((bool)(resources.GetObject("upDownAW2.ShowHelp"))));
            this.upDownAW2.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownAW2.ValueChanged += new System.EventHandler(this.upDownAW2_ValueChanged);
            // 
            // upDownP31
            // 
            this.upDownP31.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP31, "upDownP31");
            this.upDownP31.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP31.Name = "upDownP31";
            this.helpProvider1.SetShowHelp(this.upDownP31, ((bool)(resources.GetObject("upDownP31.ShowHelp"))));
            this.upDownP31.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP31.ValueChanged += new System.EventHandler(this.upDownP31_ValueChanged);
            // 
            // upDownP21
            // 
            this.upDownP21.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP21, "upDownP21");
            this.upDownP21.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP21.Name = "upDownP21";
            this.helpProvider1.SetShowHelp(this.upDownP21, ((bool)(resources.GetObject("upDownP21.ShowHelp"))));
            this.upDownP21.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP21.ValueChanged += new System.EventHandler(this.upDownP21_ValueChanged);
            // 
            // upDownP11
            // 
            this.upDownP11.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownP11, "upDownP11");
            this.upDownP11.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownP11.Name = "upDownP11";
            this.helpProvider1.SetShowHelp(this.upDownP11, ((bool)(resources.GetObject("upDownP11.ShowHelp"))));
            this.upDownP11.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownP11.ValueChanged += new System.EventHandler(this.upDownP11_ValueChanged);
            // 
            // upDownAW1
            // 
            this.upDownAW1.BackColor = System.Drawing.Color.Honeydew;
            this.upDownAW1.Increment = new decimal(new int[] {
            10,
            0,
            0,
            0});
            resources.ApplyResources(this.upDownAW1, "upDownAW1");
            this.upDownAW1.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.upDownAW1.Name = "upDownAW1";
            this.helpProvider1.SetShowHelp(this.upDownAW1, ((bool)(resources.GetObject("upDownAW1.ShowHelp"))));
            this.upDownAW1.Value = new decimal(new int[] {
            100,
            0,
            0,
            0});
            this.upDownAW1.ValueChanged += new System.EventHandler(this.upDownAW1_ValueChanged);
            // 
            // prognose2
            // 
            resources.ApplyResources(this.prognose2, "prognose2");
            this.prognose2.Name = "prognose2";
            this.helpProvider1.SetShowHelp(this.prognose2, ((bool)(resources.GetObject("prognose2.ShowHelp"))));
            // 
            // prognose3
            // 
            resources.ApplyResources(this.prognose3, "prognose3");
            this.prognose3.Name = "prognose3";
            this.helpProvider1.SetShowHelp(this.prognose3, ((bool)(resources.GetObject("prognose3.ShowHelp"))));
            // 
            // aktulleWoche
            // 
            resources.ApplyResources(this.aktulleWoche, "aktulleWoche");
            this.aktulleWoche.Name = "aktulleWoche";
            this.helpProvider1.SetShowHelp(this.aktulleWoche, ((bool)(resources.GetObject("aktulleWoche.ShowHelp"))));
            // 
            // p3
            // 
            resources.ApplyResources(this.p3, "p3");
            this.p3.Name = "p3";
            this.helpProvider1.SetShowHelp(this.p3, ((bool)(resources.GetObject("p3.ShowHelp"))));
            // 
            // p2
            // 
            resources.ApplyResources(this.p2, "p2");
            this.p2.Name = "p2";
            this.helpProvider1.SetShowHelp(this.p2, ((bool)(resources.GetObject("p2.ShowHelp"))));
            // 
            // p1
            // 
            resources.ApplyResources(this.p1, "p1");
            this.p1.Name = "p1";
            this.helpProvider1.SetShowHelp(this.p1, ((bool)(resources.GetObject("p1.ShowHelp"))));
            // 
            // titlePrognose
            // 
            resources.ApplyResources(this.titlePrognose, "titlePrognose");
            this.titlePrognose.Name = "titlePrognose";
            this.helpProvider1.SetShowHelp(this.titlePrognose, ((bool)(resources.GetObject("titlePrognose.ShowHelp"))));
            // 
            // tab_produktion
            // 
            this.tab_produktion.BackColor = System.Drawing.Color.Transparent;
            this.tab_produktion.Controls.Add(this.tab1);
            resources.ApplyResources(this.tab_produktion, "tab_produktion");
            this.tab_produktion.Name = "tab_produktion";
            this.helpProvider1.SetShowHelp(this.tab_produktion, ((bool)(resources.GetObject("tab_produktion.ShowHelp"))));
            // 
            // tab1
            // 
            this.tab1.Controls.Add(this.tab_P1);
            this.tab1.Controls.Add(this.tab_P2);
            this.tab1.Controls.Add(this.tab_P3);
            this.tab1.Controls.Add(this.tab_eTeil);
            this.tab1.Controls.Add(this.tabPage1);
            resources.ApplyResources(this.tab1, "tab1");
            this.tab1.Name = "tab1";
            this.tab1.SelectedIndex = 0;
            this.helpProvider1.SetShowHelp(this.tab1, ((bool)(resources.GetObject("tab1.ShowHelp"))));
            // 
            // tab_P1
            // 
            this.tab_P1.BackColor = System.Drawing.Color.Transparent;
            this.tab_P1.Controls.Add(this.panel1);
            resources.ApplyResources(this.tab_P1, "tab_P1");
            this.tab_P1.Name = "tab_P1";
            this.helpProvider1.SetShowHelp(this.tab_P1, ((bool)(resources.GetObject("tab_P1.ShowHelp"))));
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label91);
            this.panel1.Controls.Add(this.label90);
            this.panel1.Controls.Add(this.label89);
            this.panel1.Controls.Add(this.label88);
            this.panel1.Controls.Add(this.label87);
            this.panel1.Controls.Add(this.label86);
            this.panel1.Controls.Add(this.label74);
            this.panel1.Controls.Add(this.label75);
            this.panel1.Controls.Add(this.label76);
            this.panel1.Controls.Add(this.label77);
            this.panel1.Controls.Add(this.label78);
            this.panel1.Controls.Add(this.label79);
            this.panel1.Controls.Add(this.label80);
            this.panel1.Controls.Add(this.label81);
            this.panel1.Controls.Add(this.label82);
            this.panel1.Controls.Add(this.label83);
            this.panel1.Controls.Add(this.label84);
            this.panel1.Controls.Add(this.label85);
            this.panel1.Controls.Add(this.label73);
            this.panel1.Controls.Add(this.label72);
            this.panel1.Controls.Add(this.label71);
            this.panel1.Controls.Add(this.label60);
            this.panel1.Controls.Add(this.label61);
            this.panel1.Controls.Add(this.label62);
            this.panel1.Controls.Add(this.label63);
            this.panel1.Controls.Add(this.label64);
            this.panel1.Controls.Add(this.label65);
            this.panel1.Controls.Add(this.label66);
            this.panel1.Controls.Add(this.label67);
            this.panel1.Controls.Add(this.label68);
            this.panel1.Controls.Add(this.label69);
            this.panel1.Controls.Add(this.label70);
            this.panel1.Controls.Add(this.label49);
            this.panel1.Controls.Add(this.label50);
            this.panel1.Controls.Add(this.label51);
            this.panel1.Controls.Add(this.label52);
            this.panel1.Controls.Add(this.label53);
            this.panel1.Controls.Add(this.label54);
            this.panel1.Controls.Add(this.label55);
            this.panel1.Controls.Add(this.label56);
            this.panel1.Controls.Add(this.label57);
            this.panel1.Controls.Add(this.label58);
            this.panel1.Controls.Add(this.label59);
            this.panel1.Controls.Add(this.label38);
            this.panel1.Controls.Add(this.label39);
            this.panel1.Controls.Add(this.label40);
            this.panel1.Controls.Add(this.label41);
            this.panel1.Controls.Add(this.label42);
            this.panel1.Controls.Add(this.label43);
            this.panel1.Controls.Add(this.label44);
            this.panel1.Controls.Add(this.label45);
            this.panel1.Controls.Add(this.label46);
            this.panel1.Controls.Add(this.label47);
            this.panel1.Controls.Add(this.label48);
            this.panel1.Controls.Add(this.label37);
            this.panel1.Controls.Add(this.label15);
            this.panel1.Controls.Add(this.label27);
            this.panel1.Controls.Add(this.label28);
            this.panel1.Controls.Add(this.label29);
            this.panel1.Controls.Add(this.label30);
            this.panel1.Controls.Add(this.label31);
            this.panel1.Controls.Add(this.label32);
            this.panel1.Controls.Add(this.label33);
            this.panel1.Controls.Add(this.label34);
            this.panel1.Controls.Add(this.label35);
            this.panel1.Controls.Add(this.label36);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.label25);
            this.panel1.Controls.Add(this.label26);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Controls.Add(this.label23);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.label18);
            this.panel1.Controls.Add(this.label19);
            this.panel1.Controls.Add(this.label17);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label13);
            this.panel1.Controls.Add(this.label14);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.label10);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.p1plus_18);
            this.panel1.Controls.Add(this.p1r_18);
            this.panel1.Controls.Add(this.p1ls_18);
            this.panel1.Controls.Add(this.p1iws_18);
            this.panel1.Controls.Add(this.p1ib_18);
            this.panel1.Controls.Add(this.p1pm_18);
            this.panel1.Controls.Add(this.p1vw_18);
            this.panel1.Controls.Add(this.p1plus_7);
            this.panel1.Controls.Add(this.p1r_7);
            this.panel1.Controls.Add(this.p1ls_7);
            this.panel1.Controls.Add(this.p1iws_7);
            this.panel1.Controls.Add(this.p1ib_7);
            this.panel1.Controls.Add(this.p1pm_7);
            this.panel1.Controls.Add(this.p1vw_7);
            this.panel1.Controls.Add(this.p1plus_13);
            this.panel1.Controls.Add(this.p1r_13);
            this.panel1.Controls.Add(this.p1ls_13);
            this.panel1.Controls.Add(this.p1iws_13);
            this.panel1.Controls.Add(this.p1ib_13);
            this.panel1.Controls.Add(this.p1pm_13);
            this.panel1.Controls.Add(this.p1vw_13);
            this.panel1.Controls.Add(this.p1plus_49);
            this.panel1.Controls.Add(this.p1r_49);
            this.panel1.Controls.Add(this.p1ls_49);
            this.panel1.Controls.Add(this.p1iws_49);
            this.panel1.Controls.Add(this.p1ib_49);
            this.panel1.Controls.Add(this.p1pm_49);
            this.panel1.Controls.Add(this.p1vw_49);
            this.panel1.Controls.Add(this.p1plus_4);
            this.panel1.Controls.Add(this.p1r_4);
            this.panel1.Controls.Add(this.p1ls_4);
            this.panel1.Controls.Add(this.p1iws_4);
            this.panel1.Controls.Add(this.p1ib_4);
            this.panel1.Controls.Add(this.p1pm_4);
            this.panel1.Controls.Add(this.p1vw_4);
            this.panel1.Controls.Add(this.p1plus_10);
            this.panel1.Controls.Add(this.p1r_10);
            this.panel1.Controls.Add(this.p1ls_10);
            this.panel1.Controls.Add(this.p1iws_10);
            this.panel1.Controls.Add(this.p1ib_10);
            this.panel1.Controls.Add(this.p1pm_10);
            this.panel1.Controls.Add(this.p1vw_10);
            this.panel1.Controls.Add(this.p1plus_50);
            this.panel1.Controls.Add(this.p1r_50);
            this.panel1.Controls.Add(this.p1ls_50);
            this.panel1.Controls.Add(this.p1iws_50);
            this.panel1.Controls.Add(this.p1ib_50);
            this.panel1.Controls.Add(this.p1pm_50);
            this.panel1.Controls.Add(this.p1vw_50);
            this.panel1.Controls.Add(this.p1plus_16);
            this.panel1.Controls.Add(this.p1r_16);
            this.panel1.Controls.Add(this.p1ls_16);
            this.panel1.Controls.Add(this.p1iws_16);
            this.panel1.Controls.Add(this.p1ib_16);
            this.panel1.Controls.Add(this.p1pm_16);
            this.panel1.Controls.Add(this.p1vw_16);
            this.panel1.Controls.Add(this.p1plus_17);
            this.panel1.Controls.Add(this.p1r_17);
            this.panel1.Controls.Add(this.p1ls_17);
            this.panel1.Controls.Add(this.p1iws_17);
            this.panel1.Controls.Add(this.p1ib_17);
            this.panel1.Controls.Add(this.p1pm_17);
            this.panel1.Controls.Add(this.p1vw_17);
            this.panel1.Controls.Add(this.p1plus_26);
            this.panel1.Controls.Add(this.p1r_26);
            this.panel1.Controls.Add(this.p1ls_26);
            this.panel1.Controls.Add(this.p1iws_26);
            this.panel1.Controls.Add(this.p1ib_26);
            this.panel1.Controls.Add(this.p1pm_26);
            this.panel1.Controls.Add(this.p1vw_26);
            this.panel1.Controls.Add(this.p1plus_51);
            this.panel1.Controls.Add(this.p1r_51);
            this.panel1.Controls.Add(this.p1ls_51);
            this.panel1.Controls.Add(this.p1iws_51);
            this.panel1.Controls.Add(this.p1ib_51);
            this.panel1.Controls.Add(this.p1pm_51);
            this.panel1.Controls.Add(this.p1vw_51);
            this.panel1.Controls.Add(this.p1r_0);
            this.panel1.Controls.Add(this.p1ls_0);
            this.panel1.Controls.Add(this.p1iws_0);
            this.panel1.Controls.Add(this.p1ib_0);
            this.panel1.Controls.Add(this.p1pm_0);
            this.panel1.Controls.Add(this.p1vw_0);
            this.panel1.Controls.Add(this.p1ETAusfueren);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Name = "panel1";
            this.helpProvider1.SetShowHelp(this.panel1, ((bool)(resources.GetObject("panel1.ShowHelp"))));
            this.toolTip.SetToolTip(this.panel1, resources.GetString("panel1.ToolTip"));
            // 
            // label91
            // 
            resources.ApplyResources(this.label91, "label91");
            this.label91.Name = "label91";
            this.helpProvider1.SetShowHelp(this.label91, ((bool)(resources.GetObject("label91.ShowHelp"))));
            // 
            // label90
            // 
            resources.ApplyResources(this.label90, "label90");
            this.label90.Name = "label90";
            this.helpProvider1.SetShowHelp(this.label90, ((bool)(resources.GetObject("label90.ShowHelp"))));
            // 
            // label89
            // 
            resources.ApplyResources(this.label89, "label89");
            this.label89.Name = "label89";
            this.helpProvider1.SetShowHelp(this.label89, ((bool)(resources.GetObject("label89.ShowHelp"))));
            // 
            // label88
            // 
            resources.ApplyResources(this.label88, "label88");
            this.label88.Name = "label88";
            this.helpProvider1.SetShowHelp(this.label88, ((bool)(resources.GetObject("label88.ShowHelp"))));
            // 
            // label87
            // 
            resources.ApplyResources(this.label87, "label87");
            this.label87.Name = "label87";
            this.helpProvider1.SetShowHelp(this.label87, ((bool)(resources.GetObject("label87.ShowHelp"))));
            // 
            // label86
            // 
            resources.ApplyResources(this.label86, "label86");
            this.label86.Name = "label86";
            this.helpProvider1.SetShowHelp(this.label86, ((bool)(resources.GetObject("label86.ShowHelp"))));
            // 
            // label74
            // 
            resources.ApplyResources(this.label74, "label74");
            this.label74.BackColor = System.Drawing.Color.Transparent;
            this.label74.Name = "label74";
            this.helpProvider1.SetShowHelp(this.label74, ((bool)(resources.GetObject("label74.ShowHelp"))));
            // 
            // label75
            // 
            resources.ApplyResources(this.label75, "label75");
            this.label75.BackColor = System.Drawing.Color.Transparent;
            this.label75.Name = "label75";
            this.helpProvider1.SetShowHelp(this.label75, ((bool)(resources.GetObject("label75.ShowHelp"))));
            // 
            // label76
            // 
            resources.ApplyResources(this.label76, "label76");
            this.label76.BackColor = System.Drawing.Color.Transparent;
            this.label76.Name = "label76";
            this.helpProvider1.SetShowHelp(this.label76, ((bool)(resources.GetObject("label76.ShowHelp"))));
            // 
            // label77
            // 
            resources.ApplyResources(this.label77, "label77");
            this.label77.BackColor = System.Drawing.Color.Transparent;
            this.label77.Name = "label77";
            this.helpProvider1.SetShowHelp(this.label77, ((bool)(resources.GetObject("label77.ShowHelp"))));
            // 
            // label78
            // 
            resources.ApplyResources(this.label78, "label78");
            this.label78.BackColor = System.Drawing.Color.Transparent;
            this.label78.Name = "label78";
            this.helpProvider1.SetShowHelp(this.label78, ((bool)(resources.GetObject("label78.ShowHelp"))));
            // 
            // label79
            // 
            resources.ApplyResources(this.label79, "label79");
            this.label79.BackColor = System.Drawing.Color.Transparent;
            this.label79.Name = "label79";
            this.helpProvider1.SetShowHelp(this.label79, ((bool)(resources.GetObject("label79.ShowHelp"))));
            // 
            // label80
            // 
            resources.ApplyResources(this.label80, "label80");
            this.label80.BackColor = System.Drawing.Color.Transparent;
            this.label80.Name = "label80";
            this.helpProvider1.SetShowHelp(this.label80, ((bool)(resources.GetObject("label80.ShowHelp"))));
            // 
            // label81
            // 
            resources.ApplyResources(this.label81, "label81");
            this.label81.BackColor = System.Drawing.Color.Transparent;
            this.label81.Name = "label81";
            this.helpProvider1.SetShowHelp(this.label81, ((bool)(resources.GetObject("label81.ShowHelp"))));
            // 
            // label82
            // 
            resources.ApplyResources(this.label82, "label82");
            this.label82.BackColor = System.Drawing.Color.Transparent;
            this.label82.Name = "label82";
            this.helpProvider1.SetShowHelp(this.label82, ((bool)(resources.GetObject("label82.ShowHelp"))));
            // 
            // label83
            // 
            resources.ApplyResources(this.label83, "label83");
            this.label83.BackColor = System.Drawing.Color.Transparent;
            this.label83.Name = "label83";
            this.helpProvider1.SetShowHelp(this.label83, ((bool)(resources.GetObject("label83.ShowHelp"))));
            // 
            // label84
            // 
            resources.ApplyResources(this.label84, "label84");
            this.label84.BackColor = System.Drawing.Color.Transparent;
            this.label84.Name = "label84";
            this.helpProvider1.SetShowHelp(this.label84, ((bool)(resources.GetObject("label84.ShowHelp"))));
            // 
            // label85
            // 
            resources.ApplyResources(this.label85, "label85");
            this.label85.BackColor = System.Drawing.Color.Transparent;
            this.label85.Name = "label85";
            this.helpProvider1.SetShowHelp(this.label85, ((bool)(resources.GetObject("label85.ShowHelp"))));
            // 
            // label73
            // 
            resources.ApplyResources(this.label73, "label73");
            this.label73.BackColor = System.Drawing.Color.Transparent;
            this.label73.Name = "label73";
            this.helpProvider1.SetShowHelp(this.label73, ((bool)(resources.GetObject("label73.ShowHelp"))));
            // 
            // label72
            // 
            resources.ApplyResources(this.label72, "label72");
            this.label72.BackColor = System.Drawing.Color.Transparent;
            this.label72.Name = "label72";
            this.helpProvider1.SetShowHelp(this.label72, ((bool)(resources.GetObject("label72.ShowHelp"))));
            // 
            // label71
            // 
            resources.ApplyResources(this.label71, "label71");
            this.label71.BackColor = System.Drawing.Color.Transparent;
            this.label71.Name = "label71";
            this.helpProvider1.SetShowHelp(this.label71, ((bool)(resources.GetObject("label71.ShowHelp"))));
            // 
            // label60
            // 
            resources.ApplyResources(this.label60, "label60");
            this.label60.BackColor = System.Drawing.Color.Transparent;
            this.label60.Name = "label60";
            this.helpProvider1.SetShowHelp(this.label60, ((bool)(resources.GetObject("label60.ShowHelp"))));
            // 
            // label61
            // 
            resources.ApplyResources(this.label61, "label61");
            this.label61.BackColor = System.Drawing.Color.Transparent;
            this.label61.Name = "label61";
            this.helpProvider1.SetShowHelp(this.label61, ((bool)(resources.GetObject("label61.ShowHelp"))));
            // 
            // label62
            // 
            resources.ApplyResources(this.label62, "label62");
            this.label62.BackColor = System.Drawing.Color.Transparent;
            this.label62.Name = "label62";
            this.helpProvider1.SetShowHelp(this.label62, ((bool)(resources.GetObject("label62.ShowHelp"))));
            // 
            // label63
            // 
            resources.ApplyResources(this.label63, "label63");
            this.label63.BackColor = System.Drawing.Color.Transparent;
            this.label63.Name = "label63";
            this.helpProvider1.SetShowHelp(this.label63, ((bool)(resources.GetObject("label63.ShowHelp"))));
            // 
            // label64
            // 
            resources.ApplyResources(this.label64, "label64");
            this.label64.BackColor = System.Drawing.Color.Transparent;
            this.label64.Name = "label64";
            this.helpProvider1.SetShowHelp(this.label64, ((bool)(resources.GetObject("label64.ShowHelp"))));
            // 
            // label65
            // 
            resources.ApplyResources(this.label65, "label65");
            this.label65.BackColor = System.Drawing.Color.Transparent;
            this.label65.Name = "label65";
            this.helpProvider1.SetShowHelp(this.label65, ((bool)(resources.GetObject("label65.ShowHelp"))));
            // 
            // label66
            // 
            resources.ApplyResources(this.label66, "label66");
            this.label66.BackColor = System.Drawing.Color.Transparent;
            this.label66.Name = "label66";
            this.helpProvider1.SetShowHelp(this.label66, ((bool)(resources.GetObject("label66.ShowHelp"))));
            // 
            // label67
            // 
            resources.ApplyResources(this.label67, "label67");
            this.label67.BackColor = System.Drawing.Color.Transparent;
            this.label67.Name = "label67";
            this.helpProvider1.SetShowHelp(this.label67, ((bool)(resources.GetObject("label67.ShowHelp"))));
            // 
            // label68
            // 
            resources.ApplyResources(this.label68, "label68");
            this.label68.BackColor = System.Drawing.Color.Transparent;
            this.label68.Name = "label68";
            this.helpProvider1.SetShowHelp(this.label68, ((bool)(resources.GetObject("label68.ShowHelp"))));
            // 
            // label69
            // 
            resources.ApplyResources(this.label69, "label69");
            this.label69.BackColor = System.Drawing.Color.Transparent;
            this.label69.Name = "label69";
            this.helpProvider1.SetShowHelp(this.label69, ((bool)(resources.GetObject("label69.ShowHelp"))));
            // 
            // label70
            // 
            resources.ApplyResources(this.label70, "label70");
            this.label70.BackColor = System.Drawing.Color.Transparent;
            this.label70.Name = "label70";
            this.helpProvider1.SetShowHelp(this.label70, ((bool)(resources.GetObject("label70.ShowHelp"))));
            // 
            // label49
            // 
            resources.ApplyResources(this.label49, "label49");
            this.label49.BackColor = System.Drawing.Color.Transparent;
            this.label49.Name = "label49";
            this.helpProvider1.SetShowHelp(this.label49, ((bool)(resources.GetObject("label49.ShowHelp"))));
            // 
            // label50
            // 
            resources.ApplyResources(this.label50, "label50");
            this.label50.BackColor = System.Drawing.Color.Transparent;
            this.label50.Name = "label50";
            this.helpProvider1.SetShowHelp(this.label50, ((bool)(resources.GetObject("label50.ShowHelp"))));
            // 
            // label51
            // 
            resources.ApplyResources(this.label51, "label51");
            this.label51.BackColor = System.Drawing.Color.Transparent;
            this.label51.Name = "label51";
            this.helpProvider1.SetShowHelp(this.label51, ((bool)(resources.GetObject("label51.ShowHelp"))));
            // 
            // label52
            // 
            resources.ApplyResources(this.label52, "label52");
            this.label52.BackColor = System.Drawing.Color.Transparent;
            this.label52.Name = "label52";
            this.helpProvider1.SetShowHelp(this.label52, ((bool)(resources.GetObject("label52.ShowHelp"))));
            // 
            // label53
            // 
            resources.ApplyResources(this.label53, "label53");
            this.label53.BackColor = System.Drawing.Color.Transparent;
            this.label53.Name = "label53";
            this.helpProvider1.SetShowHelp(this.label53, ((bool)(resources.GetObject("label53.ShowHelp"))));
            // 
            // label54
            // 
            resources.ApplyResources(this.label54, "label54");
            this.label54.BackColor = System.Drawing.Color.Transparent;
            this.label54.Name = "label54";
            this.helpProvider1.SetShowHelp(this.label54, ((bool)(resources.GetObject("label54.ShowHelp"))));
            // 
            // label55
            // 
            resources.ApplyResources(this.label55, "label55");
            this.label55.BackColor = System.Drawing.Color.Transparent;
            this.label55.Name = "label55";
            this.helpProvider1.SetShowHelp(this.label55, ((bool)(resources.GetObject("label55.ShowHelp"))));
            // 
            // label56
            // 
            resources.ApplyResources(this.label56, "label56");
            this.label56.BackColor = System.Drawing.Color.Transparent;
            this.label56.Name = "label56";
            this.helpProvider1.SetShowHelp(this.label56, ((bool)(resources.GetObject("label56.ShowHelp"))));
            // 
            // label57
            // 
            resources.ApplyResources(this.label57, "label57");
            this.label57.BackColor = System.Drawing.Color.Transparent;
            this.label57.Name = "label57";
            this.helpProvider1.SetShowHelp(this.label57, ((bool)(resources.GetObject("label57.ShowHelp"))));
            // 
            // label58
            // 
            resources.ApplyResources(this.label58, "label58");
            this.label58.BackColor = System.Drawing.Color.Transparent;
            this.label58.Name = "label58";
            this.helpProvider1.SetShowHelp(this.label58, ((bool)(resources.GetObject("label58.ShowHelp"))));
            // 
            // label59
            // 
            resources.ApplyResources(this.label59, "label59");
            this.label59.BackColor = System.Drawing.Color.Transparent;
            this.label59.Name = "label59";
            this.helpProvider1.SetShowHelp(this.label59, ((bool)(resources.GetObject("label59.ShowHelp"))));
            // 
            // label38
            // 
            resources.ApplyResources(this.label38, "label38");
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Name = "label38";
            this.helpProvider1.SetShowHelp(this.label38, ((bool)(resources.GetObject("label38.ShowHelp"))));
            // 
            // label39
            // 
            resources.ApplyResources(this.label39, "label39");
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.Name = "label39";
            this.helpProvider1.SetShowHelp(this.label39, ((bool)(resources.GetObject("label39.ShowHelp"))));
            // 
            // label40
            // 
            resources.ApplyResources(this.label40, "label40");
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.Name = "label40";
            this.helpProvider1.SetShowHelp(this.label40, ((bool)(resources.GetObject("label40.ShowHelp"))));
            // 
            // label41
            // 
            resources.ApplyResources(this.label41, "label41");
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.Name = "label41";
            this.helpProvider1.SetShowHelp(this.label41, ((bool)(resources.GetObject("label41.ShowHelp"))));
            // 
            // label42
            // 
            resources.ApplyResources(this.label42, "label42");
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Name = "label42";
            this.helpProvider1.SetShowHelp(this.label42, ((bool)(resources.GetObject("label42.ShowHelp"))));
            // 
            // label43
            // 
            resources.ApplyResources(this.label43, "label43");
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Name = "label43";
            this.helpProvider1.SetShowHelp(this.label43, ((bool)(resources.GetObject("label43.ShowHelp"))));
            // 
            // label44
            // 
            resources.ApplyResources(this.label44, "label44");
            this.label44.BackColor = System.Drawing.Color.Transparent;
            this.label44.Name = "label44";
            this.helpProvider1.SetShowHelp(this.label44, ((bool)(resources.GetObject("label44.ShowHelp"))));
            // 
            // label45
            // 
            resources.ApplyResources(this.label45, "label45");
            this.label45.BackColor = System.Drawing.Color.Transparent;
            this.label45.Name = "label45";
            this.helpProvider1.SetShowHelp(this.label45, ((bool)(resources.GetObject("label45.ShowHelp"))));
            // 
            // label46
            // 
            resources.ApplyResources(this.label46, "label46");
            this.label46.BackColor = System.Drawing.Color.Transparent;
            this.label46.Name = "label46";
            this.helpProvider1.SetShowHelp(this.label46, ((bool)(resources.GetObject("label46.ShowHelp"))));
            // 
            // label47
            // 
            resources.ApplyResources(this.label47, "label47");
            this.label47.BackColor = System.Drawing.Color.Transparent;
            this.label47.Name = "label47";
            this.helpProvider1.SetShowHelp(this.label47, ((bool)(resources.GetObject("label47.ShowHelp"))));
            // 
            // label48
            // 
            resources.ApplyResources(this.label48, "label48");
            this.label48.BackColor = System.Drawing.Color.Transparent;
            this.label48.Name = "label48";
            this.helpProvider1.SetShowHelp(this.label48, ((bool)(resources.GetObject("label48.ShowHelp"))));
            // 
            // label37
            // 
            resources.ApplyResources(this.label37, "label37");
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Name = "label37";
            this.helpProvider1.SetShowHelp(this.label37, ((bool)(resources.GetObject("label37.ShowHelp"))));
            // 
            // label15
            // 
            resources.ApplyResources(this.label15, "label15");
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Name = "label15";
            this.helpProvider1.SetShowHelp(this.label15, ((bool)(resources.GetObject("label15.ShowHelp"))));
            // 
            // label27
            // 
            resources.ApplyResources(this.label27, "label27");
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Name = "label27";
            this.helpProvider1.SetShowHelp(this.label27, ((bool)(resources.GetObject("label27.ShowHelp"))));
            // 
            // label28
            // 
            resources.ApplyResources(this.label28, "label28");
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Name = "label28";
            this.helpProvider1.SetShowHelp(this.label28, ((bool)(resources.GetObject("label28.ShowHelp"))));
            // 
            // label29
            // 
            resources.ApplyResources(this.label29, "label29");
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Name = "label29";
            this.helpProvider1.SetShowHelp(this.label29, ((bool)(resources.GetObject("label29.ShowHelp"))));
            // 
            // label30
            // 
            resources.ApplyResources(this.label30, "label30");
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Name = "label30";
            this.helpProvider1.SetShowHelp(this.label30, ((bool)(resources.GetObject("label30.ShowHelp"))));
            // 
            // label31
            // 
            resources.ApplyResources(this.label31, "label31");
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.Name = "label31";
            this.helpProvider1.SetShowHelp(this.label31, ((bool)(resources.GetObject("label31.ShowHelp"))));
            // 
            // label32
            // 
            resources.ApplyResources(this.label32, "label32");
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Name = "label32";
            this.helpProvider1.SetShowHelp(this.label32, ((bool)(resources.GetObject("label32.ShowHelp"))));
            // 
            // label33
            // 
            resources.ApplyResources(this.label33, "label33");
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.Name = "label33";
            this.helpProvider1.SetShowHelp(this.label33, ((bool)(resources.GetObject("label33.ShowHelp"))));
            // 
            // label34
            // 
            resources.ApplyResources(this.label34, "label34");
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.Name = "label34";
            this.helpProvider1.SetShowHelp(this.label34, ((bool)(resources.GetObject("label34.ShowHelp"))));
            // 
            // label35
            // 
            resources.ApplyResources(this.label35, "label35");
            this.label35.BackColor = System.Drawing.Color.Transparent;
            this.label35.Name = "label35";
            this.helpProvider1.SetShowHelp(this.label35, ((bool)(resources.GetObject("label35.ShowHelp"))));
            // 
            // label36
            // 
            resources.ApplyResources(this.label36, "label36");
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.Name = "label36";
            this.helpProvider1.SetShowHelp(this.label36, ((bool)(resources.GetObject("label36.ShowHelp"))));
            // 
            // label24
            // 
            resources.ApplyResources(this.label24, "label24");
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Name = "label24";
            this.helpProvider1.SetShowHelp(this.label24, ((bool)(resources.GetObject("label24.ShowHelp"))));
            // 
            // label25
            // 
            resources.ApplyResources(this.label25, "label25");
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Name = "label25";
            this.helpProvider1.SetShowHelp(this.label25, ((bool)(resources.GetObject("label25.ShowHelp"))));
            // 
            // label26
            // 
            resources.ApplyResources(this.label26, "label26");
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Name = "label26";
            this.helpProvider1.SetShowHelp(this.label26, ((bool)(resources.GetObject("label26.ShowHelp"))));
            // 
            // label21
            // 
            resources.ApplyResources(this.label21, "label21");
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Name = "label21";
            this.helpProvider1.SetShowHelp(this.label21, ((bool)(resources.GetObject("label21.ShowHelp"))));
            // 
            // label22
            // 
            resources.ApplyResources(this.label22, "label22");
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Name = "label22";
            this.helpProvider1.SetShowHelp(this.label22, ((bool)(resources.GetObject("label22.ShowHelp"))));
            // 
            // label23
            // 
            resources.ApplyResources(this.label23, "label23");
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.Name = "label23";
            this.helpProvider1.SetShowHelp(this.label23, ((bool)(resources.GetObject("label23.ShowHelp"))));
            // 
            // label20
            // 
            resources.ApplyResources(this.label20, "label20");
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Name = "label20";
            this.helpProvider1.SetShowHelp(this.label20, ((bool)(resources.GetObject("label20.ShowHelp"))));
            // 
            // label18
            // 
            resources.ApplyResources(this.label18, "label18");
            this.label18.BackColor = System.Drawing.Color.Transparent;
            this.label18.Name = "label18";
            this.helpProvider1.SetShowHelp(this.label18, ((bool)(resources.GetObject("label18.ShowHelp"))));
            // 
            // label19
            // 
            resources.ApplyResources(this.label19, "label19");
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Name = "label19";
            this.helpProvider1.SetShowHelp(this.label19, ((bool)(resources.GetObject("label19.ShowHelp"))));
            // 
            // label17
            // 
            resources.ApplyResources(this.label17, "label17");
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Name = "label17";
            this.helpProvider1.SetShowHelp(this.label17, ((bool)(resources.GetObject("label17.ShowHelp"))));
            // 
            // label16
            // 
            resources.ApplyResources(this.label16, "label16");
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Name = "label16";
            this.helpProvider1.SetShowHelp(this.label16, ((bool)(resources.GetObject("label16.ShowHelp"))));
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            this.helpProvider1.SetShowHelp(this.label12, ((bool)(resources.GetObject("label12.ShowHelp"))));
            // 
            // label13
            // 
            resources.ApplyResources(this.label13, "label13");
            this.label13.Name = "label13";
            this.helpProvider1.SetShowHelp(this.label13, ((bool)(resources.GetObject("label13.ShowHelp"))));
            // 
            // label14
            // 
            resources.ApplyResources(this.label14, "label14");
            this.label14.Name = "label14";
            this.helpProvider1.SetShowHelp(this.label14, ((bool)(resources.GetObject("label14.ShowHelp"))));
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            this.helpProvider1.SetShowHelp(this.label9, ((bool)(resources.GetObject("label9.ShowHelp"))));
            // 
            // label10
            // 
            resources.ApplyResources(this.label10, "label10");
            this.label10.Name = "label10";
            this.helpProvider1.SetShowHelp(this.label10, ((bool)(resources.GetObject("label10.ShowHelp"))));
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            this.helpProvider1.SetShowHelp(this.label11, ((bool)(resources.GetObject("label11.ShowHelp"))));
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            this.helpProvider1.SetShowHelp(this.label8, ((bool)(resources.GetObject("label8.ShowHelp"))));
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            this.helpProvider1.SetShowHelp(this.label6, ((bool)(resources.GetObject("label6.ShowHelp"))));
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            this.helpProvider1.SetShowHelp(this.label7, ((bool)(resources.GetObject("label7.ShowHelp"))));
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            this.helpProvider1.SetShowHelp(this.label5, ((bool)(resources.GetObject("label5.ShowHelp"))));
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.Name = "label4";
            this.helpProvider1.SetShowHelp(this.label4, ((bool)(resources.GetObject("label4.ShowHelp"))));
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            this.helpProvider1.SetShowHelp(this.label2, ((bool)(resources.GetObject("label2.ShowHelp"))));
            // 
            // p1plus_18
            // 
            this.p1plus_18.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_18.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_18, "p1plus_18");
            this.p1plus_18.Name = "p1plus_18";
            this.p1plus_18.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_18, ((bool)(resources.GetObject("p1plus_18.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_18, resources.GetString("p1plus_18.ToolTip"));
            // 
            // p1r_18
            // 
            this.p1r_18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_18, "p1r_18");
            this.p1r_18.Name = "p1r_18";
            this.helpProvider1.SetShowHelp(this.p1r_18, ((bool)(resources.GetObject("p1r_18.ShowHelp"))));
            // 
            // p1ls_18
            // 
            this.p1ls_18.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_18.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_18, "p1ls_18");
            this.p1ls_18.Name = "p1ls_18";
            this.p1ls_18.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_18, ((bool)(resources.GetObject("p1ls_18.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_18, resources.GetString("p1ls_18.ToolTip"));
            // 
            // p1iws_18
            // 
            this.p1iws_18.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_18.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_18, "p1iws_18");
            this.p1iws_18.Name = "p1iws_18";
            this.p1iws_18.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_18, ((bool)(resources.GetObject("p1iws_18.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_18, resources.GetString("p1iws_18.ToolTip"));
            // 
            // p1ib_18
            // 
            this.p1ib_18.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_18.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_18, "p1ib_18");
            this.p1ib_18.Name = "p1ib_18";
            this.p1ib_18.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_18, ((bool)(resources.GetObject("p1ib_18.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_18, resources.GetString("p1ib_18.ToolTip"));
            // 
            // p1pm_18
            // 
            this.p1pm_18.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1pm_18.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_18, "p1pm_18");
            this.p1pm_18.Name = "p1pm_18";
            this.p1pm_18.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_18, ((bool)(resources.GetObject("p1pm_18.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_18, resources.GetString("p1pm_18.ToolTip"));
            // 
            // p1vw_18
            // 
            this.p1vw_18.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_18.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_18, "p1vw_18");
            this.p1vw_18.Name = "p1vw_18";
            this.p1vw_18.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_18, ((bool)(resources.GetObject("p1vw_18.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_18, resources.GetString("p1vw_18.ToolTip"));
            // 
            // p1plus_7
            // 
            this.p1plus_7.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_7.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_7, "p1plus_7");
            this.p1plus_7.Name = "p1plus_7";
            this.p1plus_7.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_7, ((bool)(resources.GetObject("p1plus_7.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_7, resources.GetString("p1plus_7.ToolTip"));
            // 
            // p1r_7
            // 
            this.p1r_7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_7, "p1r_7");
            this.p1r_7.Name = "p1r_7";
            this.helpProvider1.SetShowHelp(this.p1r_7, ((bool)(resources.GetObject("p1r_7.ShowHelp"))));
            // 
            // p1ls_7
            // 
            this.p1ls_7.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_7.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_7, "p1ls_7");
            this.p1ls_7.Name = "p1ls_7";
            this.p1ls_7.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_7, ((bool)(resources.GetObject("p1ls_7.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_7, resources.GetString("p1ls_7.ToolTip"));
            // 
            // p1iws_7
            // 
            this.p1iws_7.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_7.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_7, "p1iws_7");
            this.p1iws_7.Name = "p1iws_7";
            this.p1iws_7.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_7, ((bool)(resources.GetObject("p1iws_7.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_7, resources.GetString("p1iws_7.ToolTip"));
            // 
            // p1ib_7
            // 
            this.p1ib_7.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_7.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_7, "p1ib_7");
            this.p1ib_7.Name = "p1ib_7";
            this.p1ib_7.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_7, ((bool)(resources.GetObject("p1ib_7.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_7, resources.GetString("p1ib_7.ToolTip"));
            // 
            // p1pm_7
            // 
            this.p1pm_7.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1pm_7.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_7, "p1pm_7");
            this.p1pm_7.Name = "p1pm_7";
            this.p1pm_7.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_7, ((bool)(resources.GetObject("p1pm_7.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_7, resources.GetString("p1pm_7.ToolTip"));
            // 
            // p1vw_7
            // 
            this.p1vw_7.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_7.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_7, "p1vw_7");
            this.p1vw_7.Name = "p1vw_7";
            this.p1vw_7.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_7, ((bool)(resources.GetObject("p1vw_7.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_7, resources.GetString("p1vw_7.ToolTip"));
            // 
            // p1plus_13
            // 
            this.p1plus_13.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_13.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_13, "p1plus_13");
            this.p1plus_13.Name = "p1plus_13";
            this.p1plus_13.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_13, ((bool)(resources.GetObject("p1plus_13.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_13, resources.GetString("p1plus_13.ToolTip"));
            // 
            // p1r_13
            // 
            this.p1r_13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_13, "p1r_13");
            this.p1r_13.Name = "p1r_13";
            this.helpProvider1.SetShowHelp(this.p1r_13, ((bool)(resources.GetObject("p1r_13.ShowHelp"))));
            // 
            // p1ls_13
            // 
            this.p1ls_13.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_13.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_13, "p1ls_13");
            this.p1ls_13.Name = "p1ls_13";
            this.p1ls_13.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_13, ((bool)(resources.GetObject("p1ls_13.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_13, resources.GetString("p1ls_13.ToolTip"));
            // 
            // p1iws_13
            // 
            this.p1iws_13.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_13.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_13, "p1iws_13");
            this.p1iws_13.Name = "p1iws_13";
            this.p1iws_13.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_13, ((bool)(resources.GetObject("p1iws_13.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_13, resources.GetString("p1iws_13.ToolTip"));
            // 
            // p1ib_13
            // 
            this.p1ib_13.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_13.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_13, "p1ib_13");
            this.p1ib_13.Name = "p1ib_13";
            this.p1ib_13.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_13, ((bool)(resources.GetObject("p1ib_13.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_13, resources.GetString("p1ib_13.ToolTip"));
            // 
            // p1pm_13
            // 
            this.p1pm_13.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1pm_13.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_13, "p1pm_13");
            this.p1pm_13.Name = "p1pm_13";
            this.p1pm_13.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_13, ((bool)(resources.GetObject("p1pm_13.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_13, resources.GetString("p1pm_13.ToolTip"));
            // 
            // p1vw_13
            // 
            this.p1vw_13.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_13.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_13, "p1vw_13");
            this.p1vw_13.Name = "p1vw_13";
            this.p1vw_13.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_13, ((bool)(resources.GetObject("p1vw_13.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_13, resources.GetString("p1vw_13.ToolTip"));
            // 
            // p1plus_49
            // 
            this.p1plus_49.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_49.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_49, "p1plus_49");
            this.p1plus_49.Name = "p1plus_49";
            this.p1plus_49.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_49, ((bool)(resources.GetObject("p1plus_49.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_49, resources.GetString("p1plus_49.ToolTip"));
            // 
            // p1r_49
            // 
            this.p1r_49.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_49, "p1r_49");
            this.p1r_49.Name = "p1r_49";
            this.helpProvider1.SetShowHelp(this.p1r_49, ((bool)(resources.GetObject("p1r_49.ShowHelp"))));
            // 
            // p1ls_49
            // 
            this.p1ls_49.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_49.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_49, "p1ls_49");
            this.p1ls_49.Name = "p1ls_49";
            this.p1ls_49.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_49, ((bool)(resources.GetObject("p1ls_49.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_49, resources.GetString("p1ls_49.ToolTip"));
            // 
            // p1iws_49
            // 
            this.p1iws_49.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1iws_49.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_49, "p1iws_49");
            this.p1iws_49.Name = "p1iws_49";
            this.p1iws_49.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_49, ((bool)(resources.GetObject("p1iws_49.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_49, resources.GetString("p1iws_49.ToolTip"));
            // 
            // p1ib_49
            // 
            this.p1ib_49.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_49.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_49, "p1ib_49");
            this.p1ib_49.Name = "p1ib_49";
            this.p1ib_49.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_49, ((bool)(resources.GetObject("p1ib_49.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_49, resources.GetString("p1ib_49.ToolTip"));
            // 
            // p1pm_49
            // 
            this.p1pm_49.BackColor = System.Drawing.Color.MistyRose;
            this.p1pm_49.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_49, "p1pm_49");
            this.p1pm_49.Name = "p1pm_49";
            this.p1pm_49.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_49, ((bool)(resources.GetObject("p1pm_49.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_49, resources.GetString("p1pm_49.ToolTip"));
            // 
            // p1vw_49
            // 
            this.p1vw_49.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_49.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_49, "p1vw_49");
            this.p1vw_49.Name = "p1vw_49";
            this.p1vw_49.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_49, ((bool)(resources.GetObject("p1vw_49.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_49, resources.GetString("p1vw_49.ToolTip"));
            // 
            // p1plus_4
            // 
            this.p1plus_4.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_4.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_4, "p1plus_4");
            this.p1plus_4.Name = "p1plus_4";
            this.p1plus_4.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_4, ((bool)(resources.GetObject("p1plus_4.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_4, resources.GetString("p1plus_4.ToolTip"));
            // 
            // p1r_4
            // 
            this.p1r_4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_4, "p1r_4");
            this.p1r_4.Name = "p1r_4";
            this.helpProvider1.SetShowHelp(this.p1r_4, ((bool)(resources.GetObject("p1r_4.ShowHelp"))));
            // 
            // p1ls_4
            // 
            this.p1ls_4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_4.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_4, "p1ls_4");
            this.p1ls_4.Name = "p1ls_4";
            this.p1ls_4.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_4, ((bool)(resources.GetObject("p1ls_4.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_4, resources.GetString("p1ls_4.ToolTip"));
            // 
            // p1iws_4
            // 
            this.p1iws_4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_4.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_4, "p1iws_4");
            this.p1iws_4.Name = "p1iws_4";
            this.p1iws_4.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_4, ((bool)(resources.GetObject("p1iws_4.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_4, resources.GetString("p1iws_4.ToolTip"));
            // 
            // p1ib_4
            // 
            this.p1ib_4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_4.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_4, "p1ib_4");
            this.p1ib_4.Name = "p1ib_4";
            this.p1ib_4.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_4, ((bool)(resources.GetObject("p1ib_4.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_4, resources.GetString("p1ib_4.ToolTip"));
            // 
            // p1pm_4
            // 
            this.p1pm_4.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1pm_4.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_4, "p1pm_4");
            this.p1pm_4.Name = "p1pm_4";
            this.p1pm_4.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_4, ((bool)(resources.GetObject("p1pm_4.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_4, resources.GetString("p1pm_4.ToolTip"));
            // 
            // p1vw_4
            // 
            this.p1vw_4.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_4.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_4, "p1vw_4");
            this.p1vw_4.Name = "p1vw_4";
            this.p1vw_4.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_4, ((bool)(resources.GetObject("p1vw_4.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_4, resources.GetString("p1vw_4.ToolTip"));
            // 
            // p1plus_10
            // 
            this.p1plus_10.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_10.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_10, "p1plus_10");
            this.p1plus_10.Name = "p1plus_10";
            this.p1plus_10.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_10, ((bool)(resources.GetObject("p1plus_10.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_10, resources.GetString("p1plus_10.ToolTip"));
            // 
            // p1r_10
            // 
            this.p1r_10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_10, "p1r_10");
            this.p1r_10.Name = "p1r_10";
            this.helpProvider1.SetShowHelp(this.p1r_10, ((bool)(resources.GetObject("p1r_10.ShowHelp"))));
            // 
            // p1ls_10
            // 
            this.p1ls_10.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_10.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_10, "p1ls_10");
            this.p1ls_10.Name = "p1ls_10";
            this.p1ls_10.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_10, ((bool)(resources.GetObject("p1ls_10.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_10, resources.GetString("p1ls_10.ToolTip"));
            // 
            // p1iws_10
            // 
            this.p1iws_10.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_10.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_10, "p1iws_10");
            this.p1iws_10.Name = "p1iws_10";
            this.p1iws_10.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_10, ((bool)(resources.GetObject("p1iws_10.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_10, resources.GetString("p1iws_10.ToolTip"));
            // 
            // p1ib_10
            // 
            this.p1ib_10.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_10.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_10, "p1ib_10");
            this.p1ib_10.Name = "p1ib_10";
            this.p1ib_10.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_10, ((bool)(resources.GetObject("p1ib_10.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_10, resources.GetString("p1ib_10.ToolTip"));
            // 
            // p1pm_10
            // 
            this.p1pm_10.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1pm_10.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_10, "p1pm_10");
            this.p1pm_10.Name = "p1pm_10";
            this.p1pm_10.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_10, ((bool)(resources.GetObject("p1pm_10.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_10, resources.GetString("p1pm_10.ToolTip"));
            // 
            // p1vw_10
            // 
            this.p1vw_10.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_10.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_10, "p1vw_10");
            this.p1vw_10.Name = "p1vw_10";
            this.p1vw_10.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_10, ((bool)(resources.GetObject("p1vw_10.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_10, resources.GetString("p1vw_10.ToolTip"));
            // 
            // p1plus_50
            // 
            this.p1plus_50.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_50.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_50, "p1plus_50");
            this.p1plus_50.Name = "p1plus_50";
            this.p1plus_50.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_50, ((bool)(resources.GetObject("p1plus_50.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_50, resources.GetString("p1plus_50.ToolTip"));
            // 
            // p1r_50
            // 
            this.p1r_50.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_50, "p1r_50");
            this.p1r_50.Name = "p1r_50";
            this.helpProvider1.SetShowHelp(this.p1r_50, ((bool)(resources.GetObject("p1r_50.ShowHelp"))));
            // 
            // p1ls_50
            // 
            this.p1ls_50.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_50.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_50, "p1ls_50");
            this.p1ls_50.Name = "p1ls_50";
            this.p1ls_50.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_50, ((bool)(resources.GetObject("p1ls_50.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_50, resources.GetString("p1ls_50.ToolTip"));
            // 
            // p1iws_50
            // 
            this.p1iws_50.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1iws_50.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_50, "p1iws_50");
            this.p1iws_50.Name = "p1iws_50";
            this.p1iws_50.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_50, ((bool)(resources.GetObject("p1iws_50.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_50, resources.GetString("p1iws_50.ToolTip"));
            // 
            // p1ib_50
            // 
            this.p1ib_50.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_50.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_50, "p1ib_50");
            this.p1ib_50.Name = "p1ib_50";
            this.p1ib_50.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_50, ((bool)(resources.GetObject("p1ib_50.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_50, resources.GetString("p1ib_50.ToolTip"));
            // 
            // p1pm_50
            // 
            this.p1pm_50.BackColor = System.Drawing.Color.MistyRose;
            this.p1pm_50.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_50, "p1pm_50");
            this.p1pm_50.Name = "p1pm_50";
            this.p1pm_50.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_50, ((bool)(resources.GetObject("p1pm_50.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_50, resources.GetString("p1pm_50.ToolTip"));
            // 
            // p1vw_50
            // 
            this.p1vw_50.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_50.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_50, "p1vw_50");
            this.p1vw_50.Name = "p1vw_50";
            this.p1vw_50.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_50, ((bool)(resources.GetObject("p1vw_50.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_50, resources.GetString("p1vw_50.ToolTip"));
            // 
            // p1plus_16
            // 
            this.p1plus_16.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_16, "p1plus_16");
            this.p1plus_16.Name = "p1plus_16";
            this.p1plus_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_16, ((bool)(resources.GetObject("p1plus_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_16, resources.GetString("p1plus_16.ToolTip"));
            // 
            // p1r_16
            // 
            this.p1r_16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_16, "p1r_16");
            this.p1r_16.Name = "p1r_16";
            this.helpProvider1.SetShowHelp(this.p1r_16, ((bool)(resources.GetObject("p1r_16.ShowHelp"))));
            // 
            // p1ls_16
            // 
            this.p1ls_16.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_16, "p1ls_16");
            this.p1ls_16.Name = "p1ls_16";
            this.p1ls_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_16, ((bool)(resources.GetObject("p1ls_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_16, resources.GetString("p1ls_16.ToolTip"));
            // 
            // p1iws_16
            // 
            this.p1iws_16.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_16, "p1iws_16");
            this.p1iws_16.Name = "p1iws_16";
            this.p1iws_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_16, ((bool)(resources.GetObject("p1iws_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_16, resources.GetString("p1iws_16.ToolTip"));
            // 
            // p1ib_16
            // 
            this.p1ib_16.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_16, "p1ib_16");
            this.p1ib_16.Name = "p1ib_16";
            this.p1ib_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_16, ((bool)(resources.GetObject("p1ib_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_16, resources.GetString("p1ib_16.ToolTip"));
            // 
            // p1pm_16
            // 
            this.p1pm_16.BackColor = System.Drawing.Color.LemonChiffon;
            this.p1pm_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_16, "p1pm_16");
            this.p1pm_16.Name = "p1pm_16";
            this.p1pm_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_16, ((bool)(resources.GetObject("p1pm_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_16, resources.GetString("p1pm_16.ToolTip"));
            // 
            // p1vw_16
            // 
            this.p1vw_16.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_16, "p1vw_16");
            this.p1vw_16.Name = "p1vw_16";
            this.p1vw_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_16, ((bool)(resources.GetObject("p1vw_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_16, resources.GetString("p1vw_16.ToolTip"));
            // 
            // p1plus_17
            // 
            this.p1plus_17.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_17, "p1plus_17");
            this.p1plus_17.Name = "p1plus_17";
            this.p1plus_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_17, ((bool)(resources.GetObject("p1plus_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_17, resources.GetString("p1plus_17.ToolTip"));
            // 
            // p1r_17
            // 
            this.p1r_17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_17, "p1r_17");
            this.p1r_17.Name = "p1r_17";
            this.helpProvider1.SetShowHelp(this.p1r_17, ((bool)(resources.GetObject("p1r_17.ShowHelp"))));
            // 
            // p1ls_17
            // 
            this.p1ls_17.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_17, "p1ls_17");
            this.p1ls_17.Name = "p1ls_17";
            this.p1ls_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_17, ((bool)(resources.GetObject("p1ls_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_17, resources.GetString("p1ls_17.ToolTip"));
            // 
            // p1iws_17
            // 
            this.p1iws_17.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_17, "p1iws_17");
            this.p1iws_17.Name = "p1iws_17";
            this.p1iws_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_17, ((bool)(resources.GetObject("p1iws_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_17, resources.GetString("p1iws_17.ToolTip"));
            // 
            // p1ib_17
            // 
            this.p1ib_17.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_17, "p1ib_17");
            this.p1ib_17.Name = "p1ib_17";
            this.p1ib_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_17, ((bool)(resources.GetObject("p1ib_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_17, resources.GetString("p1ib_17.ToolTip"));
            // 
            // p1pm_17
            // 
            this.p1pm_17.BackColor = System.Drawing.Color.LemonChiffon;
            this.p1pm_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_17, "p1pm_17");
            this.p1pm_17.Name = "p1pm_17";
            this.p1pm_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_17, ((bool)(resources.GetObject("p1pm_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_17, resources.GetString("p1pm_17.ToolTip"));
            // 
            // p1vw_17
            // 
            this.p1vw_17.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_17, "p1vw_17");
            this.p1vw_17.Name = "p1vw_17";
            this.p1vw_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_17, ((bool)(resources.GetObject("p1vw_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_17, resources.GetString("p1vw_17.ToolTip"));
            // 
            // p1plus_26
            // 
            this.p1plus_26.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_26, "p1plus_26");
            this.p1plus_26.Name = "p1plus_26";
            this.p1plus_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_26, ((bool)(resources.GetObject("p1plus_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_26, resources.GetString("p1plus_26.ToolTip"));
            // 
            // p1r_26
            // 
            this.p1r_26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_26, "p1r_26");
            this.p1r_26.Name = "p1r_26";
            this.helpProvider1.SetShowHelp(this.p1r_26, ((bool)(resources.GetObject("p1r_26.ShowHelp"))));
            // 
            // p1ls_26
            // 
            this.p1ls_26.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_26, "p1ls_26");
            this.p1ls_26.Name = "p1ls_26";
            this.p1ls_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_26, ((bool)(resources.GetObject("p1ls_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_26, resources.GetString("p1ls_26.ToolTip"));
            // 
            // p1iws_26
            // 
            this.p1iws_26.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1iws_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_26, "p1iws_26");
            this.p1iws_26.Name = "p1iws_26";
            this.p1iws_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_26, ((bool)(resources.GetObject("p1iws_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_26, resources.GetString("p1iws_26.ToolTip"));
            // 
            // p1ib_26
            // 
            this.p1ib_26.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_26, "p1ib_26");
            this.p1ib_26.Name = "p1ib_26";
            this.p1ib_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_26, ((bool)(resources.GetObject("p1ib_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_26, resources.GetString("p1ib_26.ToolTip"));
            // 
            // p1pm_26
            // 
            this.p1pm_26.BackColor = System.Drawing.Color.LemonChiffon;
            this.p1pm_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_26, "p1pm_26");
            this.p1pm_26.Name = "p1pm_26";
            this.p1pm_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_26, ((bool)(resources.GetObject("p1pm_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_26, resources.GetString("p1pm_26.ToolTip"));
            // 
            // p1vw_26
            // 
            this.p1vw_26.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_26, "p1vw_26");
            this.p1vw_26.Name = "p1vw_26";
            this.p1vw_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_26, ((bool)(resources.GetObject("p1vw_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_26, resources.GetString("p1vw_26.ToolTip"));
            // 
            // p1plus_51
            // 
            this.p1plus_51.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1plus_51.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1plus_51, "p1plus_51");
            this.p1plus_51.Name = "p1plus_51";
            this.p1plus_51.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1plus_51, ((bool)(resources.GetObject("p1plus_51.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1plus_51, resources.GetString("p1plus_51.ToolTip"));
            // 
            // p1r_51
            // 
            this.p1r_51.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_51, "p1r_51");
            this.p1r_51.Name = "p1r_51";
            this.helpProvider1.SetShowHelp(this.p1r_51, ((bool)(resources.GetObject("p1r_51.ShowHelp"))));
            // 
            // p1ls_51
            // 
            this.p1ls_51.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_51.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_51, "p1ls_51");
            this.p1ls_51.Name = "p1ls_51";
            this.p1ls_51.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_51, ((bool)(resources.GetObject("p1ls_51.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_51, resources.GetString("p1ls_51.ToolTip"));
            // 
            // p1iws_51
            // 
            this.p1iws_51.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1iws_51.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_51, "p1iws_51");
            this.p1iws_51.Name = "p1iws_51";
            this.p1iws_51.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_51, ((bool)(resources.GetObject("p1iws_51.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_51, resources.GetString("p1iws_51.ToolTip"));
            // 
            // p1ib_51
            // 
            this.p1ib_51.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_51.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_51, "p1ib_51");
            this.p1ib_51.Name = "p1ib_51";
            this.p1ib_51.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_51, ((bool)(resources.GetObject("p1ib_51.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_51, resources.GetString("p1ib_51.ToolTip"));
            // 
            // p1pm_51
            // 
            this.p1pm_51.BackColor = System.Drawing.Color.MistyRose;
            this.p1pm_51.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_51, "p1pm_51");
            this.p1pm_51.Name = "p1pm_51";
            this.p1pm_51.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_51, ((bool)(resources.GetObject("p1pm_51.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_51, resources.GetString("p1pm_51.ToolTip"));
            // 
            // p1vw_51
            // 
            this.p1vw_51.BackColor = System.Drawing.Color.MistyRose;
            this.p1vw_51.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1vw_51, "p1vw_51");
            this.p1vw_51.Name = "p1vw_51";
            this.p1vw_51.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1vw_51, ((bool)(resources.GetObject("p1vw_51.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1vw_51, resources.GetString("p1vw_51.ToolTip"));
            // 
            // p1r_0
            // 
            this.p1r_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1r_0, "p1r_0");
            this.p1r_0.Name = "p1r_0";
            this.helpProvider1.SetShowHelp(this.p1r_0, ((bool)(resources.GetObject("p1r_0.ShowHelp"))));
            // 
            // p1ls_0
            // 
            this.p1ls_0.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ls_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ls_0, "p1ls_0");
            this.p1ls_0.Name = "p1ls_0";
            this.p1ls_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ls_0, ((bool)(resources.GetObject("p1ls_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ls_0, resources.GetString("p1ls_0.ToolTip"));
            // 
            // p1iws_0
            // 
            this.p1iws_0.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p1iws_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1iws_0, "p1iws_0");
            this.p1iws_0.Name = "p1iws_0";
            this.p1iws_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1iws_0, ((bool)(resources.GetObject("p1iws_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1iws_0, resources.GetString("p1iws_0.ToolTip"));
            // 
            // p1ib_0
            // 
            this.p1ib_0.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p1ib_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1ib_0, "p1ib_0");
            this.p1ib_0.Name = "p1ib_0";
            this.p1ib_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1ib_0, ((bool)(resources.GetObject("p1ib_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1ib_0, resources.GetString("p1ib_0.ToolTip"));
            // 
            // p1pm_0
            // 
            this.p1pm_0.BackColor = System.Drawing.Color.MistyRose;
            this.p1pm_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p1pm_0, "p1pm_0");
            this.p1pm_0.Name = "p1pm_0";
            this.p1pm_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p1pm_0, ((bool)(resources.GetObject("p1pm_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p1pm_0, resources.GetString("p1pm_0.ToolTip"));
            // 
            // p1vw_0
            // 
            this.p1vw_0.BackColor = System.Drawing.Color.LightYellow;
            this.p1vw_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p1vw_0, "p1vw_0");
            this.p1vw_0.Name = "p1vw_0";
            this.helpProvider1.SetShowHelp(this.p1vw_0, ((bool)(resources.GetObject("p1vw_0.ShowHelp"))));
            // 
            // p1ETAusfueren
            // 
            this.p1ETAusfueren.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.p1ETAusfueren, "p1ETAusfueren");
            this.p1ETAusfueren.Name = "p1ETAusfueren";
            this.helpProvider1.SetShowHelp(this.p1ETAusfueren, ((bool)(resources.GetObject("p1ETAusfueren.ShowHelp"))));
            this.p1ETAusfueren.TabStop = false;
            this.toolTip.SetToolTip(this.p1ETAusfueren, resources.GetString("p1ETAusfueren.ToolTip"));
            this.p1ETAusfueren.Click += new System.EventHandler(this.p1ETAusfueren_Click);
            // 
            // tab_P2
            // 
            this.tab_P2.BackColor = System.Drawing.Color.Transparent;
            this.tab_P2.Controls.Add(this.panel2);
            resources.ApplyResources(this.tab_P2, "tab_P2");
            this.tab_P2.Name = "tab_P2";
            this.helpProvider1.SetShowHelp(this.tab_P2, ((bool)(resources.GetObject("tab_P2.ShowHelp"))));
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.p2ETAusfueren);
            this.panel2.Controls.Add(this.label92);
            this.panel2.Controls.Add(this.label93);
            this.panel2.Controls.Add(this.label94);
            this.panel2.Controls.Add(this.label95);
            this.panel2.Controls.Add(this.label96);
            this.panel2.Controls.Add(this.label97);
            this.panel2.Controls.Add(this.label98);
            this.panel2.Controls.Add(this.label99);
            this.panel2.Controls.Add(this.label100);
            this.panel2.Controls.Add(this.label101);
            this.panel2.Controls.Add(this.label102);
            this.panel2.Controls.Add(this.label103);
            this.panel2.Controls.Add(this.label104);
            this.panel2.Controls.Add(this.label105);
            this.panel2.Controls.Add(this.label106);
            this.panel2.Controls.Add(this.label107);
            this.panel2.Controls.Add(this.label108);
            this.panel2.Controls.Add(this.label109);
            this.panel2.Controls.Add(this.label110);
            this.panel2.Controls.Add(this.label111);
            this.panel2.Controls.Add(this.label112);
            this.panel2.Controls.Add(this.label113);
            this.panel2.Controls.Add(this.label114);
            this.panel2.Controls.Add(this.label115);
            this.panel2.Controls.Add(this.label116);
            this.panel2.Controls.Add(this.label117);
            this.panel2.Controls.Add(this.label118);
            this.panel2.Controls.Add(this.label119);
            this.panel2.Controls.Add(this.label120);
            this.panel2.Controls.Add(this.label121);
            this.panel2.Controls.Add(this.label122);
            this.panel2.Controls.Add(this.label123);
            this.panel2.Controls.Add(this.label124);
            this.panel2.Controls.Add(this.label125);
            this.panel2.Controls.Add(this.label126);
            this.panel2.Controls.Add(this.label127);
            this.panel2.Controls.Add(this.label128);
            this.panel2.Controls.Add(this.label129);
            this.panel2.Controls.Add(this.label130);
            this.panel2.Controls.Add(this.label131);
            this.panel2.Controls.Add(this.label132);
            this.panel2.Controls.Add(this.label133);
            this.panel2.Controls.Add(this.label134);
            this.panel2.Controls.Add(this.label135);
            this.panel2.Controls.Add(this.label136);
            this.panel2.Controls.Add(this.label137);
            this.panel2.Controls.Add(this.label138);
            this.panel2.Controls.Add(this.label139);
            this.panel2.Controls.Add(this.label140);
            this.panel2.Controls.Add(this.label141);
            this.panel2.Controls.Add(this.label142);
            this.panel2.Controls.Add(this.label143);
            this.panel2.Controls.Add(this.label144);
            this.panel2.Controls.Add(this.label145);
            this.panel2.Controls.Add(this.label146);
            this.panel2.Controls.Add(this.label147);
            this.panel2.Controls.Add(this.label148);
            this.panel2.Controls.Add(this.label149);
            this.panel2.Controls.Add(this.label150);
            this.panel2.Controls.Add(this.label151);
            this.panel2.Controls.Add(this.label152);
            this.panel2.Controls.Add(this.label153);
            this.panel2.Controls.Add(this.label154);
            this.panel2.Controls.Add(this.label155);
            this.panel2.Controls.Add(this.label156);
            this.panel2.Controls.Add(this.label157);
            this.panel2.Controls.Add(this.label158);
            this.panel2.Controls.Add(this.label159);
            this.panel2.Controls.Add(this.label160);
            this.panel2.Controls.Add(this.label161);
            this.panel2.Controls.Add(this.label162);
            this.panel2.Controls.Add(this.label163);
            this.panel2.Controls.Add(this.label164);
            this.panel2.Controls.Add(this.label165);
            this.panel2.Controls.Add(this.label166);
            this.panel2.Controls.Add(this.label167);
            this.panel2.Controls.Add(this.label168);
            this.panel2.Controls.Add(this.label169);
            this.panel2.Controls.Add(this.label170);
            this.panel2.Controls.Add(this.label171);
            this.panel2.Controls.Add(this.label172);
            this.panel2.Controls.Add(this.label173);
            this.panel2.Controls.Add(this.label174);
            this.panel2.Controls.Add(this.label175);
            this.panel2.Controls.Add(this.label176);
            this.panel2.Controls.Add(this.label177);
            this.panel2.Controls.Add(this.label178);
            this.panel2.Controls.Add(this.label179);
            this.panel2.Controls.Add(this.label180);
            this.panel2.Controls.Add(this.p2plus_19);
            this.panel2.Controls.Add(this.p2r_19);
            this.panel2.Controls.Add(this.p2ls_19);
            this.panel2.Controls.Add(this.p2iws_19);
            this.panel2.Controls.Add(this.p2ib_19);
            this.panel2.Controls.Add(this.p2pm_19);
            this.panel2.Controls.Add(this.p2vw_19);
            this.panel2.Controls.Add(this.p2plus_8);
            this.panel2.Controls.Add(this.p2r_8);
            this.panel2.Controls.Add(this.p2ls_8);
            this.panel2.Controls.Add(this.p2iws_8);
            this.panel2.Controls.Add(this.p2ib_8);
            this.panel2.Controls.Add(this.p2pm_8);
            this.panel2.Controls.Add(this.p2vw_8);
            this.panel2.Controls.Add(this.p2plus_14);
            this.panel2.Controls.Add(this.p2r_14);
            this.panel2.Controls.Add(this.p2ls_14);
            this.panel2.Controls.Add(this.p2iws_14);
            this.panel2.Controls.Add(this.p2ib_14);
            this.panel2.Controls.Add(this.p2pm_14);
            this.panel2.Controls.Add(this.p2vw_14);
            this.panel2.Controls.Add(this.p2plus_54);
            this.panel2.Controls.Add(this.p2r_54);
            this.panel2.Controls.Add(this.p2ls_54);
            this.panel2.Controls.Add(this.p2iws_54);
            this.panel2.Controls.Add(this.p2ib_54);
            this.panel2.Controls.Add(this.p2pm_54);
            this.panel2.Controls.Add(this.p2vw_54);
            this.panel2.Controls.Add(this.p2plus_5);
            this.panel2.Controls.Add(this.p2r_5);
            this.panel2.Controls.Add(this.p2ls_5);
            this.panel2.Controls.Add(this.p2iws_5);
            this.panel2.Controls.Add(this.p2ib_5);
            this.panel2.Controls.Add(this.p2pm_5);
            this.panel2.Controls.Add(this.p2vw_5);
            this.panel2.Controls.Add(this.p2plus_11);
            this.panel2.Controls.Add(this.p2r_11);
            this.panel2.Controls.Add(this.p2ls_11);
            this.panel2.Controls.Add(this.p2iws_11);
            this.panel2.Controls.Add(this.p2ib_11);
            this.panel2.Controls.Add(this.p2pm_11);
            this.panel2.Controls.Add(this.p2vw_11);
            this.panel2.Controls.Add(this.p2plus_55);
            this.panel2.Controls.Add(this.p2r_55);
            this.panel2.Controls.Add(this.p2ls_55);
            this.panel2.Controls.Add(this.p2iws_55);
            this.panel2.Controls.Add(this.p2ib_55);
            this.panel2.Controls.Add(this.p2pm_55);
            this.panel2.Controls.Add(this.p2vw_55);
            this.panel2.Controls.Add(this.p2plus_16);
            this.panel2.Controls.Add(this.p2r_16);
            this.panel2.Controls.Add(this.p2ls_16);
            this.panel2.Controls.Add(this.p2iws_16);
            this.panel2.Controls.Add(this.p2ib_16);
            this.panel2.Controls.Add(this.p2pm_16);
            this.panel2.Controls.Add(this.p2vw_16);
            this.panel2.Controls.Add(this.p2plus_17);
            this.panel2.Controls.Add(this.p2r_17);
            this.panel2.Controls.Add(this.p2ls_17);
            this.panel2.Controls.Add(this.p2iws_17);
            this.panel2.Controls.Add(this.p2ib_17);
            this.panel2.Controls.Add(this.p2pm_17);
            this.panel2.Controls.Add(this.p2vw_17);
            this.panel2.Controls.Add(this.p2plus_26);
            this.panel2.Controls.Add(this.p2r_26);
            this.panel2.Controls.Add(this.p2ls_26);
            this.panel2.Controls.Add(this.p2iws_26);
            this.panel2.Controls.Add(this.p2ib_26);
            this.panel2.Controls.Add(this.p2pm_26);
            this.panel2.Controls.Add(this.p2vw_26);
            this.panel2.Controls.Add(this.p2plus_56);
            this.panel2.Controls.Add(this.p2r_56);
            this.panel2.Controls.Add(this.p2ls_56);
            this.panel2.Controls.Add(this.p2iws_56);
            this.panel2.Controls.Add(this.p2ib_56);
            this.panel2.Controls.Add(this.p2pm_56);
            this.panel2.Controls.Add(this.p2vw_56);
            this.panel2.Controls.Add(this.p2r_0);
            this.panel2.Controls.Add(this.p2ls_0);
            this.panel2.Controls.Add(this.p2iws_0);
            this.panel2.Controls.Add(this.p2ib_0);
            this.panel2.Controls.Add(this.p2pm_0);
            this.panel2.Controls.Add(this.p2vw_0);
            this.panel2.Cursor = System.Windows.Forms.Cursors.Default;
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Name = "panel2";
            this.helpProvider1.SetShowHelp(this.panel2, ((bool)(resources.GetObject("panel2.ShowHelp"))));
            this.toolTip.SetToolTip(this.panel2, resources.GetString("panel2.ToolTip"));
            // 
            // p2ETAusfueren
            // 
            this.p2ETAusfueren.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.p2ETAusfueren, "p2ETAusfueren");
            this.p2ETAusfueren.Name = "p2ETAusfueren";
            this.helpProvider1.SetShowHelp(this.p2ETAusfueren, ((bool)(resources.GetObject("p2ETAusfueren.ShowHelp"))));
            this.p2ETAusfueren.TabStop = false;
            this.toolTip.SetToolTip(this.p2ETAusfueren, resources.GetString("p2ETAusfueren.ToolTip"));
            this.p2ETAusfueren.Click += new System.EventHandler(this.p2ETAusfueren_Click);
            // 
            // label92
            // 
            resources.ApplyResources(this.label92, "label92");
            this.label92.Name = "label92";
            this.helpProvider1.SetShowHelp(this.label92, ((bool)(resources.GetObject("label92.ShowHelp"))));
            // 
            // label93
            // 
            resources.ApplyResources(this.label93, "label93");
            this.label93.Name = "label93";
            this.helpProvider1.SetShowHelp(this.label93, ((bool)(resources.GetObject("label93.ShowHelp"))));
            // 
            // label94
            // 
            resources.ApplyResources(this.label94, "label94");
            this.label94.Name = "label94";
            this.helpProvider1.SetShowHelp(this.label94, ((bool)(resources.GetObject("label94.ShowHelp"))));
            // 
            // label95
            // 
            resources.ApplyResources(this.label95, "label95");
            this.label95.Name = "label95";
            this.helpProvider1.SetShowHelp(this.label95, ((bool)(resources.GetObject("label95.ShowHelp"))));
            // 
            // label96
            // 
            resources.ApplyResources(this.label96, "label96");
            this.label96.Name = "label96";
            this.helpProvider1.SetShowHelp(this.label96, ((bool)(resources.GetObject("label96.ShowHelp"))));
            // 
            // label97
            // 
            resources.ApplyResources(this.label97, "label97");
            this.label97.Name = "label97";
            this.helpProvider1.SetShowHelp(this.label97, ((bool)(resources.GetObject("label97.ShowHelp"))));
            // 
            // label98
            // 
            resources.ApplyResources(this.label98, "label98");
            this.label98.BackColor = System.Drawing.Color.Transparent;
            this.label98.Name = "label98";
            this.helpProvider1.SetShowHelp(this.label98, ((bool)(resources.GetObject("label98.ShowHelp"))));
            // 
            // label99
            // 
            resources.ApplyResources(this.label99, "label99");
            this.label99.BackColor = System.Drawing.Color.Transparent;
            this.label99.Name = "label99";
            this.helpProvider1.SetShowHelp(this.label99, ((bool)(resources.GetObject("label99.ShowHelp"))));
            // 
            // label100
            // 
            resources.ApplyResources(this.label100, "label100");
            this.label100.BackColor = System.Drawing.Color.Transparent;
            this.label100.Name = "label100";
            this.helpProvider1.SetShowHelp(this.label100, ((bool)(resources.GetObject("label100.ShowHelp"))));
            // 
            // label101
            // 
            resources.ApplyResources(this.label101, "label101");
            this.label101.BackColor = System.Drawing.Color.Transparent;
            this.label101.Name = "label101";
            this.helpProvider1.SetShowHelp(this.label101, ((bool)(resources.GetObject("label101.ShowHelp"))));
            // 
            // label102
            // 
            resources.ApplyResources(this.label102, "label102");
            this.label102.BackColor = System.Drawing.Color.Transparent;
            this.label102.Name = "label102";
            this.helpProvider1.SetShowHelp(this.label102, ((bool)(resources.GetObject("label102.ShowHelp"))));
            // 
            // label103
            // 
            resources.ApplyResources(this.label103, "label103");
            this.label103.BackColor = System.Drawing.Color.Transparent;
            this.label103.Name = "label103";
            this.helpProvider1.SetShowHelp(this.label103, ((bool)(resources.GetObject("label103.ShowHelp"))));
            // 
            // label104
            // 
            resources.ApplyResources(this.label104, "label104");
            this.label104.BackColor = System.Drawing.Color.Transparent;
            this.label104.Name = "label104";
            this.helpProvider1.SetShowHelp(this.label104, ((bool)(resources.GetObject("label104.ShowHelp"))));
            // 
            // label105
            // 
            resources.ApplyResources(this.label105, "label105");
            this.label105.BackColor = System.Drawing.Color.Transparent;
            this.label105.Name = "label105";
            this.helpProvider1.SetShowHelp(this.label105, ((bool)(resources.GetObject("label105.ShowHelp"))));
            // 
            // label106
            // 
            resources.ApplyResources(this.label106, "label106");
            this.label106.BackColor = System.Drawing.Color.Transparent;
            this.label106.Name = "label106";
            this.helpProvider1.SetShowHelp(this.label106, ((bool)(resources.GetObject("label106.ShowHelp"))));
            // 
            // label107
            // 
            resources.ApplyResources(this.label107, "label107");
            this.label107.BackColor = System.Drawing.Color.Transparent;
            this.label107.Name = "label107";
            this.helpProvider1.SetShowHelp(this.label107, ((bool)(resources.GetObject("label107.ShowHelp"))));
            // 
            // label108
            // 
            resources.ApplyResources(this.label108, "label108");
            this.label108.BackColor = System.Drawing.Color.Transparent;
            this.label108.Name = "label108";
            this.helpProvider1.SetShowHelp(this.label108, ((bool)(resources.GetObject("label108.ShowHelp"))));
            // 
            // label109
            // 
            resources.ApplyResources(this.label109, "label109");
            this.label109.BackColor = System.Drawing.Color.Transparent;
            this.label109.Name = "label109";
            this.helpProvider1.SetShowHelp(this.label109, ((bool)(resources.GetObject("label109.ShowHelp"))));
            // 
            // label110
            // 
            resources.ApplyResources(this.label110, "label110");
            this.label110.BackColor = System.Drawing.Color.Transparent;
            this.label110.Name = "label110";
            this.helpProvider1.SetShowHelp(this.label110, ((bool)(resources.GetObject("label110.ShowHelp"))));
            // 
            // label111
            // 
            resources.ApplyResources(this.label111, "label111");
            this.label111.BackColor = System.Drawing.Color.Transparent;
            this.label111.Name = "label111";
            this.helpProvider1.SetShowHelp(this.label111, ((bool)(resources.GetObject("label111.ShowHelp"))));
            // 
            // label112
            // 
            resources.ApplyResources(this.label112, "label112");
            this.label112.BackColor = System.Drawing.Color.Transparent;
            this.label112.Name = "label112";
            this.helpProvider1.SetShowHelp(this.label112, ((bool)(resources.GetObject("label112.ShowHelp"))));
            // 
            // label113
            // 
            resources.ApplyResources(this.label113, "label113");
            this.label113.BackColor = System.Drawing.Color.Transparent;
            this.label113.Name = "label113";
            this.helpProvider1.SetShowHelp(this.label113, ((bool)(resources.GetObject("label113.ShowHelp"))));
            // 
            // label114
            // 
            resources.ApplyResources(this.label114, "label114");
            this.label114.BackColor = System.Drawing.Color.Transparent;
            this.label114.Name = "label114";
            this.helpProvider1.SetShowHelp(this.label114, ((bool)(resources.GetObject("label114.ShowHelp"))));
            // 
            // label115
            // 
            resources.ApplyResources(this.label115, "label115");
            this.label115.BackColor = System.Drawing.Color.Transparent;
            this.label115.Name = "label115";
            this.helpProvider1.SetShowHelp(this.label115, ((bool)(resources.GetObject("label115.ShowHelp"))));
            // 
            // label116
            // 
            resources.ApplyResources(this.label116, "label116");
            this.label116.BackColor = System.Drawing.Color.Transparent;
            this.label116.Name = "label116";
            this.helpProvider1.SetShowHelp(this.label116, ((bool)(resources.GetObject("label116.ShowHelp"))));
            // 
            // label117
            // 
            resources.ApplyResources(this.label117, "label117");
            this.label117.BackColor = System.Drawing.Color.Transparent;
            this.label117.Name = "label117";
            this.helpProvider1.SetShowHelp(this.label117, ((bool)(resources.GetObject("label117.ShowHelp"))));
            // 
            // label118
            // 
            resources.ApplyResources(this.label118, "label118");
            this.label118.BackColor = System.Drawing.Color.Transparent;
            this.label118.Name = "label118";
            this.helpProvider1.SetShowHelp(this.label118, ((bool)(resources.GetObject("label118.ShowHelp"))));
            // 
            // label119
            // 
            resources.ApplyResources(this.label119, "label119");
            this.label119.BackColor = System.Drawing.Color.Transparent;
            this.label119.Name = "label119";
            this.helpProvider1.SetShowHelp(this.label119, ((bool)(resources.GetObject("label119.ShowHelp"))));
            // 
            // label120
            // 
            resources.ApplyResources(this.label120, "label120");
            this.label120.BackColor = System.Drawing.Color.Transparent;
            this.label120.Name = "label120";
            this.helpProvider1.SetShowHelp(this.label120, ((bool)(resources.GetObject("label120.ShowHelp"))));
            // 
            // label121
            // 
            resources.ApplyResources(this.label121, "label121");
            this.label121.BackColor = System.Drawing.Color.Transparent;
            this.label121.Name = "label121";
            this.helpProvider1.SetShowHelp(this.label121, ((bool)(resources.GetObject("label121.ShowHelp"))));
            // 
            // label122
            // 
            resources.ApplyResources(this.label122, "label122");
            this.label122.BackColor = System.Drawing.Color.Transparent;
            this.label122.Name = "label122";
            this.helpProvider1.SetShowHelp(this.label122, ((bool)(resources.GetObject("label122.ShowHelp"))));
            // 
            // label123
            // 
            resources.ApplyResources(this.label123, "label123");
            this.label123.BackColor = System.Drawing.Color.Transparent;
            this.label123.Name = "label123";
            this.helpProvider1.SetShowHelp(this.label123, ((bool)(resources.GetObject("label123.ShowHelp"))));
            // 
            // label124
            // 
            resources.ApplyResources(this.label124, "label124");
            this.label124.BackColor = System.Drawing.Color.Transparent;
            this.label124.Name = "label124";
            this.helpProvider1.SetShowHelp(this.label124, ((bool)(resources.GetObject("label124.ShowHelp"))));
            // 
            // label125
            // 
            resources.ApplyResources(this.label125, "label125");
            this.label125.BackColor = System.Drawing.Color.Transparent;
            this.label125.Name = "label125";
            this.helpProvider1.SetShowHelp(this.label125, ((bool)(resources.GetObject("label125.ShowHelp"))));
            // 
            // label126
            // 
            resources.ApplyResources(this.label126, "label126");
            this.label126.BackColor = System.Drawing.Color.Transparent;
            this.label126.Name = "label126";
            this.helpProvider1.SetShowHelp(this.label126, ((bool)(resources.GetObject("label126.ShowHelp"))));
            // 
            // label127
            // 
            resources.ApplyResources(this.label127, "label127");
            this.label127.BackColor = System.Drawing.Color.Transparent;
            this.label127.Name = "label127";
            this.helpProvider1.SetShowHelp(this.label127, ((bool)(resources.GetObject("label127.ShowHelp"))));
            // 
            // label128
            // 
            resources.ApplyResources(this.label128, "label128");
            this.label128.BackColor = System.Drawing.Color.Transparent;
            this.label128.Name = "label128";
            this.helpProvider1.SetShowHelp(this.label128, ((bool)(resources.GetObject("label128.ShowHelp"))));
            // 
            // label129
            // 
            resources.ApplyResources(this.label129, "label129");
            this.label129.BackColor = System.Drawing.Color.Transparent;
            this.label129.Name = "label129";
            this.helpProvider1.SetShowHelp(this.label129, ((bool)(resources.GetObject("label129.ShowHelp"))));
            // 
            // label130
            // 
            resources.ApplyResources(this.label130, "label130");
            this.label130.BackColor = System.Drawing.Color.Transparent;
            this.label130.Name = "label130";
            this.helpProvider1.SetShowHelp(this.label130, ((bool)(resources.GetObject("label130.ShowHelp"))));
            // 
            // label131
            // 
            resources.ApplyResources(this.label131, "label131");
            this.label131.BackColor = System.Drawing.Color.Transparent;
            this.label131.Name = "label131";
            this.helpProvider1.SetShowHelp(this.label131, ((bool)(resources.GetObject("label131.ShowHelp"))));
            // 
            // label132
            // 
            resources.ApplyResources(this.label132, "label132");
            this.label132.BackColor = System.Drawing.Color.Transparent;
            this.label132.Name = "label132";
            this.helpProvider1.SetShowHelp(this.label132, ((bool)(resources.GetObject("label132.ShowHelp"))));
            // 
            // label133
            // 
            resources.ApplyResources(this.label133, "label133");
            this.label133.BackColor = System.Drawing.Color.Transparent;
            this.label133.Name = "label133";
            this.helpProvider1.SetShowHelp(this.label133, ((bool)(resources.GetObject("label133.ShowHelp"))));
            // 
            // label134
            // 
            resources.ApplyResources(this.label134, "label134");
            this.label134.BackColor = System.Drawing.Color.Transparent;
            this.label134.Name = "label134";
            this.helpProvider1.SetShowHelp(this.label134, ((bool)(resources.GetObject("label134.ShowHelp"))));
            // 
            // label135
            // 
            resources.ApplyResources(this.label135, "label135");
            this.label135.BackColor = System.Drawing.Color.Transparent;
            this.label135.Name = "label135";
            this.helpProvider1.SetShowHelp(this.label135, ((bool)(resources.GetObject("label135.ShowHelp"))));
            // 
            // label136
            // 
            resources.ApplyResources(this.label136, "label136");
            this.label136.BackColor = System.Drawing.Color.Transparent;
            this.label136.Name = "label136";
            this.helpProvider1.SetShowHelp(this.label136, ((bool)(resources.GetObject("label136.ShowHelp"))));
            // 
            // label137
            // 
            resources.ApplyResources(this.label137, "label137");
            this.label137.BackColor = System.Drawing.Color.Transparent;
            this.label137.Name = "label137";
            this.helpProvider1.SetShowHelp(this.label137, ((bool)(resources.GetObject("label137.ShowHelp"))));
            // 
            // label138
            // 
            resources.ApplyResources(this.label138, "label138");
            this.label138.BackColor = System.Drawing.Color.Transparent;
            this.label138.Name = "label138";
            this.helpProvider1.SetShowHelp(this.label138, ((bool)(resources.GetObject("label138.ShowHelp"))));
            // 
            // label139
            // 
            resources.ApplyResources(this.label139, "label139");
            this.label139.BackColor = System.Drawing.Color.Transparent;
            this.label139.Name = "label139";
            this.helpProvider1.SetShowHelp(this.label139, ((bool)(resources.GetObject("label139.ShowHelp"))));
            // 
            // label140
            // 
            resources.ApplyResources(this.label140, "label140");
            this.label140.BackColor = System.Drawing.Color.Transparent;
            this.label140.Name = "label140";
            this.helpProvider1.SetShowHelp(this.label140, ((bool)(resources.GetObject("label140.ShowHelp"))));
            // 
            // label141
            // 
            resources.ApplyResources(this.label141, "label141");
            this.label141.BackColor = System.Drawing.Color.Transparent;
            this.label141.Name = "label141";
            this.helpProvider1.SetShowHelp(this.label141, ((bool)(resources.GetObject("label141.ShowHelp"))));
            // 
            // label142
            // 
            resources.ApplyResources(this.label142, "label142");
            this.label142.BackColor = System.Drawing.Color.Transparent;
            this.label142.Name = "label142";
            this.helpProvider1.SetShowHelp(this.label142, ((bool)(resources.GetObject("label142.ShowHelp"))));
            // 
            // label143
            // 
            resources.ApplyResources(this.label143, "label143");
            this.label143.BackColor = System.Drawing.Color.Transparent;
            this.label143.Name = "label143";
            this.helpProvider1.SetShowHelp(this.label143, ((bool)(resources.GetObject("label143.ShowHelp"))));
            // 
            // label144
            // 
            resources.ApplyResources(this.label144, "label144");
            this.label144.BackColor = System.Drawing.Color.Transparent;
            this.label144.Name = "label144";
            this.helpProvider1.SetShowHelp(this.label144, ((bool)(resources.GetObject("label144.ShowHelp"))));
            // 
            // label145
            // 
            resources.ApplyResources(this.label145, "label145");
            this.label145.BackColor = System.Drawing.Color.Transparent;
            this.label145.Name = "label145";
            this.helpProvider1.SetShowHelp(this.label145, ((bool)(resources.GetObject("label145.ShowHelp"))));
            // 
            // label146
            // 
            resources.ApplyResources(this.label146, "label146");
            this.label146.BackColor = System.Drawing.Color.Transparent;
            this.label146.Name = "label146";
            this.helpProvider1.SetShowHelp(this.label146, ((bool)(resources.GetObject("label146.ShowHelp"))));
            // 
            // label147
            // 
            resources.ApplyResources(this.label147, "label147");
            this.label147.BackColor = System.Drawing.Color.Transparent;
            this.label147.Name = "label147";
            this.helpProvider1.SetShowHelp(this.label147, ((bool)(resources.GetObject("label147.ShowHelp"))));
            // 
            // label148
            // 
            resources.ApplyResources(this.label148, "label148");
            this.label148.BackColor = System.Drawing.Color.Transparent;
            this.label148.Name = "label148";
            this.helpProvider1.SetShowHelp(this.label148, ((bool)(resources.GetObject("label148.ShowHelp"))));
            // 
            // label149
            // 
            resources.ApplyResources(this.label149, "label149");
            this.label149.BackColor = System.Drawing.Color.Transparent;
            this.label149.Name = "label149";
            this.helpProvider1.SetShowHelp(this.label149, ((bool)(resources.GetObject("label149.ShowHelp"))));
            // 
            // label150
            // 
            resources.ApplyResources(this.label150, "label150");
            this.label150.BackColor = System.Drawing.Color.Transparent;
            this.label150.Name = "label150";
            this.helpProvider1.SetShowHelp(this.label150, ((bool)(resources.GetObject("label150.ShowHelp"))));
            // 
            // label151
            // 
            resources.ApplyResources(this.label151, "label151");
            this.label151.BackColor = System.Drawing.Color.Transparent;
            this.label151.Name = "label151";
            this.helpProvider1.SetShowHelp(this.label151, ((bool)(resources.GetObject("label151.ShowHelp"))));
            // 
            // label152
            // 
            resources.ApplyResources(this.label152, "label152");
            this.label152.BackColor = System.Drawing.Color.Transparent;
            this.label152.Name = "label152";
            this.helpProvider1.SetShowHelp(this.label152, ((bool)(resources.GetObject("label152.ShowHelp"))));
            // 
            // label153
            // 
            resources.ApplyResources(this.label153, "label153");
            this.label153.BackColor = System.Drawing.Color.Transparent;
            this.label153.Name = "label153";
            this.helpProvider1.SetShowHelp(this.label153, ((bool)(resources.GetObject("label153.ShowHelp"))));
            // 
            // label154
            // 
            resources.ApplyResources(this.label154, "label154");
            this.label154.BackColor = System.Drawing.Color.Transparent;
            this.label154.Name = "label154";
            this.helpProvider1.SetShowHelp(this.label154, ((bool)(resources.GetObject("label154.ShowHelp"))));
            // 
            // label155
            // 
            resources.ApplyResources(this.label155, "label155");
            this.label155.BackColor = System.Drawing.Color.Transparent;
            this.label155.Name = "label155";
            this.helpProvider1.SetShowHelp(this.label155, ((bool)(resources.GetObject("label155.ShowHelp"))));
            // 
            // label156
            // 
            resources.ApplyResources(this.label156, "label156");
            this.label156.BackColor = System.Drawing.Color.Transparent;
            this.label156.Name = "label156";
            this.helpProvider1.SetShowHelp(this.label156, ((bool)(resources.GetObject("label156.ShowHelp"))));
            // 
            // label157
            // 
            resources.ApplyResources(this.label157, "label157");
            this.label157.BackColor = System.Drawing.Color.Transparent;
            this.label157.Name = "label157";
            this.helpProvider1.SetShowHelp(this.label157, ((bool)(resources.GetObject("label157.ShowHelp"))));
            // 
            // label158
            // 
            resources.ApplyResources(this.label158, "label158");
            this.label158.BackColor = System.Drawing.Color.Transparent;
            this.label158.Name = "label158";
            this.helpProvider1.SetShowHelp(this.label158, ((bool)(resources.GetObject("label158.ShowHelp"))));
            // 
            // label159
            // 
            resources.ApplyResources(this.label159, "label159");
            this.label159.BackColor = System.Drawing.Color.Transparent;
            this.label159.Name = "label159";
            this.helpProvider1.SetShowHelp(this.label159, ((bool)(resources.GetObject("label159.ShowHelp"))));
            // 
            // label160
            // 
            resources.ApplyResources(this.label160, "label160");
            this.label160.BackColor = System.Drawing.Color.Transparent;
            this.label160.Name = "label160";
            this.helpProvider1.SetShowHelp(this.label160, ((bool)(resources.GetObject("label160.ShowHelp"))));
            // 
            // label161
            // 
            resources.ApplyResources(this.label161, "label161");
            this.label161.BackColor = System.Drawing.Color.Transparent;
            this.label161.Name = "label161";
            this.helpProvider1.SetShowHelp(this.label161, ((bool)(resources.GetObject("label161.ShowHelp"))));
            // 
            // label162
            // 
            resources.ApplyResources(this.label162, "label162");
            this.label162.BackColor = System.Drawing.Color.Transparent;
            this.label162.Name = "label162";
            this.helpProvider1.SetShowHelp(this.label162, ((bool)(resources.GetObject("label162.ShowHelp"))));
            // 
            // label163
            // 
            resources.ApplyResources(this.label163, "label163");
            this.label163.BackColor = System.Drawing.Color.Transparent;
            this.label163.Name = "label163";
            this.helpProvider1.SetShowHelp(this.label163, ((bool)(resources.GetObject("label163.ShowHelp"))));
            // 
            // label164
            // 
            resources.ApplyResources(this.label164, "label164");
            this.label164.BackColor = System.Drawing.Color.Transparent;
            this.label164.Name = "label164";
            this.helpProvider1.SetShowHelp(this.label164, ((bool)(resources.GetObject("label164.ShowHelp"))));
            // 
            // label165
            // 
            resources.ApplyResources(this.label165, "label165");
            this.label165.BackColor = System.Drawing.Color.Transparent;
            this.label165.Name = "label165";
            this.helpProvider1.SetShowHelp(this.label165, ((bool)(resources.GetObject("label165.ShowHelp"))));
            // 
            // label166
            // 
            resources.ApplyResources(this.label166, "label166");
            this.label166.BackColor = System.Drawing.Color.Transparent;
            this.label166.Name = "label166";
            this.helpProvider1.SetShowHelp(this.label166, ((bool)(resources.GetObject("label166.ShowHelp"))));
            // 
            // label167
            // 
            resources.ApplyResources(this.label167, "label167");
            this.label167.BackColor = System.Drawing.Color.Transparent;
            this.label167.Name = "label167";
            this.helpProvider1.SetShowHelp(this.label167, ((bool)(resources.GetObject("label167.ShowHelp"))));
            // 
            // label168
            // 
            resources.ApplyResources(this.label168, "label168");
            this.label168.BackColor = System.Drawing.Color.Transparent;
            this.label168.Name = "label168";
            this.helpProvider1.SetShowHelp(this.label168, ((bool)(resources.GetObject("label168.ShowHelp"))));
            // 
            // label169
            // 
            resources.ApplyResources(this.label169, "label169");
            this.label169.Name = "label169";
            this.helpProvider1.SetShowHelp(this.label169, ((bool)(resources.GetObject("label169.ShowHelp"))));
            // 
            // label170
            // 
            resources.ApplyResources(this.label170, "label170");
            this.label170.Name = "label170";
            this.helpProvider1.SetShowHelp(this.label170, ((bool)(resources.GetObject("label170.ShowHelp"))));
            // 
            // label171
            // 
            resources.ApplyResources(this.label171, "label171");
            this.label171.Name = "label171";
            this.helpProvider1.SetShowHelp(this.label171, ((bool)(resources.GetObject("label171.ShowHelp"))));
            // 
            // label172
            // 
            resources.ApplyResources(this.label172, "label172");
            this.label172.Name = "label172";
            this.helpProvider1.SetShowHelp(this.label172, ((bool)(resources.GetObject("label172.ShowHelp"))));
            // 
            // label173
            // 
            resources.ApplyResources(this.label173, "label173");
            this.label173.Name = "label173";
            this.helpProvider1.SetShowHelp(this.label173, ((bool)(resources.GetObject("label173.ShowHelp"))));
            // 
            // label174
            // 
            resources.ApplyResources(this.label174, "label174");
            this.label174.Name = "label174";
            this.helpProvider1.SetShowHelp(this.label174, ((bool)(resources.GetObject("label174.ShowHelp"))));
            // 
            // label175
            // 
            resources.ApplyResources(this.label175, "label175");
            this.label175.Name = "label175";
            this.helpProvider1.SetShowHelp(this.label175, ((bool)(resources.GetObject("label175.ShowHelp"))));
            // 
            // label176
            // 
            resources.ApplyResources(this.label176, "label176");
            this.label176.Name = "label176";
            this.helpProvider1.SetShowHelp(this.label176, ((bool)(resources.GetObject("label176.ShowHelp"))));
            // 
            // label177
            // 
            resources.ApplyResources(this.label177, "label177");
            this.label177.Name = "label177";
            this.helpProvider1.SetShowHelp(this.label177, ((bool)(resources.GetObject("label177.ShowHelp"))));
            // 
            // label178
            // 
            resources.ApplyResources(this.label178, "label178");
            this.label178.Name = "label178";
            this.helpProvider1.SetShowHelp(this.label178, ((bool)(resources.GetObject("label178.ShowHelp"))));
            // 
            // label179
            // 
            resources.ApplyResources(this.label179, "label179");
            this.label179.Name = "label179";
            this.helpProvider1.SetShowHelp(this.label179, ((bool)(resources.GetObject("label179.ShowHelp"))));
            // 
            // label180
            // 
            resources.ApplyResources(this.label180, "label180");
            this.label180.Name = "label180";
            this.helpProvider1.SetShowHelp(this.label180, ((bool)(resources.GetObject("label180.ShowHelp"))));
            // 
            // p2plus_19
            // 
            this.p2plus_19.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_19.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_19, "p2plus_19");
            this.p2plus_19.Name = "p2plus_19";
            this.p2plus_19.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_19, ((bool)(resources.GetObject("p2plus_19.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_19, resources.GetString("p2plus_19.ToolTip"));
            // 
            // p2r_19
            // 
            this.p2r_19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_19, "p2r_19");
            this.p2r_19.Name = "p2r_19";
            this.helpProvider1.SetShowHelp(this.p2r_19, ((bool)(resources.GetObject("p2r_19.ShowHelp"))));
            // 
            // p2ls_19
            // 
            this.p2ls_19.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_19.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_19, "p2ls_19");
            this.p2ls_19.Name = "p2ls_19";
            this.p2ls_19.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_19, ((bool)(resources.GetObject("p2ls_19.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_19, resources.GetString("p2ls_19.ToolTip"));
            // 
            // p2iws_19
            // 
            this.p2iws_19.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2iws_19.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_19, "p2iws_19");
            this.p2iws_19.Name = "p2iws_19";
            this.p2iws_19.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_19, ((bool)(resources.GetObject("p2iws_19.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_19, resources.GetString("p2iws_19.ToolTip"));
            // 
            // p2ib_19
            // 
            this.p2ib_19.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_19.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_19, "p2ib_19");
            this.p2ib_19.Name = "p2ib_19";
            this.p2ib_19.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_19, ((bool)(resources.GetObject("p2ib_19.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_19, resources.GetString("p2ib_19.ToolTip"));
            // 
            // p2pm_19
            // 
            this.p2pm_19.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2pm_19.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_19, "p2pm_19");
            this.p2pm_19.Name = "p2pm_19";
            this.p2pm_19.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_19, ((bool)(resources.GetObject("p2pm_19.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_19, resources.GetString("p2pm_19.ToolTip"));
            // 
            // p2vw_19
            // 
            this.p2vw_19.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_19.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_19, "p2vw_19");
            this.p2vw_19.Name = "p2vw_19";
            this.p2vw_19.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_19, ((bool)(resources.GetObject("p2vw_19.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_19, resources.GetString("p2vw_19.ToolTip"));
            // 
            // p2plus_8
            // 
            this.p2plus_8.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_8.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_8, "p2plus_8");
            this.p2plus_8.Name = "p2plus_8";
            this.p2plus_8.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_8, ((bool)(resources.GetObject("p2plus_8.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_8, resources.GetString("p2plus_8.ToolTip"));
            // 
            // p2r_8
            // 
            this.p2r_8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_8, "p2r_8");
            this.p2r_8.Name = "p2r_8";
            this.helpProvider1.SetShowHelp(this.p2r_8, ((bool)(resources.GetObject("p2r_8.ShowHelp"))));
            // 
            // p2ls_8
            // 
            this.p2ls_8.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_8.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_8, "p2ls_8");
            this.p2ls_8.Name = "p2ls_8";
            this.p2ls_8.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_8, ((bool)(resources.GetObject("p2ls_8.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_8, resources.GetString("p2ls_8.ToolTip"));
            // 
            // p2iws_8
            // 
            this.p2iws_8.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2iws_8.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_8, "p2iws_8");
            this.p2iws_8.Name = "p2iws_8";
            this.p2iws_8.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_8, ((bool)(resources.GetObject("p2iws_8.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_8, resources.GetString("p2iws_8.ToolTip"));
            // 
            // p2ib_8
            // 
            this.p2ib_8.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_8.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_8, "p2ib_8");
            this.p2ib_8.Name = "p2ib_8";
            this.p2ib_8.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_8, ((bool)(resources.GetObject("p2ib_8.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_8, resources.GetString("p2ib_8.ToolTip"));
            // 
            // p2pm_8
            // 
            this.p2pm_8.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2pm_8.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_8, "p2pm_8");
            this.p2pm_8.Name = "p2pm_8";
            this.p2pm_8.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_8, ((bool)(resources.GetObject("p2pm_8.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_8, resources.GetString("p2pm_8.ToolTip"));
            // 
            // p2vw_8
            // 
            this.p2vw_8.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_8.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_8, "p2vw_8");
            this.p2vw_8.Name = "p2vw_8";
            this.p2vw_8.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_8, ((bool)(resources.GetObject("p2vw_8.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_8, resources.GetString("p2vw_8.ToolTip"));
            // 
            // p2plus_14
            // 
            this.p2plus_14.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_14.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_14, "p2plus_14");
            this.p2plus_14.Name = "p2plus_14";
            this.p2plus_14.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_14, ((bool)(resources.GetObject("p2plus_14.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_14, resources.GetString("p2plus_14.ToolTip"));
            // 
            // p2r_14
            // 
            this.p2r_14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_14, "p2r_14");
            this.p2r_14.Name = "p2r_14";
            this.helpProvider1.SetShowHelp(this.p2r_14, ((bool)(resources.GetObject("p2r_14.ShowHelp"))));
            // 
            // p2ls_14
            // 
            this.p2ls_14.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_14.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_14, "p2ls_14");
            this.p2ls_14.Name = "p2ls_14";
            this.p2ls_14.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_14, ((bool)(resources.GetObject("p2ls_14.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_14, resources.GetString("p2ls_14.ToolTip"));
            // 
            // p2iws_14
            // 
            this.p2iws_14.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2iws_14.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_14, "p2iws_14");
            this.p2iws_14.Name = "p2iws_14";
            this.p2iws_14.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_14, ((bool)(resources.GetObject("p2iws_14.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_14, resources.GetString("p2iws_14.ToolTip"));
            // 
            // p2ib_14
            // 
            this.p2ib_14.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_14.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_14, "p2ib_14");
            this.p2ib_14.Name = "p2ib_14";
            this.p2ib_14.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_14, ((bool)(resources.GetObject("p2ib_14.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_14, resources.GetString("p2ib_14.ToolTip"));
            // 
            // p2pm_14
            // 
            this.p2pm_14.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2pm_14.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_14, "p2pm_14");
            this.p2pm_14.Name = "p2pm_14";
            this.p2pm_14.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_14, ((bool)(resources.GetObject("p2pm_14.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_14, resources.GetString("p2pm_14.ToolTip"));
            // 
            // p2vw_14
            // 
            this.p2vw_14.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_14.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_14, "p2vw_14");
            this.p2vw_14.Name = "p2vw_14";
            this.p2vw_14.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_14, ((bool)(resources.GetObject("p2vw_14.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_14, resources.GetString("p2vw_14.ToolTip"));
            // 
            // p2plus_54
            // 
            this.p2plus_54.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_54.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_54, "p2plus_54");
            this.p2plus_54.Name = "p2plus_54";
            this.p2plus_54.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_54, ((bool)(resources.GetObject("p2plus_54.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_54, resources.GetString("p2plus_54.ToolTip"));
            // 
            // p2r_54
            // 
            this.p2r_54.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_54, "p2r_54");
            this.p2r_54.Name = "p2r_54";
            this.helpProvider1.SetShowHelp(this.p2r_54, ((bool)(resources.GetObject("p2r_54.ShowHelp"))));
            // 
            // p2ls_54
            // 
            this.p2ls_54.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_54.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_54, "p2ls_54");
            this.p2ls_54.Name = "p2ls_54";
            this.p2ls_54.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_54, ((bool)(resources.GetObject("p2ls_54.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_54, resources.GetString("p2ls_54.ToolTip"));
            // 
            // p2iws_54
            // 
            this.p2iws_54.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2iws_54.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_54, "p2iws_54");
            this.p2iws_54.Name = "p2iws_54";
            this.p2iws_54.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_54, ((bool)(resources.GetObject("p2iws_54.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_54, resources.GetString("p2iws_54.ToolTip"));
            // 
            // p2ib_54
            // 
            this.p2ib_54.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_54.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_54, "p2ib_54");
            this.p2ib_54.Name = "p2ib_54";
            this.p2ib_54.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_54, ((bool)(resources.GetObject("p2ib_54.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_54, resources.GetString("p2ib_54.ToolTip"));
            // 
            // p2pm_54
            // 
            this.p2pm_54.BackColor = System.Drawing.Color.MistyRose;
            this.p2pm_54.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_54, "p2pm_54");
            this.p2pm_54.Name = "p2pm_54";
            this.p2pm_54.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_54, ((bool)(resources.GetObject("p2pm_54.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_54, resources.GetString("p2pm_54.ToolTip"));
            // 
            // p2vw_54
            // 
            this.p2vw_54.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_54.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_54, "p2vw_54");
            this.p2vw_54.Name = "p2vw_54";
            this.p2vw_54.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_54, ((bool)(resources.GetObject("p2vw_54.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_54, resources.GetString("p2vw_54.ToolTip"));
            // 
            // p2plus_5
            // 
            this.p2plus_5.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_5.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_5, "p2plus_5");
            this.p2plus_5.Name = "p2plus_5";
            this.p2plus_5.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_5, ((bool)(resources.GetObject("p2plus_5.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_5, resources.GetString("p2plus_5.ToolTip"));
            // 
            // p2r_5
            // 
            this.p2r_5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_5, "p2r_5");
            this.p2r_5.Name = "p2r_5";
            this.helpProvider1.SetShowHelp(this.p2r_5, ((bool)(resources.GetObject("p2r_5.ShowHelp"))));
            // 
            // p2ls_5
            // 
            this.p2ls_5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_5.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_5, "p2ls_5");
            this.p2ls_5.Name = "p2ls_5";
            this.p2ls_5.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_5, ((bool)(resources.GetObject("p2ls_5.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_5, resources.GetString("p2ls_5.ToolTip"));
            // 
            // p2iws_5
            // 
            this.p2iws_5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2iws_5.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_5, "p2iws_5");
            this.p2iws_5.Name = "p2iws_5";
            this.p2iws_5.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_5, ((bool)(resources.GetObject("p2iws_5.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_5, resources.GetString("p2iws_5.ToolTip"));
            // 
            // p2ib_5
            // 
            this.p2ib_5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_5.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_5, "p2ib_5");
            this.p2ib_5.Name = "p2ib_5";
            this.p2ib_5.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_5, ((bool)(resources.GetObject("p2ib_5.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_5, resources.GetString("p2ib_5.ToolTip"));
            // 
            // p2pm_5
            // 
            this.p2pm_5.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2pm_5.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_5, "p2pm_5");
            this.p2pm_5.Name = "p2pm_5";
            this.p2pm_5.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_5, ((bool)(resources.GetObject("p2pm_5.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_5, resources.GetString("p2pm_5.ToolTip"));
            // 
            // p2vw_5
            // 
            this.p2vw_5.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_5.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_5, "p2vw_5");
            this.p2vw_5.Name = "p2vw_5";
            this.p2vw_5.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_5, ((bool)(resources.GetObject("p2vw_5.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_5, resources.GetString("p2vw_5.ToolTip"));
            // 
            // p2plus_11
            // 
            this.p2plus_11.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_11.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_11, "p2plus_11");
            this.p2plus_11.Name = "p2plus_11";
            this.p2plus_11.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_11, ((bool)(resources.GetObject("p2plus_11.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_11, resources.GetString("p2plus_11.ToolTip"));
            // 
            // p2r_11
            // 
            this.p2r_11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_11, "p2r_11");
            this.p2r_11.Name = "p2r_11";
            this.helpProvider1.SetShowHelp(this.p2r_11, ((bool)(resources.GetObject("p2r_11.ShowHelp"))));
            // 
            // p2ls_11
            // 
            this.p2ls_11.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_11.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_11, "p2ls_11");
            this.p2ls_11.Name = "p2ls_11";
            this.p2ls_11.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_11, ((bool)(resources.GetObject("p2ls_11.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_11, resources.GetString("p2ls_11.ToolTip"));
            // 
            // p2iws_11
            // 
            this.p2iws_11.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2iws_11.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_11, "p2iws_11");
            this.p2iws_11.Name = "p2iws_11";
            this.p2iws_11.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_11, ((bool)(resources.GetObject("p2iws_11.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_11, resources.GetString("p2iws_11.ToolTip"));
            // 
            // p2ib_11
            // 
            this.p2ib_11.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_11.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_11, "p2ib_11");
            this.p2ib_11.Name = "p2ib_11";
            this.p2ib_11.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_11, ((bool)(resources.GetObject("p2ib_11.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_11, resources.GetString("p2ib_11.ToolTip"));
            // 
            // p2pm_11
            // 
            this.p2pm_11.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2pm_11.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_11, "p2pm_11");
            this.p2pm_11.Name = "p2pm_11";
            this.p2pm_11.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_11, ((bool)(resources.GetObject("p2pm_11.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_11, resources.GetString("p2pm_11.ToolTip"));
            // 
            // p2vw_11
            // 
            this.p2vw_11.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_11.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_11, "p2vw_11");
            this.p2vw_11.Name = "p2vw_11";
            this.p2vw_11.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_11, ((bool)(resources.GetObject("p2vw_11.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_11, resources.GetString("p2vw_11.ToolTip"));
            // 
            // p2plus_55
            // 
            this.p2plus_55.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_55.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_55, "p2plus_55");
            this.p2plus_55.Name = "p2plus_55";
            this.p2plus_55.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_55, ((bool)(resources.GetObject("p2plus_55.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_55, resources.GetString("p2plus_55.ToolTip"));
            // 
            // p2r_55
            // 
            this.p2r_55.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_55, "p2r_55");
            this.p2r_55.Name = "p2r_55";
            this.helpProvider1.SetShowHelp(this.p2r_55, ((bool)(resources.GetObject("p2r_55.ShowHelp"))));
            // 
            // p2ls_55
            // 
            this.p2ls_55.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_55.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_55, "p2ls_55");
            this.p2ls_55.Name = "p2ls_55";
            this.p2ls_55.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_55, ((bool)(resources.GetObject("p2ls_55.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_55, resources.GetString("p2ls_55.ToolTip"));
            // 
            // p2iws_55
            // 
            this.p2iws_55.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2iws_55.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_55, "p2iws_55");
            this.p2iws_55.Name = "p2iws_55";
            this.p2iws_55.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_55, ((bool)(resources.GetObject("p2iws_55.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_55, resources.GetString("p2iws_55.ToolTip"));
            // 
            // p2ib_55
            // 
            this.p2ib_55.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_55.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_55, "p2ib_55");
            this.p2ib_55.Name = "p2ib_55";
            this.p2ib_55.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_55, ((bool)(resources.GetObject("p2ib_55.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_55, resources.GetString("p2ib_55.ToolTip"));
            // 
            // p2pm_55
            // 
            this.p2pm_55.BackColor = System.Drawing.Color.MistyRose;
            this.p2pm_55.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_55, "p2pm_55");
            this.p2pm_55.Name = "p2pm_55";
            this.p2pm_55.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_55, ((bool)(resources.GetObject("p2pm_55.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_55, resources.GetString("p2pm_55.ToolTip"));
            // 
            // p2vw_55
            // 
            this.p2vw_55.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_55.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_55, "p2vw_55");
            this.p2vw_55.Name = "p2vw_55";
            this.p2vw_55.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_55, ((bool)(resources.GetObject("p2vw_55.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_55, resources.GetString("p2vw_55.ToolTip"));
            // 
            // p2plus_16
            // 
            this.p2plus_16.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_16, "p2plus_16");
            this.p2plus_16.Name = "p2plus_16";
            this.p2plus_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_16, ((bool)(resources.GetObject("p2plus_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_16, resources.GetString("p2plus_16.ToolTip"));
            // 
            // p2r_16
            // 
            this.p2r_16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_16, "p2r_16");
            this.p2r_16.Name = "p2r_16";
            this.helpProvider1.SetShowHelp(this.p2r_16, ((bool)(resources.GetObject("p2r_16.ShowHelp"))));
            // 
            // p2ls_16
            // 
            this.p2ls_16.BackColor = System.Drawing.SystemColors.Window;
            this.p2ls_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_16, "p2ls_16");
            this.p2ls_16.Name = "p2ls_16";
            this.p2ls_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_16, ((bool)(resources.GetObject("p2ls_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_16, resources.GetString("p2ls_16.ToolTip"));
            // 
            // p2iws_16
            // 
            this.p2iws_16.BackColor = System.Drawing.SystemColors.Window;
            this.p2iws_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_16, "p2iws_16");
            this.p2iws_16.Name = "p2iws_16";
            this.p2iws_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_16, ((bool)(resources.GetObject("p2iws_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_16, resources.GetString("p2iws_16.ToolTip"));
            // 
            // p2ib_16
            // 
            this.p2ib_16.BackColor = System.Drawing.SystemColors.Window;
            this.p2ib_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_16, "p2ib_16");
            this.p2ib_16.Name = "p2ib_16";
            this.p2ib_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_16, ((bool)(resources.GetObject("p2ib_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_16, resources.GetString("p2ib_16.ToolTip"));
            // 
            // p2pm_16
            // 
            this.p2pm_16.BackColor = System.Drawing.Color.LemonChiffon;
            this.p2pm_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_16, "p2pm_16");
            this.p2pm_16.Name = "p2pm_16";
            this.p2pm_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_16, ((bool)(resources.GetObject("p2pm_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_16, resources.GetString("p2pm_16.ToolTip"));
            // 
            // p2vw_16
            // 
            this.p2vw_16.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_16, "p2vw_16");
            this.p2vw_16.Name = "p2vw_16";
            this.p2vw_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_16, ((bool)(resources.GetObject("p2vw_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_16, resources.GetString("p2vw_16.ToolTip"));
            // 
            // p2plus_17
            // 
            this.p2plus_17.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_17, "p2plus_17");
            this.p2plus_17.Name = "p2plus_17";
            this.p2plus_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_17, ((bool)(resources.GetObject("p2plus_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_17, resources.GetString("p2plus_17.ToolTip"));
            // 
            // p2r_17
            // 
            this.p2r_17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_17, "p2r_17");
            this.p2r_17.Name = "p2r_17";
            this.helpProvider1.SetShowHelp(this.p2r_17, ((bool)(resources.GetObject("p2r_17.ShowHelp"))));
            // 
            // p2ls_17
            // 
            this.p2ls_17.BackColor = System.Drawing.SystemColors.Window;
            this.p2ls_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_17, "p2ls_17");
            this.p2ls_17.Name = "p2ls_17";
            this.p2ls_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_17, ((bool)(resources.GetObject("p2ls_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_17, resources.GetString("p2ls_17.ToolTip"));
            // 
            // p2iws_17
            // 
            this.p2iws_17.BackColor = System.Drawing.SystemColors.Window;
            this.p2iws_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_17, "p2iws_17");
            this.p2iws_17.Name = "p2iws_17";
            this.p2iws_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_17, ((bool)(resources.GetObject("p2iws_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_17, resources.GetString("p2iws_17.ToolTip"));
            // 
            // p2ib_17
            // 
            this.p2ib_17.BackColor = System.Drawing.SystemColors.Window;
            this.p2ib_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_17, "p2ib_17");
            this.p2ib_17.Name = "p2ib_17";
            this.p2ib_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_17, ((bool)(resources.GetObject("p2ib_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_17, resources.GetString("p2ib_17.ToolTip"));
            // 
            // p2pm_17
            // 
            this.p2pm_17.BackColor = System.Drawing.Color.LemonChiffon;
            this.p2pm_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_17, "p2pm_17");
            this.p2pm_17.Name = "p2pm_17";
            this.p2pm_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_17, ((bool)(resources.GetObject("p2pm_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_17, resources.GetString("p2pm_17.ToolTip"));
            // 
            // p2vw_17
            // 
            this.p2vw_17.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_17, "p2vw_17");
            this.p2vw_17.Name = "p2vw_17";
            this.p2vw_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_17, ((bool)(resources.GetObject("p2vw_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_17, resources.GetString("p2vw_17.ToolTip"));
            // 
            // p2plus_26
            // 
            this.p2plus_26.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_26, "p2plus_26");
            this.p2plus_26.Name = "p2plus_26";
            this.p2plus_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_26, ((bool)(resources.GetObject("p2plus_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_26, resources.GetString("p2plus_26.ToolTip"));
            // 
            // p2r_26
            // 
            this.p2r_26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_26, "p2r_26");
            this.p2r_26.Name = "p2r_26";
            this.helpProvider1.SetShowHelp(this.p2r_26, ((bool)(resources.GetObject("p2r_26.ShowHelp"))));
            // 
            // p2ls_26
            // 
            this.p2ls_26.BackColor = System.Drawing.SystemColors.Window;
            this.p2ls_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_26, "p2ls_26");
            this.p2ls_26.Name = "p2ls_26";
            this.p2ls_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_26, ((bool)(resources.GetObject("p2ls_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_26, resources.GetString("p2ls_26.ToolTip"));
            // 
            // p2iws_26
            // 
            this.p2iws_26.BackColor = System.Drawing.SystemColors.Window;
            this.p2iws_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_26, "p2iws_26");
            this.p2iws_26.Name = "p2iws_26";
            this.p2iws_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_26, ((bool)(resources.GetObject("p2iws_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_26, resources.GetString("p2iws_26.ToolTip"));
            // 
            // p2ib_26
            // 
            this.p2ib_26.BackColor = System.Drawing.SystemColors.Window;
            this.p2ib_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_26, "p2ib_26");
            this.p2ib_26.Name = "p2ib_26";
            this.p2ib_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_26, ((bool)(resources.GetObject("p2ib_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_26, resources.GetString("p2ib_26.ToolTip"));
            // 
            // p2pm_26
            // 
            this.p2pm_26.BackColor = System.Drawing.Color.LemonChiffon;
            this.p2pm_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_26, "p2pm_26");
            this.p2pm_26.Name = "p2pm_26";
            this.p2pm_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_26, ((bool)(resources.GetObject("p2pm_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_26, resources.GetString("p2pm_26.ToolTip"));
            // 
            // p2vw_26
            // 
            this.p2vw_26.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_26, "p2vw_26");
            this.p2vw_26.Name = "p2vw_26";
            this.p2vw_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_26, ((bool)(resources.GetObject("p2vw_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_26, resources.GetString("p2vw_26.ToolTip"));
            // 
            // p2plus_56
            // 
            this.p2plus_56.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2plus_56.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2plus_56, "p2plus_56");
            this.p2plus_56.Name = "p2plus_56";
            this.p2plus_56.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2plus_56, ((bool)(resources.GetObject("p2plus_56.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2plus_56, resources.GetString("p2plus_56.ToolTip"));
            // 
            // p2r_56
            // 
            this.p2r_56.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_56, "p2r_56");
            this.p2r_56.Name = "p2r_56";
            this.helpProvider1.SetShowHelp(this.p2r_56, ((bool)(resources.GetObject("p2r_56.ShowHelp"))));
            // 
            // p2ls_56
            // 
            this.p2ls_56.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_56.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_56, "p2ls_56");
            this.p2ls_56.Name = "p2ls_56";
            this.p2ls_56.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_56, ((bool)(resources.GetObject("p2ls_56.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_56, resources.GetString("p2ls_56.ToolTip"));
            // 
            // p2iws_56
            // 
            this.p2iws_56.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2iws_56.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_56, "p2iws_56");
            this.p2iws_56.Name = "p2iws_56";
            this.p2iws_56.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_56, ((bool)(resources.GetObject("p2iws_56.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_56, resources.GetString("p2iws_56.ToolTip"));
            // 
            // p2ib_56
            // 
            this.p2ib_56.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_56.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_56, "p2ib_56");
            this.p2ib_56.Name = "p2ib_56";
            this.p2ib_56.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_56, ((bool)(resources.GetObject("p2ib_56.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_56, resources.GetString("p2ib_56.ToolTip"));
            // 
            // p2pm_56
            // 
            this.p2pm_56.BackColor = System.Drawing.Color.MistyRose;
            this.p2pm_56.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_56, "p2pm_56");
            this.p2pm_56.Name = "p2pm_56";
            this.p2pm_56.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_56, ((bool)(resources.GetObject("p2pm_56.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_56, resources.GetString("p2pm_56.ToolTip"));
            // 
            // p2vw_56
            // 
            this.p2vw_56.BackColor = System.Drawing.Color.MistyRose;
            this.p2vw_56.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2vw_56, "p2vw_56");
            this.p2vw_56.Name = "p2vw_56";
            this.p2vw_56.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2vw_56, ((bool)(resources.GetObject("p2vw_56.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2vw_56, resources.GetString("p2vw_56.ToolTip"));
            // 
            // p2r_0
            // 
            this.p2r_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2r_0, "p2r_0");
            this.p2r_0.Name = "p2r_0";
            this.helpProvider1.SetShowHelp(this.p2r_0, ((bool)(resources.GetObject("p2r_0.ShowHelp"))));
            // 
            // p2ls_0
            // 
            this.p2ls_0.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ls_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ls_0, "p2ls_0");
            this.p2ls_0.Name = "p2ls_0";
            this.p2ls_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ls_0, ((bool)(resources.GetObject("p2ls_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ls_0, resources.GetString("p2ls_0.ToolTip"));
            // 
            // p2iws_0
            // 
            this.p2iws_0.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p2iws_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2iws_0, "p2iws_0");
            this.p2iws_0.Name = "p2iws_0";
            this.p2iws_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2iws_0, ((bool)(resources.GetObject("p2iws_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2iws_0, resources.GetString("p2iws_0.ToolTip"));
            // 
            // p2ib_0
            // 
            this.p2ib_0.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p2ib_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2ib_0, "p2ib_0");
            this.p2ib_0.Name = "p2ib_0";
            this.p2ib_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2ib_0, ((bool)(resources.GetObject("p2ib_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2ib_0, resources.GetString("p2ib_0.ToolTip"));
            // 
            // p2pm_0
            // 
            this.p2pm_0.BackColor = System.Drawing.Color.MistyRose;
            this.p2pm_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p2pm_0, "p2pm_0");
            this.p2pm_0.Name = "p2pm_0";
            this.p2pm_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p2pm_0, ((bool)(resources.GetObject("p2pm_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p2pm_0, resources.GetString("p2pm_0.ToolTip"));
            // 
            // p2vw_0
            // 
            this.p2vw_0.BackColor = System.Drawing.Color.LightYellow;
            this.p2vw_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p2vw_0, "p2vw_0");
            this.p2vw_0.Name = "p2vw_0";
            this.helpProvider1.SetShowHelp(this.p2vw_0, ((bool)(resources.GetObject("p2vw_0.ShowHelp"))));
            // 
            // tab_P3
            // 
            this.tab_P3.BackColor = System.Drawing.Color.Transparent;
            this.tab_P3.Controls.Add(this.panel3);
            resources.ApplyResources(this.tab_P3, "tab_P3");
            this.tab_P3.Name = "tab_P3";
            this.helpProvider1.SetShowHelp(this.tab_P3, ((bool)(resources.GetObject("tab_P3.ShowHelp"))));
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.p3ETAusfueren);
            this.panel3.Controls.Add(this.label181);
            this.panel3.Controls.Add(this.label182);
            this.panel3.Controls.Add(this.label183);
            this.panel3.Controls.Add(this.label184);
            this.panel3.Controls.Add(this.label185);
            this.panel3.Controls.Add(this.label186);
            this.panel3.Controls.Add(this.label187);
            this.panel3.Controls.Add(this.label188);
            this.panel3.Controls.Add(this.label189);
            this.panel3.Controls.Add(this.label190);
            this.panel3.Controls.Add(this.label191);
            this.panel3.Controls.Add(this.label192);
            this.panel3.Controls.Add(this.label193);
            this.panel3.Controls.Add(this.label194);
            this.panel3.Controls.Add(this.label195);
            this.panel3.Controls.Add(this.label196);
            this.panel3.Controls.Add(this.label197);
            this.panel3.Controls.Add(this.label198);
            this.panel3.Controls.Add(this.label199);
            this.panel3.Controls.Add(this.label200);
            this.panel3.Controls.Add(this.label201);
            this.panel3.Controls.Add(this.label202);
            this.panel3.Controls.Add(this.label203);
            this.panel3.Controls.Add(this.label204);
            this.panel3.Controls.Add(this.label205);
            this.panel3.Controls.Add(this.label206);
            this.panel3.Controls.Add(this.label207);
            this.panel3.Controls.Add(this.label208);
            this.panel3.Controls.Add(this.label209);
            this.panel3.Controls.Add(this.label210);
            this.panel3.Controls.Add(this.label211);
            this.panel3.Controls.Add(this.label212);
            this.panel3.Controls.Add(this.label213);
            this.panel3.Controls.Add(this.label214);
            this.panel3.Controls.Add(this.label215);
            this.panel3.Controls.Add(this.label216);
            this.panel3.Controls.Add(this.label217);
            this.panel3.Controls.Add(this.label218);
            this.panel3.Controls.Add(this.label219);
            this.panel3.Controls.Add(this.label220);
            this.panel3.Controls.Add(this.label221);
            this.panel3.Controls.Add(this.label222);
            this.panel3.Controls.Add(this.label223);
            this.panel3.Controls.Add(this.label224);
            this.panel3.Controls.Add(this.label225);
            this.panel3.Controls.Add(this.label226);
            this.panel3.Controls.Add(this.label227);
            this.panel3.Controls.Add(this.label228);
            this.panel3.Controls.Add(this.label229);
            this.panel3.Controls.Add(this.label230);
            this.panel3.Controls.Add(this.label231);
            this.panel3.Controls.Add(this.label232);
            this.panel3.Controls.Add(this.label233);
            this.panel3.Controls.Add(this.label234);
            this.panel3.Controls.Add(this.label235);
            this.panel3.Controls.Add(this.label236);
            this.panel3.Controls.Add(this.label237);
            this.panel3.Controls.Add(this.label238);
            this.panel3.Controls.Add(this.label239);
            this.panel3.Controls.Add(this.label240);
            this.panel3.Controls.Add(this.label241);
            this.panel3.Controls.Add(this.label242);
            this.panel3.Controls.Add(this.label243);
            this.panel3.Controls.Add(this.label244);
            this.panel3.Controls.Add(this.label245);
            this.panel3.Controls.Add(this.label246);
            this.panel3.Controls.Add(this.label247);
            this.panel3.Controls.Add(this.label248);
            this.panel3.Controls.Add(this.label249);
            this.panel3.Controls.Add(this.label250);
            this.panel3.Controls.Add(this.label251);
            this.panel3.Controls.Add(this.label252);
            this.panel3.Controls.Add(this.label253);
            this.panel3.Controls.Add(this.label254);
            this.panel3.Controls.Add(this.label255);
            this.panel3.Controls.Add(this.label256);
            this.panel3.Controls.Add(this.label257);
            this.panel3.Controls.Add(this.label258);
            this.panel3.Controls.Add(this.label259);
            this.panel3.Controls.Add(this.label260);
            this.panel3.Controls.Add(this.label261);
            this.panel3.Controls.Add(this.label262);
            this.panel3.Controls.Add(this.label263);
            this.panel3.Controls.Add(this.label264);
            this.panel3.Controls.Add(this.label265);
            this.panel3.Controls.Add(this.label266);
            this.panel3.Controls.Add(this.label267);
            this.panel3.Controls.Add(this.label268);
            this.panel3.Controls.Add(this.label269);
            this.panel3.Controls.Add(this.p3plus_20);
            this.panel3.Controls.Add(this.p3r_20);
            this.panel3.Controls.Add(this.p3ls_20);
            this.panel3.Controls.Add(this.p3iws_20);
            this.panel3.Controls.Add(this.p3ib_20);
            this.panel3.Controls.Add(this.p3pm_20);
            this.panel3.Controls.Add(this.p3vw_20);
            this.panel3.Controls.Add(this.p3plus_9);
            this.panel3.Controls.Add(this.p3r_9);
            this.panel3.Controls.Add(this.p3ls_9);
            this.panel3.Controls.Add(this.p3iws_9);
            this.panel3.Controls.Add(this.p3ib_9);
            this.panel3.Controls.Add(this.p3pm_9);
            this.panel3.Controls.Add(this.p3vw_9);
            this.panel3.Controls.Add(this.p3plus_15);
            this.panel3.Controls.Add(this.p3r_15);
            this.panel3.Controls.Add(this.p3ls_15);
            this.panel3.Controls.Add(this.p3iws_15);
            this.panel3.Controls.Add(this.p3ib_15);
            this.panel3.Controls.Add(this.p3pm_15);
            this.panel3.Controls.Add(this.p3vw_15);
            this.panel3.Controls.Add(this.p3plus_29);
            this.panel3.Controls.Add(this.p3r_29);
            this.panel3.Controls.Add(this.p3ls_29);
            this.panel3.Controls.Add(this.p3iws_29);
            this.panel3.Controls.Add(this.p3ib_29);
            this.panel3.Controls.Add(this.p3pm_29);
            this.panel3.Controls.Add(this.p3vw_29);
            this.panel3.Controls.Add(this.p3plus_6);
            this.panel3.Controls.Add(this.p3r_6);
            this.panel3.Controls.Add(this.p3ls_6);
            this.panel3.Controls.Add(this.p3iws_6);
            this.panel3.Controls.Add(this.p3ib_6);
            this.panel3.Controls.Add(this.p3pm_6);
            this.panel3.Controls.Add(this.p3vw_6);
            this.panel3.Controls.Add(this.p3plus_12);
            this.panel3.Controls.Add(this.p3r_12);
            this.panel3.Controls.Add(this.p3ls_12);
            this.panel3.Controls.Add(this.p3iws_12);
            this.panel3.Controls.Add(this.p3ib_12);
            this.panel3.Controls.Add(this.p3pm_12);
            this.panel3.Controls.Add(this.p3vw_12);
            this.panel3.Controls.Add(this.p3plus_30);
            this.panel3.Controls.Add(this.p3r_30);
            this.panel3.Controls.Add(this.p3ls_30);
            this.panel3.Controls.Add(this.p3iws_30);
            this.panel3.Controls.Add(this.p3ib_30);
            this.panel3.Controls.Add(this.p3pm_30);
            this.panel3.Controls.Add(this.p3vw_30);
            this.panel3.Controls.Add(this.p3plus_16);
            this.panel3.Controls.Add(this.p3r_16);
            this.panel3.Controls.Add(this.p3ls_16);
            this.panel3.Controls.Add(this.p3iws_16);
            this.panel3.Controls.Add(this.p3ib_16);
            this.panel3.Controls.Add(this.p3pm_16);
            this.panel3.Controls.Add(this.p3vw_16);
            this.panel3.Controls.Add(this.p3plus_17);
            this.panel3.Controls.Add(this.p3r_17);
            this.panel3.Controls.Add(this.p3ls_17);
            this.panel3.Controls.Add(this.p3iws_17);
            this.panel3.Controls.Add(this.p3ib_17);
            this.panel3.Controls.Add(this.p3pm_17);
            this.panel3.Controls.Add(this.p3vw_17);
            this.panel3.Controls.Add(this.p3plus_26);
            this.panel3.Controls.Add(this.p3r_26);
            this.panel3.Controls.Add(this.p3ls_26);
            this.panel3.Controls.Add(this.p3iws_26);
            this.panel3.Controls.Add(this.p3ib_26);
            this.panel3.Controls.Add(this.p3pm_26);
            this.panel3.Controls.Add(this.p3vw_26);
            this.panel3.Controls.Add(this.p3plus_31);
            this.panel3.Controls.Add(this.p3r_31);
            this.panel3.Controls.Add(this.p3ls_31);
            this.panel3.Controls.Add(this.p3iws_31);
            this.panel3.Controls.Add(this.p3ib_31);
            this.panel3.Controls.Add(this.p3pm_31);
            this.panel3.Controls.Add(this.p3vw_31);
            this.panel3.Controls.Add(this.p3r_0);
            this.panel3.Controls.Add(this.p3ls_0);
            this.panel3.Controls.Add(this.p3iws_0);
            this.panel3.Controls.Add(this.p3ib_0);
            this.panel3.Controls.Add(this.p3pm_0);
            this.panel3.Controls.Add(this.p3vw_0);
            this.panel3.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Name = "panel3";
            this.helpProvider1.SetShowHelp(this.panel3, ((bool)(resources.GetObject("panel3.ShowHelp"))));
            // 
            // p3ETAusfueren
            // 
            this.p3ETAusfueren.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.p3ETAusfueren, "p3ETAusfueren");
            this.p3ETAusfueren.Name = "p3ETAusfueren";
            this.helpProvider1.SetShowHelp(this.p3ETAusfueren, ((bool)(resources.GetObject("p3ETAusfueren.ShowHelp"))));
            this.p3ETAusfueren.TabStop = false;
            this.toolTip.SetToolTip(this.p3ETAusfueren, resources.GetString("p3ETAusfueren.ToolTip"));
            this.p3ETAusfueren.Click += new System.EventHandler(this.p3ETAusfueren_Click);
            // 
            // label181
            // 
            resources.ApplyResources(this.label181, "label181");
            this.label181.Name = "label181";
            this.helpProvider1.SetShowHelp(this.label181, ((bool)(resources.GetObject("label181.ShowHelp"))));
            // 
            // label182
            // 
            resources.ApplyResources(this.label182, "label182");
            this.label182.Name = "label182";
            this.helpProvider1.SetShowHelp(this.label182, ((bool)(resources.GetObject("label182.ShowHelp"))));
            // 
            // label183
            // 
            resources.ApplyResources(this.label183, "label183");
            this.label183.Name = "label183";
            this.helpProvider1.SetShowHelp(this.label183, ((bool)(resources.GetObject("label183.ShowHelp"))));
            // 
            // label184
            // 
            resources.ApplyResources(this.label184, "label184");
            this.label184.Name = "label184";
            this.helpProvider1.SetShowHelp(this.label184, ((bool)(resources.GetObject("label184.ShowHelp"))));
            // 
            // label185
            // 
            resources.ApplyResources(this.label185, "label185");
            this.label185.Name = "label185";
            this.helpProvider1.SetShowHelp(this.label185, ((bool)(resources.GetObject("label185.ShowHelp"))));
            // 
            // label186
            // 
            resources.ApplyResources(this.label186, "label186");
            this.label186.Name = "label186";
            this.helpProvider1.SetShowHelp(this.label186, ((bool)(resources.GetObject("label186.ShowHelp"))));
            // 
            // label187
            // 
            resources.ApplyResources(this.label187, "label187");
            this.label187.BackColor = System.Drawing.Color.Transparent;
            this.label187.Name = "label187";
            this.helpProvider1.SetShowHelp(this.label187, ((bool)(resources.GetObject("label187.ShowHelp"))));
            // 
            // label188
            // 
            resources.ApplyResources(this.label188, "label188");
            this.label188.BackColor = System.Drawing.Color.Transparent;
            this.label188.Name = "label188";
            this.helpProvider1.SetShowHelp(this.label188, ((bool)(resources.GetObject("label188.ShowHelp"))));
            // 
            // label189
            // 
            resources.ApplyResources(this.label189, "label189");
            this.label189.BackColor = System.Drawing.Color.Transparent;
            this.label189.Name = "label189";
            this.helpProvider1.SetShowHelp(this.label189, ((bool)(resources.GetObject("label189.ShowHelp"))));
            // 
            // label190
            // 
            resources.ApplyResources(this.label190, "label190");
            this.label190.BackColor = System.Drawing.Color.Transparent;
            this.label190.Name = "label190";
            this.helpProvider1.SetShowHelp(this.label190, ((bool)(resources.GetObject("label190.ShowHelp"))));
            // 
            // label191
            // 
            resources.ApplyResources(this.label191, "label191");
            this.label191.BackColor = System.Drawing.Color.Transparent;
            this.label191.Name = "label191";
            this.helpProvider1.SetShowHelp(this.label191, ((bool)(resources.GetObject("label191.ShowHelp"))));
            // 
            // label192
            // 
            resources.ApplyResources(this.label192, "label192");
            this.label192.BackColor = System.Drawing.Color.Transparent;
            this.label192.Name = "label192";
            this.helpProvider1.SetShowHelp(this.label192, ((bool)(resources.GetObject("label192.ShowHelp"))));
            // 
            // label193
            // 
            resources.ApplyResources(this.label193, "label193");
            this.label193.BackColor = System.Drawing.Color.Transparent;
            this.label193.Name = "label193";
            this.helpProvider1.SetShowHelp(this.label193, ((bool)(resources.GetObject("label193.ShowHelp"))));
            // 
            // label194
            // 
            resources.ApplyResources(this.label194, "label194");
            this.label194.BackColor = System.Drawing.Color.Transparent;
            this.label194.Name = "label194";
            this.helpProvider1.SetShowHelp(this.label194, ((bool)(resources.GetObject("label194.ShowHelp"))));
            // 
            // label195
            // 
            resources.ApplyResources(this.label195, "label195");
            this.label195.BackColor = System.Drawing.Color.Transparent;
            this.label195.Name = "label195";
            this.helpProvider1.SetShowHelp(this.label195, ((bool)(resources.GetObject("label195.ShowHelp"))));
            // 
            // label196
            // 
            resources.ApplyResources(this.label196, "label196");
            this.label196.BackColor = System.Drawing.Color.Transparent;
            this.label196.Name = "label196";
            this.helpProvider1.SetShowHelp(this.label196, ((bool)(resources.GetObject("label196.ShowHelp"))));
            // 
            // label197
            // 
            resources.ApplyResources(this.label197, "label197");
            this.label197.BackColor = System.Drawing.Color.Transparent;
            this.label197.Name = "label197";
            this.helpProvider1.SetShowHelp(this.label197, ((bool)(resources.GetObject("label197.ShowHelp"))));
            // 
            // label198
            // 
            resources.ApplyResources(this.label198, "label198");
            this.label198.BackColor = System.Drawing.Color.Transparent;
            this.label198.Name = "label198";
            this.helpProvider1.SetShowHelp(this.label198, ((bool)(resources.GetObject("label198.ShowHelp"))));
            // 
            // label199
            // 
            resources.ApplyResources(this.label199, "label199");
            this.label199.BackColor = System.Drawing.Color.Transparent;
            this.label199.Name = "label199";
            this.helpProvider1.SetShowHelp(this.label199, ((bool)(resources.GetObject("label199.ShowHelp"))));
            // 
            // label200
            // 
            resources.ApplyResources(this.label200, "label200");
            this.label200.BackColor = System.Drawing.Color.Transparent;
            this.label200.Name = "label200";
            this.helpProvider1.SetShowHelp(this.label200, ((bool)(resources.GetObject("label200.ShowHelp"))));
            // 
            // label201
            // 
            resources.ApplyResources(this.label201, "label201");
            this.label201.BackColor = System.Drawing.Color.Transparent;
            this.label201.Name = "label201";
            this.helpProvider1.SetShowHelp(this.label201, ((bool)(resources.GetObject("label201.ShowHelp"))));
            // 
            // label202
            // 
            resources.ApplyResources(this.label202, "label202");
            this.label202.BackColor = System.Drawing.Color.Transparent;
            this.label202.Name = "label202";
            this.helpProvider1.SetShowHelp(this.label202, ((bool)(resources.GetObject("label202.ShowHelp"))));
            // 
            // label203
            // 
            resources.ApplyResources(this.label203, "label203");
            this.label203.BackColor = System.Drawing.Color.Transparent;
            this.label203.Name = "label203";
            this.helpProvider1.SetShowHelp(this.label203, ((bool)(resources.GetObject("label203.ShowHelp"))));
            // 
            // label204
            // 
            resources.ApplyResources(this.label204, "label204");
            this.label204.BackColor = System.Drawing.Color.Transparent;
            this.label204.Name = "label204";
            this.helpProvider1.SetShowHelp(this.label204, ((bool)(resources.GetObject("label204.ShowHelp"))));
            // 
            // label205
            // 
            resources.ApplyResources(this.label205, "label205");
            this.label205.BackColor = System.Drawing.Color.Transparent;
            this.label205.Name = "label205";
            this.helpProvider1.SetShowHelp(this.label205, ((bool)(resources.GetObject("label205.ShowHelp"))));
            // 
            // label206
            // 
            resources.ApplyResources(this.label206, "label206");
            this.label206.BackColor = System.Drawing.Color.Transparent;
            this.label206.Name = "label206";
            this.helpProvider1.SetShowHelp(this.label206, ((bool)(resources.GetObject("label206.ShowHelp"))));
            // 
            // label207
            // 
            resources.ApplyResources(this.label207, "label207");
            this.label207.BackColor = System.Drawing.Color.Transparent;
            this.label207.Name = "label207";
            this.helpProvider1.SetShowHelp(this.label207, ((bool)(resources.GetObject("label207.ShowHelp"))));
            // 
            // label208
            // 
            resources.ApplyResources(this.label208, "label208");
            this.label208.BackColor = System.Drawing.Color.Transparent;
            this.label208.Name = "label208";
            this.helpProvider1.SetShowHelp(this.label208, ((bool)(resources.GetObject("label208.ShowHelp"))));
            // 
            // label209
            // 
            resources.ApplyResources(this.label209, "label209");
            this.label209.BackColor = System.Drawing.Color.Transparent;
            this.label209.Name = "label209";
            this.helpProvider1.SetShowHelp(this.label209, ((bool)(resources.GetObject("label209.ShowHelp"))));
            // 
            // label210
            // 
            resources.ApplyResources(this.label210, "label210");
            this.label210.BackColor = System.Drawing.Color.Transparent;
            this.label210.Name = "label210";
            this.helpProvider1.SetShowHelp(this.label210, ((bool)(resources.GetObject("label210.ShowHelp"))));
            // 
            // label211
            // 
            resources.ApplyResources(this.label211, "label211");
            this.label211.BackColor = System.Drawing.Color.Transparent;
            this.label211.Name = "label211";
            this.helpProvider1.SetShowHelp(this.label211, ((bool)(resources.GetObject("label211.ShowHelp"))));
            // 
            // label212
            // 
            resources.ApplyResources(this.label212, "label212");
            this.label212.BackColor = System.Drawing.Color.Transparent;
            this.label212.Name = "label212";
            this.helpProvider1.SetShowHelp(this.label212, ((bool)(resources.GetObject("label212.ShowHelp"))));
            // 
            // label213
            // 
            resources.ApplyResources(this.label213, "label213");
            this.label213.BackColor = System.Drawing.Color.Transparent;
            this.label213.Name = "label213";
            this.helpProvider1.SetShowHelp(this.label213, ((bool)(resources.GetObject("label213.ShowHelp"))));
            // 
            // label214
            // 
            resources.ApplyResources(this.label214, "label214");
            this.label214.BackColor = System.Drawing.Color.Transparent;
            this.label214.Name = "label214";
            this.helpProvider1.SetShowHelp(this.label214, ((bool)(resources.GetObject("label214.ShowHelp"))));
            // 
            // label215
            // 
            resources.ApplyResources(this.label215, "label215");
            this.label215.BackColor = System.Drawing.Color.Transparent;
            this.label215.Name = "label215";
            this.helpProvider1.SetShowHelp(this.label215, ((bool)(resources.GetObject("label215.ShowHelp"))));
            // 
            // label216
            // 
            resources.ApplyResources(this.label216, "label216");
            this.label216.BackColor = System.Drawing.Color.Transparent;
            this.label216.Name = "label216";
            this.helpProvider1.SetShowHelp(this.label216, ((bool)(resources.GetObject("label216.ShowHelp"))));
            // 
            // label217
            // 
            resources.ApplyResources(this.label217, "label217");
            this.label217.BackColor = System.Drawing.Color.Transparent;
            this.label217.Name = "label217";
            this.helpProvider1.SetShowHelp(this.label217, ((bool)(resources.GetObject("label217.ShowHelp"))));
            // 
            // label218
            // 
            resources.ApplyResources(this.label218, "label218");
            this.label218.BackColor = System.Drawing.Color.Transparent;
            this.label218.Name = "label218";
            this.helpProvider1.SetShowHelp(this.label218, ((bool)(resources.GetObject("label218.ShowHelp"))));
            // 
            // label219
            // 
            resources.ApplyResources(this.label219, "label219");
            this.label219.BackColor = System.Drawing.Color.Transparent;
            this.label219.Name = "label219";
            this.helpProvider1.SetShowHelp(this.label219, ((bool)(resources.GetObject("label219.ShowHelp"))));
            // 
            // label220
            // 
            resources.ApplyResources(this.label220, "label220");
            this.label220.BackColor = System.Drawing.Color.Transparent;
            this.label220.Name = "label220";
            this.helpProvider1.SetShowHelp(this.label220, ((bool)(resources.GetObject("label220.ShowHelp"))));
            // 
            // label221
            // 
            resources.ApplyResources(this.label221, "label221");
            this.label221.BackColor = System.Drawing.Color.Transparent;
            this.label221.Name = "label221";
            this.helpProvider1.SetShowHelp(this.label221, ((bool)(resources.GetObject("label221.ShowHelp"))));
            // 
            // label222
            // 
            resources.ApplyResources(this.label222, "label222");
            this.label222.BackColor = System.Drawing.Color.Transparent;
            this.label222.Name = "label222";
            this.helpProvider1.SetShowHelp(this.label222, ((bool)(resources.GetObject("label222.ShowHelp"))));
            // 
            // label223
            // 
            resources.ApplyResources(this.label223, "label223");
            this.label223.BackColor = System.Drawing.Color.Transparent;
            this.label223.Name = "label223";
            this.helpProvider1.SetShowHelp(this.label223, ((bool)(resources.GetObject("label223.ShowHelp"))));
            // 
            // label224
            // 
            resources.ApplyResources(this.label224, "label224");
            this.label224.BackColor = System.Drawing.Color.Transparent;
            this.label224.Name = "label224";
            this.helpProvider1.SetShowHelp(this.label224, ((bool)(resources.GetObject("label224.ShowHelp"))));
            // 
            // label225
            // 
            resources.ApplyResources(this.label225, "label225");
            this.label225.BackColor = System.Drawing.Color.Transparent;
            this.label225.Name = "label225";
            this.helpProvider1.SetShowHelp(this.label225, ((bool)(resources.GetObject("label225.ShowHelp"))));
            // 
            // label226
            // 
            resources.ApplyResources(this.label226, "label226");
            this.label226.BackColor = System.Drawing.Color.Transparent;
            this.label226.Name = "label226";
            this.helpProvider1.SetShowHelp(this.label226, ((bool)(resources.GetObject("label226.ShowHelp"))));
            // 
            // label227
            // 
            resources.ApplyResources(this.label227, "label227");
            this.label227.BackColor = System.Drawing.Color.Transparent;
            this.label227.Name = "label227";
            this.helpProvider1.SetShowHelp(this.label227, ((bool)(resources.GetObject("label227.ShowHelp"))));
            // 
            // label228
            // 
            resources.ApplyResources(this.label228, "label228");
            this.label228.BackColor = System.Drawing.Color.Transparent;
            this.label228.Name = "label228";
            this.helpProvider1.SetShowHelp(this.label228, ((bool)(resources.GetObject("label228.ShowHelp"))));
            // 
            // label229
            // 
            resources.ApplyResources(this.label229, "label229");
            this.label229.BackColor = System.Drawing.Color.Transparent;
            this.label229.Name = "label229";
            this.helpProvider1.SetShowHelp(this.label229, ((bool)(resources.GetObject("label229.ShowHelp"))));
            // 
            // label230
            // 
            resources.ApplyResources(this.label230, "label230");
            this.label230.BackColor = System.Drawing.Color.Transparent;
            this.label230.Name = "label230";
            this.helpProvider1.SetShowHelp(this.label230, ((bool)(resources.GetObject("label230.ShowHelp"))));
            // 
            // label231
            // 
            resources.ApplyResources(this.label231, "label231");
            this.label231.BackColor = System.Drawing.Color.Transparent;
            this.label231.Name = "label231";
            this.helpProvider1.SetShowHelp(this.label231, ((bool)(resources.GetObject("label231.ShowHelp"))));
            // 
            // label232
            // 
            resources.ApplyResources(this.label232, "label232");
            this.label232.BackColor = System.Drawing.Color.Transparent;
            this.label232.Name = "label232";
            this.helpProvider1.SetShowHelp(this.label232, ((bool)(resources.GetObject("label232.ShowHelp"))));
            // 
            // label233
            // 
            resources.ApplyResources(this.label233, "label233");
            this.label233.BackColor = System.Drawing.Color.Transparent;
            this.label233.Name = "label233";
            this.helpProvider1.SetShowHelp(this.label233, ((bool)(resources.GetObject("label233.ShowHelp"))));
            // 
            // label234
            // 
            resources.ApplyResources(this.label234, "label234");
            this.label234.BackColor = System.Drawing.Color.Transparent;
            this.label234.Name = "label234";
            this.helpProvider1.SetShowHelp(this.label234, ((bool)(resources.GetObject("label234.ShowHelp"))));
            // 
            // label235
            // 
            resources.ApplyResources(this.label235, "label235");
            this.label235.BackColor = System.Drawing.Color.Transparent;
            this.label235.Name = "label235";
            this.helpProvider1.SetShowHelp(this.label235, ((bool)(resources.GetObject("label235.ShowHelp"))));
            // 
            // label236
            // 
            resources.ApplyResources(this.label236, "label236");
            this.label236.BackColor = System.Drawing.Color.Transparent;
            this.label236.Name = "label236";
            this.helpProvider1.SetShowHelp(this.label236, ((bool)(resources.GetObject("label236.ShowHelp"))));
            // 
            // label237
            // 
            resources.ApplyResources(this.label237, "label237");
            this.label237.BackColor = System.Drawing.Color.Transparent;
            this.label237.Name = "label237";
            this.helpProvider1.SetShowHelp(this.label237, ((bool)(resources.GetObject("label237.ShowHelp"))));
            // 
            // label238
            // 
            resources.ApplyResources(this.label238, "label238");
            this.label238.BackColor = System.Drawing.Color.Transparent;
            this.label238.Name = "label238";
            this.helpProvider1.SetShowHelp(this.label238, ((bool)(resources.GetObject("label238.ShowHelp"))));
            // 
            // label239
            // 
            resources.ApplyResources(this.label239, "label239");
            this.label239.BackColor = System.Drawing.Color.Transparent;
            this.label239.Name = "label239";
            this.helpProvider1.SetShowHelp(this.label239, ((bool)(resources.GetObject("label239.ShowHelp"))));
            // 
            // label240
            // 
            resources.ApplyResources(this.label240, "label240");
            this.label240.BackColor = System.Drawing.Color.Transparent;
            this.label240.Name = "label240";
            this.helpProvider1.SetShowHelp(this.label240, ((bool)(resources.GetObject("label240.ShowHelp"))));
            // 
            // label241
            // 
            resources.ApplyResources(this.label241, "label241");
            this.label241.BackColor = System.Drawing.Color.Transparent;
            this.label241.Name = "label241";
            this.helpProvider1.SetShowHelp(this.label241, ((bool)(resources.GetObject("label241.ShowHelp"))));
            // 
            // label242
            // 
            resources.ApplyResources(this.label242, "label242");
            this.label242.BackColor = System.Drawing.Color.Transparent;
            this.label242.Name = "label242";
            this.helpProvider1.SetShowHelp(this.label242, ((bool)(resources.GetObject("label242.ShowHelp"))));
            // 
            // label243
            // 
            resources.ApplyResources(this.label243, "label243");
            this.label243.BackColor = System.Drawing.Color.Transparent;
            this.label243.Name = "label243";
            this.helpProvider1.SetShowHelp(this.label243, ((bool)(resources.GetObject("label243.ShowHelp"))));
            // 
            // label244
            // 
            resources.ApplyResources(this.label244, "label244");
            this.label244.BackColor = System.Drawing.Color.Transparent;
            this.label244.Name = "label244";
            this.helpProvider1.SetShowHelp(this.label244, ((bool)(resources.GetObject("label244.ShowHelp"))));
            // 
            // label245
            // 
            resources.ApplyResources(this.label245, "label245");
            this.label245.BackColor = System.Drawing.Color.Transparent;
            this.label245.Name = "label245";
            this.helpProvider1.SetShowHelp(this.label245, ((bool)(resources.GetObject("label245.ShowHelp"))));
            // 
            // label246
            // 
            resources.ApplyResources(this.label246, "label246");
            this.label246.BackColor = System.Drawing.Color.Transparent;
            this.label246.Name = "label246";
            this.helpProvider1.SetShowHelp(this.label246, ((bool)(resources.GetObject("label246.ShowHelp"))));
            // 
            // label247
            // 
            resources.ApplyResources(this.label247, "label247");
            this.label247.BackColor = System.Drawing.Color.Transparent;
            this.label247.Name = "label247";
            this.helpProvider1.SetShowHelp(this.label247, ((bool)(resources.GetObject("label247.ShowHelp"))));
            // 
            // label248
            // 
            resources.ApplyResources(this.label248, "label248");
            this.label248.BackColor = System.Drawing.Color.Transparent;
            this.label248.Name = "label248";
            this.helpProvider1.SetShowHelp(this.label248, ((bool)(resources.GetObject("label248.ShowHelp"))));
            // 
            // label249
            // 
            resources.ApplyResources(this.label249, "label249");
            this.label249.BackColor = System.Drawing.Color.Transparent;
            this.label249.Name = "label249";
            this.helpProvider1.SetShowHelp(this.label249, ((bool)(resources.GetObject("label249.ShowHelp"))));
            // 
            // label250
            // 
            resources.ApplyResources(this.label250, "label250");
            this.label250.BackColor = System.Drawing.Color.Transparent;
            this.label250.Name = "label250";
            this.helpProvider1.SetShowHelp(this.label250, ((bool)(resources.GetObject("label250.ShowHelp"))));
            // 
            // label251
            // 
            resources.ApplyResources(this.label251, "label251");
            this.label251.BackColor = System.Drawing.Color.Transparent;
            this.label251.Name = "label251";
            this.helpProvider1.SetShowHelp(this.label251, ((bool)(resources.GetObject("label251.ShowHelp"))));
            // 
            // label252
            // 
            resources.ApplyResources(this.label252, "label252");
            this.label252.BackColor = System.Drawing.Color.Transparent;
            this.label252.Name = "label252";
            this.helpProvider1.SetShowHelp(this.label252, ((bool)(resources.GetObject("label252.ShowHelp"))));
            // 
            // label253
            // 
            resources.ApplyResources(this.label253, "label253");
            this.label253.BackColor = System.Drawing.Color.Transparent;
            this.label253.Name = "label253";
            this.helpProvider1.SetShowHelp(this.label253, ((bool)(resources.GetObject("label253.ShowHelp"))));
            // 
            // label254
            // 
            resources.ApplyResources(this.label254, "label254");
            this.label254.BackColor = System.Drawing.Color.Transparent;
            this.label254.Name = "label254";
            this.helpProvider1.SetShowHelp(this.label254, ((bool)(resources.GetObject("label254.ShowHelp"))));
            // 
            // label255
            // 
            resources.ApplyResources(this.label255, "label255");
            this.label255.BackColor = System.Drawing.Color.Transparent;
            this.label255.Name = "label255";
            this.helpProvider1.SetShowHelp(this.label255, ((bool)(resources.GetObject("label255.ShowHelp"))));
            // 
            // label256
            // 
            resources.ApplyResources(this.label256, "label256");
            this.label256.BackColor = System.Drawing.Color.Transparent;
            this.label256.Name = "label256";
            this.helpProvider1.SetShowHelp(this.label256, ((bool)(resources.GetObject("label256.ShowHelp"))));
            // 
            // label257
            // 
            resources.ApplyResources(this.label257, "label257");
            this.label257.BackColor = System.Drawing.Color.Transparent;
            this.label257.Name = "label257";
            this.helpProvider1.SetShowHelp(this.label257, ((bool)(resources.GetObject("label257.ShowHelp"))));
            // 
            // label258
            // 
            resources.ApplyResources(this.label258, "label258");
            this.label258.Name = "label258";
            this.helpProvider1.SetShowHelp(this.label258, ((bool)(resources.GetObject("label258.ShowHelp"))));
            // 
            // label259
            // 
            resources.ApplyResources(this.label259, "label259");
            this.label259.Name = "label259";
            this.helpProvider1.SetShowHelp(this.label259, ((bool)(resources.GetObject("label259.ShowHelp"))));
            // 
            // label260
            // 
            resources.ApplyResources(this.label260, "label260");
            this.label260.Name = "label260";
            this.helpProvider1.SetShowHelp(this.label260, ((bool)(resources.GetObject("label260.ShowHelp"))));
            // 
            // label261
            // 
            resources.ApplyResources(this.label261, "label261");
            this.label261.Name = "label261";
            this.helpProvider1.SetShowHelp(this.label261, ((bool)(resources.GetObject("label261.ShowHelp"))));
            // 
            // label262
            // 
            resources.ApplyResources(this.label262, "label262");
            this.label262.Name = "label262";
            this.helpProvider1.SetShowHelp(this.label262, ((bool)(resources.GetObject("label262.ShowHelp"))));
            // 
            // label263
            // 
            resources.ApplyResources(this.label263, "label263");
            this.label263.Name = "label263";
            this.helpProvider1.SetShowHelp(this.label263, ((bool)(resources.GetObject("label263.ShowHelp"))));
            // 
            // label264
            // 
            resources.ApplyResources(this.label264, "label264");
            this.label264.Name = "label264";
            this.helpProvider1.SetShowHelp(this.label264, ((bool)(resources.GetObject("label264.ShowHelp"))));
            // 
            // label265
            // 
            resources.ApplyResources(this.label265, "label265");
            this.label265.Name = "label265";
            this.helpProvider1.SetShowHelp(this.label265, ((bool)(resources.GetObject("label265.ShowHelp"))));
            // 
            // label266
            // 
            resources.ApplyResources(this.label266, "label266");
            this.label266.Name = "label266";
            this.helpProvider1.SetShowHelp(this.label266, ((bool)(resources.GetObject("label266.ShowHelp"))));
            // 
            // label267
            // 
            resources.ApplyResources(this.label267, "label267");
            this.label267.Name = "label267";
            this.helpProvider1.SetShowHelp(this.label267, ((bool)(resources.GetObject("label267.ShowHelp"))));
            // 
            // label268
            // 
            resources.ApplyResources(this.label268, "label268");
            this.label268.Name = "label268";
            this.helpProvider1.SetShowHelp(this.label268, ((bool)(resources.GetObject("label268.ShowHelp"))));
            // 
            // label269
            // 
            resources.ApplyResources(this.label269, "label269");
            this.label269.Name = "label269";
            this.helpProvider1.SetShowHelp(this.label269, ((bool)(resources.GetObject("label269.ShowHelp"))));
            // 
            // p3plus_20
            // 
            this.p3plus_20.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_20.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_20, "p3plus_20");
            this.p3plus_20.Name = "p3plus_20";
            this.p3plus_20.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_20, ((bool)(resources.GetObject("p3plus_20.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_20, resources.GetString("p3plus_20.ToolTip"));
            // 
            // p3r_20
            // 
            this.p3r_20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_20, "p3r_20");
            this.p3r_20.Name = "p3r_20";
            this.helpProvider1.SetShowHelp(this.p3r_20, ((bool)(resources.GetObject("p3r_20.ShowHelp"))));
            // 
            // p3ls_20
            // 
            this.p3ls_20.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_20.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_20, "p3ls_20");
            this.p3ls_20.Name = "p3ls_20";
            this.p3ls_20.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_20, ((bool)(resources.GetObject("p3ls_20.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_20, resources.GetString("p3ls_20.ToolTip"));
            // 
            // p3iws_20
            // 
            this.p3iws_20.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3iws_20.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_20, "p3iws_20");
            this.p3iws_20.Name = "p3iws_20";
            this.p3iws_20.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_20, ((bool)(resources.GetObject("p3iws_20.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_20, resources.GetString("p3iws_20.ToolTip"));
            // 
            // p3ib_20
            // 
            this.p3ib_20.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_20.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_20, "p3ib_20");
            this.p3ib_20.Name = "p3ib_20";
            this.p3ib_20.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_20, ((bool)(resources.GetObject("p3ib_20.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_20, resources.GetString("p3ib_20.ToolTip"));
            // 
            // p3pm_20
            // 
            this.p3pm_20.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3pm_20.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_20, "p3pm_20");
            this.p3pm_20.Name = "p3pm_20";
            this.p3pm_20.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_20, ((bool)(resources.GetObject("p3pm_20.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_20, resources.GetString("p3pm_20.ToolTip"));
            // 
            // p3vw_20
            // 
            this.p3vw_20.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_20.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_20, "p3vw_20");
            this.p3vw_20.Name = "p3vw_20";
            this.p3vw_20.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_20, ((bool)(resources.GetObject("p3vw_20.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_20, resources.GetString("p3vw_20.ToolTip"));
            // 
            // p3plus_9
            // 
            this.p3plus_9.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_9.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_9, "p3plus_9");
            this.p3plus_9.Name = "p3plus_9";
            this.p3plus_9.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_9, ((bool)(resources.GetObject("p3plus_9.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_9, resources.GetString("p3plus_9.ToolTip"));
            // 
            // p3r_9
            // 
            this.p3r_9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_9, "p3r_9");
            this.p3r_9.Name = "p3r_9";
            this.helpProvider1.SetShowHelp(this.p3r_9, ((bool)(resources.GetObject("p3r_9.ShowHelp"))));
            // 
            // p3ls_9
            // 
            this.p3ls_9.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_9.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_9, "p3ls_9");
            this.p3ls_9.Name = "p3ls_9";
            this.p3ls_9.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_9, ((bool)(resources.GetObject("p3ls_9.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_9, resources.GetString("p3ls_9.ToolTip"));
            // 
            // p3iws_9
            // 
            this.p3iws_9.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3iws_9.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_9, "p3iws_9");
            this.p3iws_9.Name = "p3iws_9";
            this.p3iws_9.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_9, ((bool)(resources.GetObject("p3iws_9.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_9, resources.GetString("p3iws_9.ToolTip"));
            // 
            // p3ib_9
            // 
            this.p3ib_9.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_9.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_9, "p3ib_9");
            this.p3ib_9.Name = "p3ib_9";
            this.p3ib_9.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_9, ((bool)(resources.GetObject("p3ib_9.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_9, resources.GetString("p3ib_9.ToolTip"));
            // 
            // p3pm_9
            // 
            this.p3pm_9.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3pm_9.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_9, "p3pm_9");
            this.p3pm_9.Name = "p3pm_9";
            this.p3pm_9.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_9, ((bool)(resources.GetObject("p3pm_9.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_9, resources.GetString("p3pm_9.ToolTip"));
            // 
            // p3vw_9
            // 
            this.p3vw_9.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_9.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_9, "p3vw_9");
            this.p3vw_9.Name = "p3vw_9";
            this.p3vw_9.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_9, ((bool)(resources.GetObject("p3vw_9.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_9, resources.GetString("p3vw_9.ToolTip"));
            // 
            // p3plus_15
            // 
            this.p3plus_15.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_15.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_15, "p3plus_15");
            this.p3plus_15.Name = "p3plus_15";
            this.p3plus_15.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_15, ((bool)(resources.GetObject("p3plus_15.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_15, resources.GetString("p3plus_15.ToolTip"));
            // 
            // p3r_15
            // 
            this.p3r_15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_15, "p3r_15");
            this.p3r_15.Name = "p3r_15";
            this.helpProvider1.SetShowHelp(this.p3r_15, ((bool)(resources.GetObject("p3r_15.ShowHelp"))));
            // 
            // p3ls_15
            // 
            this.p3ls_15.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_15.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_15, "p3ls_15");
            this.p3ls_15.Name = "p3ls_15";
            this.p3ls_15.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_15, ((bool)(resources.GetObject("p3ls_15.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_15, resources.GetString("p3ls_15.ToolTip"));
            // 
            // p3iws_15
            // 
            this.p3iws_15.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3iws_15.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_15, "p3iws_15");
            this.p3iws_15.Name = "p3iws_15";
            this.p3iws_15.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_15, ((bool)(resources.GetObject("p3iws_15.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_15, resources.GetString("p3iws_15.ToolTip"));
            // 
            // p3ib_15
            // 
            this.p3ib_15.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_15.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_15, "p3ib_15");
            this.p3ib_15.Name = "p3ib_15";
            this.p3ib_15.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_15, ((bool)(resources.GetObject("p3ib_15.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_15, resources.GetString("p3ib_15.ToolTip"));
            // 
            // p3pm_15
            // 
            this.p3pm_15.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3pm_15.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_15, "p3pm_15");
            this.p3pm_15.Name = "p3pm_15";
            this.p3pm_15.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_15, ((bool)(resources.GetObject("p3pm_15.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_15, resources.GetString("p3pm_15.ToolTip"));
            // 
            // p3vw_15
            // 
            this.p3vw_15.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_15.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_15, "p3vw_15");
            this.p3vw_15.Name = "p3vw_15";
            this.p3vw_15.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_15, ((bool)(resources.GetObject("p3vw_15.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_15, resources.GetString("p3vw_15.ToolTip"));
            // 
            // p3plus_29
            // 
            this.p3plus_29.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_29.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_29, "p3plus_29");
            this.p3plus_29.Name = "p3plus_29";
            this.p3plus_29.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_29, ((bool)(resources.GetObject("p3plus_29.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_29, resources.GetString("p3plus_29.ToolTip"));
            // 
            // p3r_29
            // 
            this.p3r_29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_29, "p3r_29");
            this.p3r_29.Name = "p3r_29";
            this.helpProvider1.SetShowHelp(this.p3r_29, ((bool)(resources.GetObject("p3r_29.ShowHelp"))));
            // 
            // p3ls_29
            // 
            this.p3ls_29.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_29.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_29, "p3ls_29");
            this.p3ls_29.Name = "p3ls_29";
            this.p3ls_29.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_29, ((bool)(resources.GetObject("p3ls_29.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_29, resources.GetString("p3ls_29.ToolTip"));
            // 
            // p3iws_29
            // 
            this.p3iws_29.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3iws_29.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_29, "p3iws_29");
            this.p3iws_29.Name = "p3iws_29";
            this.p3iws_29.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_29, ((bool)(resources.GetObject("p3iws_29.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_29, resources.GetString("p3iws_29.ToolTip"));
            // 
            // p3ib_29
            // 
            this.p3ib_29.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_29.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_29, "p3ib_29");
            this.p3ib_29.Name = "p3ib_29";
            this.p3ib_29.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_29, ((bool)(resources.GetObject("p3ib_29.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_29, resources.GetString("p3ib_29.ToolTip"));
            // 
            // p3pm_29
            // 
            this.p3pm_29.BackColor = System.Drawing.Color.MistyRose;
            this.p3pm_29.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_29, "p3pm_29");
            this.p3pm_29.Name = "p3pm_29";
            this.p3pm_29.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_29, ((bool)(resources.GetObject("p3pm_29.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_29, resources.GetString("p3pm_29.ToolTip"));
            // 
            // p3vw_29
            // 
            this.p3vw_29.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_29.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_29, "p3vw_29");
            this.p3vw_29.Name = "p3vw_29";
            this.p3vw_29.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_29, ((bool)(resources.GetObject("p3vw_29.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_29, resources.GetString("p3vw_29.ToolTip"));
            // 
            // p3plus_6
            // 
            this.p3plus_6.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_6.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_6, "p3plus_6");
            this.p3plus_6.Name = "p3plus_6";
            this.p3plus_6.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_6, ((bool)(resources.GetObject("p3plus_6.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_6, resources.GetString("p3plus_6.ToolTip"));
            // 
            // p3r_6
            // 
            this.p3r_6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_6, "p3r_6");
            this.p3r_6.Name = "p3r_6";
            this.helpProvider1.SetShowHelp(this.p3r_6, ((bool)(resources.GetObject("p3r_6.ShowHelp"))));
            // 
            // p3ls_6
            // 
            this.p3ls_6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_6.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_6, "p3ls_6");
            this.p3ls_6.Name = "p3ls_6";
            this.p3ls_6.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_6, ((bool)(resources.GetObject("p3ls_6.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_6, resources.GetString("p3ls_6.ToolTip"));
            // 
            // p3iws_6
            // 
            this.p3iws_6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3iws_6.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_6, "p3iws_6");
            this.p3iws_6.Name = "p3iws_6";
            this.p3iws_6.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_6, ((bool)(resources.GetObject("p3iws_6.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_6, resources.GetString("p3iws_6.ToolTip"));
            // 
            // p3ib_6
            // 
            this.p3ib_6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_6.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_6, "p3ib_6");
            this.p3ib_6.Name = "p3ib_6";
            this.p3ib_6.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_6, ((bool)(resources.GetObject("p3ib_6.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_6, resources.GetString("p3ib_6.ToolTip"));
            // 
            // p3pm_6
            // 
            this.p3pm_6.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3pm_6.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_6, "p3pm_6");
            this.p3pm_6.Name = "p3pm_6";
            this.p3pm_6.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_6, ((bool)(resources.GetObject("p3pm_6.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_6, resources.GetString("p3pm_6.ToolTip"));
            // 
            // p3vw_6
            // 
            this.p3vw_6.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_6.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_6, "p3vw_6");
            this.p3vw_6.Name = "p3vw_6";
            this.p3vw_6.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_6, ((bool)(resources.GetObject("p3vw_6.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_6, resources.GetString("p3vw_6.ToolTip"));
            // 
            // p3plus_12
            // 
            this.p3plus_12.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_12.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_12, "p3plus_12");
            this.p3plus_12.Name = "p3plus_12";
            this.p3plus_12.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_12, ((bool)(resources.GetObject("p3plus_12.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_12, resources.GetString("p3plus_12.ToolTip"));
            // 
            // p3r_12
            // 
            this.p3r_12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_12, "p3r_12");
            this.p3r_12.Name = "p3r_12";
            this.helpProvider1.SetShowHelp(this.p3r_12, ((bool)(resources.GetObject("p3r_12.ShowHelp"))));
            // 
            // p3ls_12
            // 
            this.p3ls_12.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_12.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_12, "p3ls_12");
            this.p3ls_12.Name = "p3ls_12";
            this.p3ls_12.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_12, ((bool)(resources.GetObject("p3ls_12.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_12, resources.GetString("p3ls_12.ToolTip"));
            // 
            // p3iws_12
            // 
            this.p3iws_12.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3iws_12.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_12, "p3iws_12");
            this.p3iws_12.Name = "p3iws_12";
            this.p3iws_12.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_12, ((bool)(resources.GetObject("p3iws_12.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_12, resources.GetString("p3iws_12.ToolTip"));
            // 
            // p3ib_12
            // 
            this.p3ib_12.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_12.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_12, "p3ib_12");
            this.p3ib_12.Name = "p3ib_12";
            this.p3ib_12.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_12, ((bool)(resources.GetObject("p3ib_12.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_12, resources.GetString("p3ib_12.ToolTip"));
            // 
            // p3pm_12
            // 
            this.p3pm_12.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3pm_12.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_12, "p3pm_12");
            this.p3pm_12.Name = "p3pm_12";
            this.p3pm_12.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_12, ((bool)(resources.GetObject("p3pm_12.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_12, resources.GetString("p3pm_12.ToolTip"));
            // 
            // p3vw_12
            // 
            this.p3vw_12.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_12.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_12, "p3vw_12");
            this.p3vw_12.Name = "p3vw_12";
            this.p3vw_12.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_12, ((bool)(resources.GetObject("p3vw_12.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_12, resources.GetString("p3vw_12.ToolTip"));
            // 
            // p3plus_30
            // 
            this.p3plus_30.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_30.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_30, "p3plus_30");
            this.p3plus_30.Name = "p3plus_30";
            this.p3plus_30.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_30, ((bool)(resources.GetObject("p3plus_30.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_30, resources.GetString("p3plus_30.ToolTip"));
            // 
            // p3r_30
            // 
            this.p3r_30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_30, "p3r_30");
            this.p3r_30.Name = "p3r_30";
            this.helpProvider1.SetShowHelp(this.p3r_30, ((bool)(resources.GetObject("p3r_30.ShowHelp"))));
            // 
            // p3ls_30
            // 
            this.p3ls_30.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_30.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_30, "p3ls_30");
            this.p3ls_30.Name = "p3ls_30";
            this.p3ls_30.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_30, ((bool)(resources.GetObject("p3ls_30.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_30, resources.GetString("p3ls_30.ToolTip"));
            // 
            // p3iws_30
            // 
            this.p3iws_30.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3iws_30.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_30, "p3iws_30");
            this.p3iws_30.Name = "p3iws_30";
            this.p3iws_30.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_30, ((bool)(resources.GetObject("p3iws_30.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_30, resources.GetString("p3iws_30.ToolTip"));
            // 
            // p3ib_30
            // 
            this.p3ib_30.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_30.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_30, "p3ib_30");
            this.p3ib_30.Name = "p3ib_30";
            this.p3ib_30.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_30, ((bool)(resources.GetObject("p3ib_30.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_30, resources.GetString("p3ib_30.ToolTip"));
            // 
            // p3pm_30
            // 
            this.p3pm_30.BackColor = System.Drawing.Color.MistyRose;
            this.p3pm_30.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_30, "p3pm_30");
            this.p3pm_30.Name = "p3pm_30";
            this.p3pm_30.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_30, ((bool)(resources.GetObject("p3pm_30.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_30, resources.GetString("p3pm_30.ToolTip"));
            // 
            // p3vw_30
            // 
            this.p3vw_30.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_30.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_30, "p3vw_30");
            this.p3vw_30.Name = "p3vw_30";
            this.p3vw_30.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_30, ((bool)(resources.GetObject("p3vw_30.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_30, resources.GetString("p3vw_30.ToolTip"));
            // 
            // p3plus_16
            // 
            this.p3plus_16.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_16, "p3plus_16");
            this.p3plus_16.Name = "p3plus_16";
            this.p3plus_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_16, ((bool)(resources.GetObject("p3plus_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_16, resources.GetString("p3plus_16.ToolTip"));
            // 
            // p3r_16
            // 
            this.p3r_16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_16, "p3r_16");
            this.p3r_16.Name = "p3r_16";
            this.helpProvider1.SetShowHelp(this.p3r_16, ((bool)(resources.GetObject("p3r_16.ShowHelp"))));
            // 
            // p3ls_16
            // 
            this.p3ls_16.BackColor = System.Drawing.SystemColors.Window;
            this.p3ls_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_16, "p3ls_16");
            this.p3ls_16.Name = "p3ls_16";
            this.p3ls_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_16, ((bool)(resources.GetObject("p3ls_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_16, resources.GetString("p3ls_16.ToolTip"));
            // 
            // p3iws_16
            // 
            this.p3iws_16.BackColor = System.Drawing.SystemColors.Window;
            this.p3iws_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_16, "p3iws_16");
            this.p3iws_16.Name = "p3iws_16";
            this.p3iws_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_16, ((bool)(resources.GetObject("p3iws_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_16, resources.GetString("p3iws_16.ToolTip"));
            // 
            // p3ib_16
            // 
            this.p3ib_16.BackColor = System.Drawing.SystemColors.Window;
            this.p3ib_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_16, "p3ib_16");
            this.p3ib_16.Name = "p3ib_16";
            this.p3ib_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_16, ((bool)(resources.GetObject("p3ib_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_16, resources.GetString("p3ib_16.ToolTip"));
            // 
            // p3pm_16
            // 
            this.p3pm_16.BackColor = System.Drawing.Color.LemonChiffon;
            this.p3pm_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_16, "p3pm_16");
            this.p3pm_16.Name = "p3pm_16";
            this.p3pm_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_16, ((bool)(resources.GetObject("p3pm_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_16, resources.GetString("p3pm_16.ToolTip"));
            // 
            // p3vw_16
            // 
            this.p3vw_16.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_16.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_16, "p3vw_16");
            this.p3vw_16.Name = "p3vw_16";
            this.p3vw_16.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_16, ((bool)(resources.GetObject("p3vw_16.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_16, resources.GetString("p3vw_16.ToolTip"));
            // 
            // p3plus_17
            // 
            this.p3plus_17.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_17, "p3plus_17");
            this.p3plus_17.Name = "p3plus_17";
            this.p3plus_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_17, ((bool)(resources.GetObject("p3plus_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_17, resources.GetString("p3plus_17.ToolTip"));
            // 
            // p3r_17
            // 
            this.p3r_17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_17, "p3r_17");
            this.p3r_17.Name = "p3r_17";
            this.helpProvider1.SetShowHelp(this.p3r_17, ((bool)(resources.GetObject("p3r_17.ShowHelp"))));
            // 
            // p3ls_17
            // 
            this.p3ls_17.BackColor = System.Drawing.SystemColors.Window;
            this.p3ls_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_17, "p3ls_17");
            this.p3ls_17.Name = "p3ls_17";
            this.p3ls_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_17, ((bool)(resources.GetObject("p3ls_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_17, resources.GetString("p3ls_17.ToolTip"));
            // 
            // p3iws_17
            // 
            this.p3iws_17.BackColor = System.Drawing.SystemColors.Window;
            this.p3iws_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_17, "p3iws_17");
            this.p3iws_17.Name = "p3iws_17";
            this.p3iws_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_17, ((bool)(resources.GetObject("p3iws_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_17, resources.GetString("p3iws_17.ToolTip"));
            // 
            // p3ib_17
            // 
            this.p3ib_17.BackColor = System.Drawing.SystemColors.Window;
            this.p3ib_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_17, "p3ib_17");
            this.p3ib_17.Name = "p3ib_17";
            this.p3ib_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_17, ((bool)(resources.GetObject("p3ib_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_17, resources.GetString("p3ib_17.ToolTip"));
            // 
            // p3pm_17
            // 
            this.p3pm_17.BackColor = System.Drawing.Color.LemonChiffon;
            this.p3pm_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_17, "p3pm_17");
            this.p3pm_17.Name = "p3pm_17";
            this.p3pm_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_17, ((bool)(resources.GetObject("p3pm_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_17, resources.GetString("p3pm_17.ToolTip"));
            // 
            // p3vw_17
            // 
            this.p3vw_17.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_17.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_17, "p3vw_17");
            this.p3vw_17.Name = "p3vw_17";
            this.p3vw_17.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_17, ((bool)(resources.GetObject("p3vw_17.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_17, resources.GetString("p3vw_17.ToolTip"));
            // 
            // p3plus_26
            // 
            this.p3plus_26.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_26, "p3plus_26");
            this.p3plus_26.Name = "p3plus_26";
            this.p3plus_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_26, ((bool)(resources.GetObject("p3plus_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_26, resources.GetString("p3plus_26.ToolTip"));
            // 
            // p3r_26
            // 
            this.p3r_26.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_26, "p3r_26");
            this.p3r_26.Name = "p3r_26";
            this.helpProvider1.SetShowHelp(this.p3r_26, ((bool)(resources.GetObject("p3r_26.ShowHelp"))));
            // 
            // p3ls_26
            // 
            this.p3ls_26.BackColor = System.Drawing.SystemColors.Window;
            this.p3ls_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_26, "p3ls_26");
            this.p3ls_26.Name = "p3ls_26";
            this.p3ls_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_26, ((bool)(resources.GetObject("p3ls_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_26, resources.GetString("p3ls_26.ToolTip"));
            // 
            // p3iws_26
            // 
            this.p3iws_26.BackColor = System.Drawing.SystemColors.Window;
            this.p3iws_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_26, "p3iws_26");
            this.p3iws_26.Name = "p3iws_26";
            this.p3iws_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_26, ((bool)(resources.GetObject("p3iws_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_26, resources.GetString("p3iws_26.ToolTip"));
            // 
            // p3ib_26
            // 
            this.p3ib_26.BackColor = System.Drawing.SystemColors.Window;
            this.p3ib_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_26, "p3ib_26");
            this.p3ib_26.Name = "p3ib_26";
            this.p3ib_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_26, ((bool)(resources.GetObject("p3ib_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_26, resources.GetString("p3ib_26.ToolTip"));
            // 
            // p3pm_26
            // 
            this.p3pm_26.BackColor = System.Drawing.Color.LemonChiffon;
            this.p3pm_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_26, "p3pm_26");
            this.p3pm_26.Name = "p3pm_26";
            this.p3pm_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_26, ((bool)(resources.GetObject("p3pm_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_26, resources.GetString("p3pm_26.ToolTip"));
            // 
            // p3vw_26
            // 
            this.p3vw_26.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_26.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_26, "p3vw_26");
            this.p3vw_26.Name = "p3vw_26";
            this.p3vw_26.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_26, ((bool)(resources.GetObject("p3vw_26.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_26, resources.GetString("p3vw_26.ToolTip"));
            // 
            // p3plus_31
            // 
            this.p3plus_31.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3plus_31.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3plus_31, "p3plus_31");
            this.p3plus_31.Name = "p3plus_31";
            this.p3plus_31.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3plus_31, ((bool)(resources.GetObject("p3plus_31.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3plus_31, resources.GetString("p3plus_31.ToolTip"));
            // 
            // p3r_31
            // 
            this.p3r_31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_31, "p3r_31");
            this.p3r_31.Name = "p3r_31";
            this.helpProvider1.SetShowHelp(this.p3r_31, ((bool)(resources.GetObject("p3r_31.ShowHelp"))));
            // 
            // p3ls_31
            // 
            this.p3ls_31.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_31.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_31, "p3ls_31");
            this.p3ls_31.Name = "p3ls_31";
            this.p3ls_31.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_31, ((bool)(resources.GetObject("p3ls_31.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_31, resources.GetString("p3ls_31.ToolTip"));
            // 
            // p3iws_31
            // 
            this.p3iws_31.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3iws_31.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_31, "p3iws_31");
            this.p3iws_31.Name = "p3iws_31";
            this.p3iws_31.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_31, ((bool)(resources.GetObject("p3iws_31.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_31, resources.GetString("p3iws_31.ToolTip"));
            // 
            // p3ib_31
            // 
            this.p3ib_31.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_31.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_31, "p3ib_31");
            this.p3ib_31.Name = "p3ib_31";
            this.p3ib_31.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_31, ((bool)(resources.GetObject("p3ib_31.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_31, resources.GetString("p3ib_31.ToolTip"));
            // 
            // p3pm_31
            // 
            this.p3pm_31.BackColor = System.Drawing.Color.MistyRose;
            this.p3pm_31.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_31, "p3pm_31");
            this.p3pm_31.Name = "p3pm_31";
            this.p3pm_31.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_31, ((bool)(resources.GetObject("p3pm_31.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_31, resources.GetString("p3pm_31.ToolTip"));
            // 
            // p3vw_31
            // 
            this.p3vw_31.BackColor = System.Drawing.Color.MistyRose;
            this.p3vw_31.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3vw_31, "p3vw_31");
            this.p3vw_31.Name = "p3vw_31";
            this.p3vw_31.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3vw_31, ((bool)(resources.GetObject("p3vw_31.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3vw_31, resources.GetString("p3vw_31.ToolTip"));
            // 
            // p3r_0
            // 
            this.p3r_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3r_0, "p3r_0");
            this.p3r_0.Name = "p3r_0";
            this.helpProvider1.SetShowHelp(this.p3r_0, ((bool)(resources.GetObject("p3r_0.ShowHelp"))));
            // 
            // p3ls_0
            // 
            this.p3ls_0.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ls_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ls_0, "p3ls_0");
            this.p3ls_0.Name = "p3ls_0";
            this.p3ls_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ls_0, ((bool)(resources.GetObject("p3ls_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ls_0, resources.GetString("p3ls_0.ToolTip"));
            // 
            // p3iws_0
            // 
            this.p3iws_0.BackColor = System.Drawing.Color.AntiqueWhite;
            this.p3iws_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3iws_0, "p3iws_0");
            this.p3iws_0.Name = "p3iws_0";
            this.p3iws_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3iws_0, ((bool)(resources.GetObject("p3iws_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3iws_0, resources.GetString("p3iws_0.ToolTip"));
            // 
            // p3ib_0
            // 
            this.p3ib_0.BackColor = System.Drawing.SystemColors.InactiveBorder;
            this.p3ib_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3ib_0, "p3ib_0");
            this.p3ib_0.Name = "p3ib_0";
            this.p3ib_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3ib_0, ((bool)(resources.GetObject("p3ib_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3ib_0, resources.GetString("p3ib_0.ToolTip"));
            // 
            // p3pm_0
            // 
            this.p3pm_0.BackColor = System.Drawing.Color.MistyRose;
            this.p3pm_0.Cursor = System.Windows.Forms.Cursors.No;
            resources.ApplyResources(this.p3pm_0, "p3pm_0");
            this.p3pm_0.Name = "p3pm_0";
            this.p3pm_0.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.p3pm_0, ((bool)(resources.GetObject("p3pm_0.ShowHelp"))));
            this.toolTip.SetToolTip(this.p3pm_0, resources.GetString("p3pm_0.ToolTip"));
            // 
            // p3vw_0
            // 
            this.p3vw_0.BackColor = System.Drawing.Color.LightYellow;
            this.p3vw_0.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.p3vw_0, "p3vw_0");
            this.p3vw_0.Name = "p3vw_0";
            this.helpProvider1.SetShowHelp(this.p3vw_0, ((bool)(resources.GetObject("p3vw_0.ShowHelp"))));
            // 
            // tab_eTeil
            // 
            this.tab_eTeil.BackColor = System.Drawing.Color.Transparent;
            this.tab_eTeil.Controls.Add(this.dataGridViewETeil);
            resources.ApplyResources(this.tab_eTeil, "tab_eTeil");
            this.tab_eTeil.Name = "tab_eTeil";
            this.helpProvider1.SetShowHelp(this.tab_eTeil, ((bool)(resources.GetObject("tab_eTeil.ShowHelp"))));
            // 
            // dataGridViewETeil
            // 
            this.dataGridViewETeil.AllowUserToAddRows = false;
            this.dataGridViewETeil.AllowUserToDeleteRows = false;
            this.dataGridViewETeil.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewETeil.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewETeil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewETeil.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewImageColumn1,
            this.colWarteschlange,
            this.colBearbeitung,
            this.colPlanung});
            resources.ApplyResources(this.dataGridViewETeil, "dataGridViewETeil");
            this.dataGridViewETeil.Name = "dataGridViewETeil";
            this.helpProvider1.SetShowHelp(this.dataGridViewETeil, ((bool)(resources.GetObject("dataGridViewETeil.ShowHelp"))));
            // 
            // dataGridViewTextBoxColumn1
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn1, "dataGridViewTextBoxColumn1");
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn2
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn2, "dataGridViewTextBoxColumn2");
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn3, "dataGridViewTextBoxColumn3");
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn4
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn4, "dataGridViewTextBoxColumn4");
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            // 
            // dataGridViewImageColumn1
            // 
            resources.ApplyResources(this.dataGridViewImageColumn1, "dataGridViewImageColumn1");
            this.dataGridViewImageColumn1.Name = "dataGridViewImageColumn1";
            this.dataGridViewImageColumn1.ReadOnly = true;
            this.dataGridViewImageColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // colWarteschlange
            // 
            resources.ApplyResources(this.colWarteschlange, "colWarteschlange");
            this.colWarteschlange.Name = "colWarteschlange";
            this.colWarteschlange.ReadOnly = true;
            // 
            // colBearbeitung
            // 
            resources.ApplyResources(this.colBearbeitung, "colBearbeitung");
            this.colBearbeitung.Name = "colBearbeitung";
            this.colBearbeitung.ReadOnly = true;
            // 
            // colPlanung
            // 
            resources.ApplyResources(this.colPlanung, "colPlanung");
            this.colPlanung.Name = "colPlanung";
            this.colPlanung.ReadOnly = true;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Transparent;
            this.tabPage1.Controls.Add(this.pictureBox4);
            this.tabPage1.Controls.Add(this.pictureBox3);
            this.tabPage1.Controls.Add(this.dataGridViewProduktAuftrag);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.helpProvider1.SetShowHelp(this.tabPage1, ((bool)(resources.GetObject("tabPage1.ShowHelp"))));
            // 
            // pictureBox4
            // 
            this.pictureBox4.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.pictureBox4, "pictureBox4");
            this.pictureBox4.Name = "pictureBox4";
            this.helpProvider1.SetShowHelp(this.pictureBox4, ((bool)(resources.GetObject("pictureBox4.ShowHelp"))));
            this.pictureBox4.TabStop = false;
            this.toolTip.SetToolTip(this.pictureBox4, resources.GetString("pictureBox4.ToolTip"));
            this.pictureBox4.Click += new System.EventHandler(this.pictureBox4_Click);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.helpProvider1.SetShowHelp(this.pictureBox3, ((bool)(resources.GetObject("pictureBox3.ShowHelp"))));
            this.pictureBox3.TabStop = false;
            this.toolTip.SetToolTip(this.pictureBox3, resources.GetString("pictureBox3.ToolTip"));
            this.pictureBox3.Click += new System.EventHandler(this.pictureBox3_Click_1);
            // 
            // dataGridViewProduktAuftrag
            // 
            this.dataGridViewProduktAuftrag.AllowDrop = true;
            this.dataGridViewProduktAuftrag.AllowUserToAddRows = false;
            this.dataGridViewProduktAuftrag.AllowUserToDeleteRows = false;
            this.dataGridViewProduktAuftrag.AllowUserToOrderColumns = true;
            this.dataGridViewProduktAuftrag.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewProduktAuftrag.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewProduktAuftrag.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduktAuftrag.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28});
            resources.ApplyResources(this.dataGridViewProduktAuftrag, "dataGridViewProduktAuftrag");
            this.dataGridViewProduktAuftrag.Name = "dataGridViewProduktAuftrag";
            this.helpProvider1.SetShowHelp(this.dataGridViewProduktAuftrag, ((bool)(resources.GetObject("dataGridViewProduktAuftrag.ShowHelp"))));
            this.dataGridViewProduktAuftrag.DragDrop += new System.Windows.Forms.DragEventHandler(this.dataGridViewProduktAuftrag_DragDrop_1);
            this.dataGridViewProduktAuftrag.DragOver += new System.Windows.Forms.DragEventHandler(this.dataGridViewProduktAuftrag_DragOver_1);
            this.dataGridViewProduktAuftrag.MouseDown += new System.Windows.Forms.MouseEventHandler(this.dataGridViewProduktAuftrag_MouseDown_1);
            this.dataGridViewProduktAuftrag.MouseMove += new System.Windows.Forms.MouseEventHandler(this.dataGridViewProduktAuftrag_MouseMove_1);
            // 
            // dataGridViewTextBoxColumn27
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn27, "dataGridViewTextBoxColumn27");
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            this.dataGridViewTextBoxColumn27.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn28
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn28, "dataGridViewTextBoxColumn28");
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // tab_arbeitzeit
            // 
            this.tab_arbeitzeit.BackColor = System.Drawing.Color.Transparent;
            this.tab_arbeitzeit.Controls.Add(this.arbPlatzAusfueren);
            this.tab_arbeitzeit.Controls.Add(this.DataGridViewAP);
            resources.ApplyResources(this.tab_arbeitzeit, "tab_arbeitzeit");
            this.tab_arbeitzeit.Name = "tab_arbeitzeit";
            this.helpProvider1.SetShowHelp(this.tab_arbeitzeit, ((bool)(resources.GetObject("tab_arbeitzeit.ShowHelp"))));
            // 
            // arbPlatzAusfueren
            // 
            this.arbPlatzAusfueren.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.arbPlatzAusfueren, "arbPlatzAusfueren");
            this.arbPlatzAusfueren.Name = "arbPlatzAusfueren";
            this.helpProvider1.SetShowHelp(this.arbPlatzAusfueren, ((bool)(resources.GetObject("arbPlatzAusfueren.ShowHelp"))));
            this.arbPlatzAusfueren.TabStop = false;
            this.toolTip.SetToolTip(this.arbPlatzAusfueren, resources.GetString("arbPlatzAusfueren.ToolTip"));
            this.arbPlatzAusfueren.Click += new System.EventHandler(this.arbPlatzAusfueren_Click);
            // 
            // DataGridViewAP
            // 
            this.DataGridViewAP.AllowUserToAddRows = false;
            this.DataGridViewAP.AllowUserToDeleteRows = false;
            this.DataGridViewAP.BackgroundColor = System.Drawing.SystemColors.Control;
            this.DataGridViewAP.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.DataGridViewAP.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DataGridViewAP.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.minus,
            this.plus,
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewImageColumn2,
            this.s1,
            this.s3,
            this.ueber});
            resources.ApplyResources(this.DataGridViewAP, "DataGridViewAP");
            this.DataGridViewAP.Name = "DataGridViewAP";
            this.helpProvider1.SetShowHelp(this.DataGridViewAP, ((bool)(resources.GetObject("DataGridViewAP.ShowHelp"))));
            this.DataGridViewAP.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewAPlatz_CellContentClick);
            this.DataGridViewAP.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.DataGridViewAP_CellMouseEnter);
            // 
            // dataGridViewTextBoxColumn5
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn5, "dataGridViewTextBoxColumn5");
            this.dataGridViewTextBoxColumn5.LinkColor = System.Drawing.Color.Blue;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewTextBoxColumn5.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewTextBoxColumn7
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn7, "dataGridViewTextBoxColumn7");
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn8
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn8, "dataGridViewTextBoxColumn8");
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // dataGridViewTextBoxColumn9
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn9, "dataGridViewTextBoxColumn9");
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            // 
            // minus
            // 
            resources.ApplyResources(this.minus, "minus");
            this.minus.Name = "minus";
            // 
            // plus
            // 
            resources.ApplyResources(this.plus, "plus");
            this.plus.Name = "plus";
            this.plus.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.plus.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewTextBoxColumn10
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn10, "dataGridViewTextBoxColumn10");
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            // 
            // dataGridViewImageColumn2
            // 
            resources.ApplyResources(this.dataGridViewImageColumn2, "dataGridViewImageColumn2");
            this.dataGridViewImageColumn2.Name = "dataGridViewImageColumn2";
            this.dataGridViewImageColumn2.ReadOnly = true;
            this.dataGridViewImageColumn2.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // s1
            // 
            resources.ApplyResources(this.s1, "s1");
            this.s1.Name = "s1";
            this.s1.ReadOnly = true;
            this.s1.TrueValue = "123";
            // 
            // s3
            // 
            resources.ApplyResources(this.s3, "s3");
            this.s3.Name = "s3";
            this.s3.ReadOnly = true;
            this.s3.TrueValue = "";
            // 
            // ueber
            // 
            resources.ApplyResources(this.ueber, "ueber");
            this.ueber.Name = "ueber";
            this.ueber.ReadOnly = true;
            this.ueber.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ueber.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // tab_bestellverwaltung
            // 
            this.tab_bestellverwaltung.BackColor = System.Drawing.Color.Transparent;
            this.tab_bestellverwaltung.Controls.Add(this.tab2);
            resources.ApplyResources(this.tab_bestellverwaltung, "tab_bestellverwaltung");
            this.tab_bestellverwaltung.Name = "tab_bestellverwaltung";
            this.helpProvider1.SetShowHelp(this.tab_bestellverwaltung, ((bool)(resources.GetObject("tab_bestellverwaltung.ShowHelp"))));
            // 
            // tab2
            // 
            this.tab2.Controls.Add(this.tabPage2);
            this.tab2.Controls.Add(this.tab_bestellung);
            resources.ApplyResources(this.tab2, "tab2");
            this.tab2.Name = "tab2";
            this.tab2.SelectedIndex = 0;
            this.helpProvider1.SetShowHelp(this.tab2, ((bool)(resources.GetObject("tab2.ShowHelp"))));
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Transparent;
            this.tabPage2.Controls.Add(this.dataGridViewKTeil);
            resources.ApplyResources(this.tabPage2, "tabPage2");
            this.tabPage2.Name = "tabPage2";
            this.helpProvider1.SetShowHelp(this.tabPage2, ((bool)(resources.GetObject("tabPage2.ShowHelp"))));
            // 
            // dataGridViewKTeil
            // 
            this.dataGridViewKTeil.AllowUserToAddRows = false;
            this.dataGridViewKTeil.AllowUserToDeleteRows = false;
            this.dataGridViewKTeil.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewKTeil.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewKTeil.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewKTeil.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewLinkColumn1,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19,
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21});
            resources.ApplyResources(this.dataGridViewKTeil, "dataGridViewKTeil");
            this.dataGridViewKTeil.Name = "dataGridViewKTeil";
            this.dataGridViewKTeil.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.dataGridViewKTeil, ((bool)(resources.GetObject("dataGridViewKTeil.ShowHelp"))));
            this.dataGridViewKTeil.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewKTeil_CellContentClick_1);
            // 
            // dataGridViewLinkColumn1
            // 
            resources.ApplyResources(this.dataGridViewLinkColumn1, "dataGridViewLinkColumn1");
            this.dataGridViewLinkColumn1.LinkColor = System.Drawing.Color.Blue;
            this.dataGridViewLinkColumn1.Name = "dataGridViewLinkColumn1";
            this.dataGridViewLinkColumn1.ReadOnly = true;
            this.dataGridViewLinkColumn1.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridViewLinkColumn1.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            // 
            // dataGridViewTextBoxColumn6
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn6, "dataGridViewTextBoxColumn6");
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn11
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn11, "dataGridViewTextBoxColumn11");
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn13
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn13, "dataGridViewTextBoxColumn13");
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn14
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn14, "dataGridViewTextBoxColumn14");
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn15
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn15, "dataGridViewTextBoxColumn15");
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn16
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn16, "dataGridViewTextBoxColumn16");
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn17
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn17, "dataGridViewTextBoxColumn17");
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn18
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn18, "dataGridViewTextBoxColumn18");
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn19
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn19, "dataGridViewTextBoxColumn19");
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn20
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn20, "dataGridViewTextBoxColumn20");
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            this.dataGridViewTextBoxColumn20.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn21
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn21, "dataGridViewTextBoxColumn21");
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            this.dataGridViewTextBoxColumn21.ReadOnly = true;
            // 
            // tab_bestellung
            // 
            this.tab_bestellung.BackColor = System.Drawing.Color.Transparent;
            this.tab_bestellung.Controls.Add(this.dvVerwenden);
            this.tab_bestellung.Controls.Add(this.addNr2);
            this.tab_bestellung.Controls.Add(this.zurueck2);
            this.tab_bestellung.Controls.Add(this.saveAenderungen2);
            this.tab_bestellung.Controls.Add(this.label275);
            this.tab_bestellung.Controls.Add(this.dataGridViewDirektverkauf);
            this.tab_bestellung.Controls.Add(this.addNr);
            this.tab_bestellung.Controls.Add(this.label3);
            this.tab_bestellung.Controls.Add(this.uebernehmenXML);
            this.tab_bestellung.Controls.Add(this.zurueck);
            this.tab_bestellung.Controls.Add(this.saveAenderungen);
            this.tab_bestellung.Controls.Add(this.dataGridViewBestellung);
            resources.ApplyResources(this.tab_bestellung, "tab_bestellung");
            this.tab_bestellung.Name = "tab_bestellung";
            this.helpProvider1.SetShowHelp(this.tab_bestellung, ((bool)(resources.GetObject("tab_bestellung.ShowHelp"))));
            // 
            // dvVerwenden
            // 
            resources.ApplyResources(this.dvVerwenden, "dvVerwenden");
            this.dvVerwenden.BackColor = System.Drawing.SystemColors.Control;
            this.dvVerwenden.Name = "dvVerwenden";
            this.helpProvider1.SetShowHelp(this.dvVerwenden, ((bool)(resources.GetObject("dvVerwenden.ShowHelp"))));
            this.toolTip.SetToolTip(this.dvVerwenden, resources.GetString("dvVerwenden.ToolTip"));
            this.dvVerwenden.UseVisualStyleBackColor = false;
            // 
            // addNr2
            // 
            this.addNr2.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.addNr2, "addNr2");
            this.addNr2.Name = "addNr2";
            this.helpProvider1.SetShowHelp(this.addNr2, ((bool)(resources.GetObject("addNr2.ShowHelp"))));
            this.addNr2.TabStop = false;
            this.toolTip.SetToolTip(this.addNr2, resources.GetString("addNr2.ToolTip"));
            this.addNr2.Click += new System.EventHandler(this.addNr2_Click);
            // 
            // zurueck2
            // 
            this.zurueck2.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.zurueck2, "zurueck2");
            this.zurueck2.Name = "zurueck2";
            this.helpProvider1.SetShowHelp(this.zurueck2, ((bool)(resources.GetObject("zurueck2.ShowHelp"))));
            this.zurueck2.TabStop = false;
            this.toolTip.SetToolTip(this.zurueck2, resources.GetString("zurueck2.ToolTip"));
            this.zurueck2.Click += new System.EventHandler(this.zurueck2_Click);
            // 
            // saveAenderungen2
            // 
            this.saveAenderungen2.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.saveAenderungen2, "saveAenderungen2");
            this.saveAenderungen2.Name = "saveAenderungen2";
            this.helpProvider1.SetShowHelp(this.saveAenderungen2, ((bool)(resources.GetObject("saveAenderungen2.ShowHelp"))));
            this.saveAenderungen2.TabStop = false;
            this.toolTip.SetToolTip(this.saveAenderungen2, resources.GetString("saveAenderungen2.ToolTip"));
            this.saveAenderungen2.Click += new System.EventHandler(this.saveAenderungen2_Click);
            // 
            // label275
            // 
            resources.ApplyResources(this.label275, "label275");
            this.label275.Name = "label275";
            this.helpProvider1.SetShowHelp(this.label275, ((bool)(resources.GetObject("label275.ShowHelp"))));
            // 
            // dataGridViewDirektverkauf
            // 
            this.dataGridViewDirektverkauf.AllowUserToAddRows = false;
            this.dataGridViewDirektverkauf.AllowUserToDeleteRows = false;
            this.dataGridViewDirektverkauf.AllowUserToOrderColumns = true;
            this.dataGridViewDirektverkauf.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewDirektverkauf.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewDirektverkauf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDirektverkauf.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.knr2,
            this.dataGridViewTextBoxColumn32,
            this.pr,
            this.str,
            this.dataGridViewCheckBoxColumn2});
            resources.ApplyResources(this.dataGridViewDirektverkauf, "dataGridViewDirektverkauf");
            this.dataGridViewDirektverkauf.Name = "dataGridViewDirektverkauf";
            this.helpProvider1.SetShowHelp(this.dataGridViewDirektverkauf, ((bool)(resources.GetObject("dataGridViewDirektverkauf.ShowHelp"))));
            // 
            // knr2
            // 
            resources.ApplyResources(this.knr2, "knr2");
            this.knr2.Name = "knr2";
            this.knr2.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn32
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn32, "dataGridViewTextBoxColumn32");
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // pr
            // 
            resources.ApplyResources(this.pr, "pr");
            this.pr.Name = "pr";
            // 
            // str
            // 
            resources.ApplyResources(this.str, "str");
            this.str.Name = "str";
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.FalseValue = "false";
            resources.ApplyResources(this.dataGridViewCheckBoxColumn2, "dataGridViewCheckBoxColumn2");
            this.dataGridViewCheckBoxColumn2.IndeterminateValue = "false";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.TrueValue = "true";
            // 
            // addNr
            // 
            this.addNr.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.addNr, "addNr");
            this.addNr.Name = "addNr";
            this.helpProvider1.SetShowHelp(this.addNr, ((bool)(resources.GetObject("addNr.ShowHelp"))));
            this.addNr.TabStop = false;
            this.toolTip.SetToolTip(this.addNr, resources.GetString("addNr.ToolTip"));
            this.addNr.Click += new System.EventHandler(this.addNr_Click);
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            this.helpProvider1.SetShowHelp(this.label3, ((bool)(resources.GetObject("label3.ShowHelp"))));
            // 
            // uebernehmenXML
            // 
            this.uebernehmenXML.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.uebernehmenXML, "uebernehmenXML");
            this.uebernehmenXML.Name = "uebernehmenXML";
            this.helpProvider1.SetShowHelp(this.uebernehmenXML, ((bool)(resources.GetObject("uebernehmenXML.ShowHelp"))));
            this.uebernehmenXML.TabStop = false;
            this.toolTip.SetToolTip(this.uebernehmenXML, resources.GetString("uebernehmenXML.ToolTip"));
            this.uebernehmenXML.Click += new System.EventHandler(this.uebernehmenXML_Click);
            // 
            // zurueck
            // 
            this.zurueck.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.zurueck, "zurueck");
            this.zurueck.Name = "zurueck";
            this.helpProvider1.SetShowHelp(this.zurueck, ((bool)(resources.GetObject("zurueck.ShowHelp"))));
            this.zurueck.TabStop = false;
            this.toolTip.SetToolTip(this.zurueck, resources.GetString("zurueck.ToolTip"));
            this.zurueck.Click += new System.EventHandler(this.zurueck_Click);
            // 
            // saveAenderungen
            // 
            this.saveAenderungen.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.saveAenderungen, "saveAenderungen");
            this.saveAenderungen.Name = "saveAenderungen";
            this.helpProvider1.SetShowHelp(this.saveAenderungen, ((bool)(resources.GetObject("saveAenderungen.ShowHelp"))));
            this.saveAenderungen.TabStop = false;
            this.toolTip.SetToolTip(this.saveAenderungen, resources.GetString("saveAenderungen.ToolTip"));
            this.saveAenderungen.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // dataGridViewBestellung
            // 
            this.dataGridViewBestellung.AllowUserToAddRows = false;
            this.dataGridViewBestellung.AllowUserToDeleteRows = false;
            this.dataGridViewBestellung.AllowUserToOrderColumns = true;
            this.dataGridViewBestellung.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewBestellung.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewBestellung.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewBestellung.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.kNr,
            this.menge,
            this.eil,
            this.del});
            resources.ApplyResources(this.dataGridViewBestellung, "dataGridViewBestellung");
            this.dataGridViewBestellung.Name = "dataGridViewBestellung";
            this.helpProvider1.SetShowHelp(this.dataGridViewBestellung, ((bool)(resources.GetObject("dataGridViewBestellung.ShowHelp"))));
            // 
            // kNr
            // 
            resources.ApplyResources(this.kNr, "kNr");
            this.kNr.Name = "kNr";
            this.kNr.ReadOnly = true;
            // 
            // menge
            // 
            resources.ApplyResources(this.menge, "menge");
            this.menge.Name = "menge";
            // 
            // eil
            // 
            this.eil.FalseValue = "false";
            resources.ApplyResources(this.eil, "eil");
            this.eil.Name = "eil";
            this.eil.TrueValue = "true";
            // 
            // del
            // 
            this.del.FalseValue = "false";
            resources.ApplyResources(this.del, "del");
            this.del.IndeterminateValue = "false";
            this.del.Name = "del";
            this.del.TrueValue = "true";
            // 
            // xmlOutput
            // 
            this.xmlOutput.BackColor = System.Drawing.Color.Transparent;
            this.xmlOutput.Controls.Add(this.panelXMLerstellen);
            resources.ApplyResources(this.xmlOutput, "xmlOutput");
            this.xmlOutput.Name = "xmlOutput";
            this.helpProvider1.SetShowHelp(this.xmlOutput, ((bool)(resources.GetObject("xmlOutput.ShowHelp"))));
            // 
            // panelXMLerstellen
            // 
            this.panelXMLerstellen.Controls.Add(this.dataGridViewPrAuftraege);
            this.panelXMLerstellen.Controls.Add(this.lb12);
            this.panelXMLerstellen.Controls.Add(this.dataGridViewProduktKapazit);
            this.panelXMLerstellen.Controls.Add(this.label274);
            this.panelXMLerstellen.Controls.Add(this.dataGridViewEinkauf);
            this.panelXMLerstellen.Controls.Add(this.label272);
            this.panelXMLerstellen.Controls.Add(this.dataGridViewDirekt);
            this.panelXMLerstellen.Controls.Add(this.label271);
            this.panelXMLerstellen.Controls.Add(this.dataGridViewVertrieb);
            this.panelXMLerstellen.Controls.Add(this.label270);
            resources.ApplyResources(this.panelXMLerstellen, "panelXMLerstellen");
            this.panelXMLerstellen.Name = "panelXMLerstellen";
            this.helpProvider1.SetShowHelp(this.panelXMLerstellen, ((bool)(resources.GetObject("panelXMLerstellen.ShowHelp"))));
            // 
            // dataGridViewPrAuftraege
            // 
            this.dataGridViewPrAuftraege.AllowUserToAddRows = false;
            this.dataGridViewPrAuftraege.AllowUserToDeleteRows = false;
            this.dataGridViewPrAuftraege.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewPrAuftraege.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewPrAuftraege.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewPrAuftraege.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn33});
            resources.ApplyResources(this.dataGridViewPrAuftraege, "dataGridViewPrAuftraege");
            this.dataGridViewPrAuftraege.Name = "dataGridViewPrAuftraege";
            this.dataGridViewPrAuftraege.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.dataGridViewPrAuftraege, ((bool)(resources.GetObject("dataGridViewPrAuftraege.ShowHelp"))));
            // 
            // dataGridViewTextBoxColumn31
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn31, "dataGridViewTextBoxColumn31");
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            this.dataGridViewTextBoxColumn31.ReadOnly = true;
            this.dataGridViewTextBoxColumn31.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn33
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn33, "dataGridViewTextBoxColumn33");
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            this.dataGridViewTextBoxColumn33.ReadOnly = true;
            this.dataGridViewTextBoxColumn33.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // lb12
            // 
            resources.ApplyResources(this.lb12, "lb12");
            this.lb12.Name = "lb12";
            this.helpProvider1.SetShowHelp(this.lb12, ((bool)(resources.GetObject("lb12.ShowHelp"))));
            // 
            // dataGridViewProduktKapazit
            // 
            this.dataGridViewProduktKapazit.AllowUserToAddRows = false;
            this.dataGridViewProduktKapazit.AllowUserToDeleteRows = false;
            this.dataGridViewProduktKapazit.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewProduktKapazit.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewProduktKapazit.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewProduktKapazit.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn29,
            this.dataGridViewTextBoxColumn30,
            this.ueberStunden});
            resources.ApplyResources(this.dataGridViewProduktKapazit, "dataGridViewProduktKapazit");
            this.dataGridViewProduktKapazit.Name = "dataGridViewProduktKapazit";
            this.dataGridViewProduktKapazit.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.dataGridViewProduktKapazit, ((bool)(resources.GetObject("dataGridViewProduktKapazit.ShowHelp"))));
            // 
            // dataGridViewTextBoxColumn29
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn29, "dataGridViewTextBoxColumn29");
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            this.dataGridViewTextBoxColumn29.ReadOnly = true;
            this.dataGridViewTextBoxColumn29.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // dataGridViewTextBoxColumn30
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn30, "dataGridViewTextBoxColumn30");
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            this.dataGridViewTextBoxColumn30.ReadOnly = true;
            this.dataGridViewTextBoxColumn30.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // ueberStunden
            // 
            resources.ApplyResources(this.ueberStunden, "ueberStunden");
            this.ueberStunden.Name = "ueberStunden";
            this.ueberStunden.ReadOnly = true;
            this.ueberStunden.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable;
            // 
            // label274
            // 
            resources.ApplyResources(this.label274, "label274");
            this.label274.Name = "label274";
            this.helpProvider1.SetShowHelp(this.label274, ((bool)(resources.GetObject("label274.ShowHelp"))));
            // 
            // dataGridViewEinkauf
            // 
            this.dataGridViewEinkauf.AllowUserToAddRows = false;
            this.dataGridViewEinkauf.AllowUserToDeleteRows = false;
            this.dataGridViewEinkauf.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewEinkauf.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewEinkauf.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewEinkauf.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25,
            this.dataGridViewTextBoxColumn26});
            resources.ApplyResources(this.dataGridViewEinkauf, "dataGridViewEinkauf");
            this.dataGridViewEinkauf.Name = "dataGridViewEinkauf";
            this.dataGridViewEinkauf.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.dataGridViewEinkauf, ((bool)(resources.GetObject("dataGridViewEinkauf.ShowHelp"))));
            // 
            // dataGridViewTextBoxColumn24
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn24, "dataGridViewTextBoxColumn24");
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            this.dataGridViewTextBoxColumn24.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn25
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn25, "dataGridViewTextBoxColumn25");
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            this.dataGridViewTextBoxColumn25.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn26
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn26, "dataGridViewTextBoxColumn26");
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            this.dataGridViewTextBoxColumn26.ReadOnly = true;
            // 
            // label272
            // 
            resources.ApplyResources(this.label272, "label272");
            this.label272.Name = "label272";
            this.helpProvider1.SetShowHelp(this.label272, ((bool)(resources.GetObject("label272.ShowHelp"))));
            // 
            // dataGridViewDirekt
            // 
            this.dataGridViewDirekt.AllowUserToAddRows = false;
            this.dataGridViewDirekt.AllowUserToDeleteRows = false;
            this.dataGridViewDirekt.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewDirekt.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewDirekt.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewDirekt.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.straf});
            resources.ApplyResources(this.dataGridViewDirekt, "dataGridViewDirekt");
            this.dataGridViewDirekt.Name = "dataGridViewDirekt";
            this.dataGridViewDirekt.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.dataGridViewDirekt, ((bool)(resources.GetObject("dataGridViewDirekt.ShowHelp"))));
            // 
            // dataGridViewTextBoxColumn12
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn12, "dataGridViewTextBoxColumn12");
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn22
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn22, "dataGridViewTextBoxColumn22");
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            this.dataGridViewTextBoxColumn22.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn23
            // 
            resources.ApplyResources(this.dataGridViewTextBoxColumn23, "dataGridViewTextBoxColumn23");
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            this.dataGridViewTextBoxColumn23.ReadOnly = true;
            // 
            // straf
            // 
            resources.ApplyResources(this.straf, "straf");
            this.straf.Name = "straf";
            this.straf.ReadOnly = true;
            // 
            // label271
            // 
            resources.ApplyResources(this.label271, "label271");
            this.label271.Name = "label271";
            this.helpProvider1.SetShowHelp(this.label271, ((bool)(resources.GetObject("label271.ShowHelp"))));
            // 
            // dataGridViewVertrieb
            // 
            this.dataGridViewVertrieb.AllowUserToAddRows = false;
            this.dataGridViewVertrieb.AllowUserToDeleteRows = false;
            this.dataGridViewVertrieb.BackgroundColor = System.Drawing.SystemColors.Control;
            this.dataGridViewVertrieb.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewVertrieb.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewVertrieb.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dg_p1,
            this.dg_p2,
            this.dg_p3});
            resources.ApplyResources(this.dataGridViewVertrieb, "dataGridViewVertrieb");
            this.dataGridViewVertrieb.Name = "dataGridViewVertrieb";
            this.dataGridViewVertrieb.ReadOnly = true;
            this.helpProvider1.SetShowHelp(this.dataGridViewVertrieb, ((bool)(resources.GetObject("dataGridViewVertrieb.ShowHelp"))));
            // 
            // dg_p1
            // 
            resources.ApplyResources(this.dg_p1, "dg_p1");
            this.dg_p1.Name = "dg_p1";
            this.dg_p1.ReadOnly = true;
            // 
            // dg_p2
            // 
            resources.ApplyResources(this.dg_p2, "dg_p2");
            this.dg_p2.Name = "dg_p2";
            this.dg_p2.ReadOnly = true;
            // 
            // dg_p3
            // 
            resources.ApplyResources(this.dg_p3, "dg_p3");
            this.dg_p3.Name = "dg_p3";
            this.dg_p3.ReadOnly = true;
            // 
            // label270
            // 
            resources.ApplyResources(this.label270, "label270");
            this.label270.Name = "label270";
            this.helpProvider1.SetShowHelp(this.label270, ((bool)(resources.GetObject("label270.ShowHelp"))));
            // 
            // Spache
            // 
            this.Spache.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Spache.Controls.Add(this.tabControl1);
            this.Spache.ForeColor = System.Drawing.SystemColors.ControlText;
            resources.ApplyResources(this.Spache, "Spache");
            this.Spache.Name = "Spache";
            this.Spache.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tab_abweichung);
            this.tabControl1.Controls.Add(this.tab_diskount);
            this.tabControl1.Controls.Add(this.tab_schicht);
            this.tabControl1.Controls.Add(this.Sprache);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            // 
            // tab_abweichung
            // 
            this.tab_abweichung.BackColor = System.Drawing.Color.Transparent;
            this.tab_abweichung.Controls.Add(this.LabelAbweichung);
            this.tab_abweichung.Controls.Add(this.panel4);
            this.tab_abweichung.Controls.Add(this.lbl_100);
            this.tab_abweichung.Controls.Add(this.lbl_50);
            this.tab_abweichung.Controls.Add(this.btn_ok);
            this.tab_abweichung.Controls.Add(this.lbl_10);
            this.tab_abweichung.Controls.Add(this.trackBarAbweichung);
            resources.ApplyResources(this.tab_abweichung, "tab_abweichung");
            this.tab_abweichung.Name = "tab_abweichung";
            // 
            // LabelAbweichung
            // 
            resources.ApplyResources(this.LabelAbweichung, "LabelAbweichung");
            this.LabelAbweichung.Name = "LabelAbweichung";
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbl_info);
            this.panel4.Controls.Add(this.pictureBox5);
            resources.ApplyResources(this.panel4, "panel4");
            this.panel4.Name = "panel4";
            // 
            // lbl_info
            // 
            resources.ApplyResources(this.lbl_info, "lbl_info");
            this.lbl_info.Name = "lbl_info";
            // 
            // pictureBox5
            // 
            resources.ApplyResources(this.pictureBox5, "pictureBox5");
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.TabStop = false;
            // 
            // lbl_100
            // 
            resources.ApplyResources(this.lbl_100, "lbl_100");
            this.lbl_100.BackColor = System.Drawing.Color.Transparent;
            this.lbl_100.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_100.Name = "lbl_100";
            // 
            // lbl_50
            // 
            resources.ApplyResources(this.lbl_50, "lbl_50");
            this.lbl_50.BackColor = System.Drawing.Color.Transparent;
            this.lbl_50.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_50.Name = "lbl_50";
            // 
            // btn_ok
            // 
            resources.ApplyResources(this.btn_ok, "btn_ok");
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.UseVisualStyleBackColor = true;
            // 
            // lbl_10
            // 
            resources.ApplyResources(this.lbl_10, "lbl_10");
            this.lbl_10.BackColor = System.Drawing.Color.Transparent;
            this.lbl_10.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_10.Name = "lbl_10";
            // 
            // trackBarAbweichung
            // 
            this.trackBarAbweichung.BackColor = System.Drawing.SystemColors.Control;
            resources.ApplyResources(this.trackBarAbweichung, "trackBarAbweichung");
            this.trackBarAbweichung.Name = "trackBarAbweichung";
            this.trackBarAbweichung.Value = 5;
            // 
            // tab_diskount
            // 
            this.tab_diskount.BackColor = System.Drawing.Color.Transparent;
            this.tab_diskount.Controls.Add(this.LabelDiskont);
            this.tab_diskount.Controls.Add(this.label273);
            this.tab_diskount.Controls.Add(this.mengeGrenze);
            this.tab_diskount.Controls.Add(this.diskGrenze);
            this.tab_diskount.Controls.Add(this.label276);
            this.tab_diskount.Controls.Add(this.label277);
            this.tab_diskount.Controls.Add(this.label278);
            this.tab_diskount.Controls.Add(this.label279);
            this.tab_diskount.Controls.Add(this.label280);
            this.tab_diskount.Controls.Add(this.panel5);
            this.tab_diskount.Controls.Add(this.diskSpeichern);
            this.tab_diskount.Controls.Add(this.trackBar1);
            resources.ApplyResources(this.tab_diskount, "tab_diskount");
            this.tab_diskount.Name = "tab_diskount";
            // 
            // LabelDiskont
            // 
            resources.ApplyResources(this.LabelDiskont, "LabelDiskont");
            this.LabelDiskont.Name = "LabelDiskont";
            // 
            // label273
            // 
            resources.ApplyResources(this.label273, "label273");
            this.label273.Name = "label273";
            // 
            // mengeGrenze
            // 
            resources.ApplyResources(this.mengeGrenze, "mengeGrenze");
            this.mengeGrenze.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.mengeGrenze.Name = "mengeGrenze";
            this.mengeGrenze.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // diskGrenze
            // 
            resources.ApplyResources(this.diskGrenze, "diskGrenze");
            this.diskGrenze.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.diskGrenze.Name = "diskGrenze";
            this.diskGrenze.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            // 
            // label276
            // 
            resources.ApplyResources(this.label276, "label276");
            this.label276.Name = "label276";
            // 
            // label277
            // 
            resources.ApplyResources(this.label277, "label277");
            this.label277.Name = "label277";
            // 
            // label278
            // 
            resources.ApplyResources(this.label278, "label278");
            this.label278.BackColor = System.Drawing.Color.Transparent;
            this.label278.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label278.Name = "label278";
            // 
            // label279
            // 
            resources.ApplyResources(this.label279, "label279");
            this.label279.BackColor = System.Drawing.Color.Transparent;
            this.label279.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label279.Name = "label279";
            // 
            // label280
            // 
            resources.ApplyResources(this.label280, "label280");
            this.label280.BackColor = System.Drawing.Color.Transparent;
            this.label280.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label280.Name = "label280";
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.label281);
            this.panel5.Controls.Add(this.pictureBox6);
            resources.ApplyResources(this.panel5, "panel5");
            this.panel5.Name = "panel5";
            // 
            // label281
            // 
            resources.ApplyResources(this.label281, "label281");
            this.label281.Name = "label281";
            // 
            // pictureBox6
            // 
            resources.ApplyResources(this.pictureBox6, "pictureBox6");
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.TabStop = false;
            // 
            // diskSpeichern
            // 
            resources.ApplyResources(this.diskSpeichern, "diskSpeichern");
            this.diskSpeichern.Name = "diskSpeichern";
            this.diskSpeichern.UseVisualStyleBackColor = true;
            // 
            // trackBar1
            // 
            this.trackBar1.BackColor = System.Drawing.SystemColors.Control;
            resources.ApplyResources(this.trackBar1, "trackBar1");
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Value = 5;
            // 
            // tab_schicht
            // 
            this.tab_schicht.BackColor = System.Drawing.Color.Transparent;
            this.tab_schicht.Controls.Add(this.LabelSchichten);
            this.tab_schicht.Controls.Add(this.panel6);
            this.tab_schicht.Controls.Add(this.numericUpDown2);
            this.tab_schicht.Controls.Add(this.numericUpDown1);
            this.tab_schicht.Controls.Add(this.btn_schicht_save);
            this.tab_schicht.Controls.Add(this.lbl_3schicht);
            this.tab_schicht.Controls.Add(this.lbl_2schicht);
            resources.ApplyResources(this.tab_schicht, "tab_schicht");
            this.tab_schicht.Name = "tab_schicht";
            // 
            // LabelSchichten
            // 
            resources.ApplyResources(this.LabelSchichten, "LabelSchichten");
            this.LabelSchichten.Name = "LabelSchichten";
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.label282);
            this.panel6.Controls.Add(this.pictureBox7);
            resources.ApplyResources(this.panel6, "panel6");
            this.panel6.Name = "panel6";
            // 
            // label282
            // 
            resources.ApplyResources(this.label282, "label282");
            this.label282.Name = "label282";
            // 
            // pictureBox7
            // 
            resources.ApplyResources(this.pictureBox7, "pictureBox7");
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.TabStop = false;
            // 
            // numericUpDown2
            // 
            this.numericUpDown2.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            resources.ApplyResources(this.numericUpDown2, "numericUpDown2");
            this.numericUpDown2.Maximum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            4800,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.TabStop = false;
            this.numericUpDown2.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            resources.ApplyResources(this.numericUpDown1, "numericUpDown1");
            this.numericUpDown1.Maximum = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            2400,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.TabStop = false;
            this.numericUpDown1.Value = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            // 
            // btn_schicht_save
            // 
            resources.ApplyResources(this.btn_schicht_save, "btn_schicht_save");
            this.btn_schicht_save.Name = "btn_schicht_save";
            this.btn_schicht_save.UseVisualStyleBackColor = true;
            // 
            // lbl_3schicht
            // 
            resources.ApplyResources(this.lbl_3schicht, "lbl_3schicht");
            this.lbl_3schicht.Name = "lbl_3schicht";
            // 
            // lbl_2schicht
            // 
            resources.ApplyResources(this.lbl_2schicht, "lbl_2schicht");
            this.lbl_2schicht.Name = "lbl_2schicht";
            // 
            // Sprache
            // 
            this.Sprache.BackColor = System.Drawing.Color.WhiteSmoke;
            this.Sprache.Controls.Add(this.textBox1);
            this.Sprache.Controls.Add(this.radioButton2);
            this.Sprache.Controls.Add(this.radioButton1);
            resources.ApplyResources(this.Sprache, "Sprache");
            this.Sprache.Name = "Sprache";
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.WhiteSmoke;
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            resources.ApplyResources(this.textBox1, "textBox1");
            this.textBox1.Name = "textBox1";
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // radioButton2
            // 
            resources.ApplyResources(this.radioButton2, "radioButton2");
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.Click += new System.EventHandler(this.radioButton2_CheckedChanged_Click);
            // 
            // radioButton1
            // 
            resources.ApplyResources(this.radioButton1, "radioButton1");
            this.radioButton1.Checked = true;
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.TabStop = true;
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.Click += new System.EventHandler(this.radioButton1_CheckedChanged_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage3.Controls.Add(this.button2);
            this.tabPage3.Controls.Add(this.button1);
            resources.ApplyResources(this.tabPage3, "tabPage3");
            this.tabPage3.Name = "tabPage3";
            // 
            // button2
            // 
            resources.ApplyResources(this.button2, "button2");
            this.button2.Name = "button2";
            this.helpProvider1.SetShowHelp(this.button2, ((bool)(resources.GetObject("button2.ShowHelp"))));
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // openFileDialog
            // 
            this.openFileDialog.FileName = "openFileDialog";
            // 
            // menu
            // 
            this.menu.BackColor = System.Drawing.Color.Transparent;
            this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateiToolStripMenuItem,
            this.einstellungenToolStripMenuItem,
            this.scimToolStripMenuItem});
            resources.ApplyResources(this.menu, "menu");
            this.menu.Name = "menu";
            this.helpProvider1.SetShowHelp(this.menu, ((bool)(resources.GetObject("menu.ShowHelp"))));
            // 
            // dateiToolStripMenuItem
            // 
            this.dateiToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.dateiÖffnenToolStripMenuItem,
            this.xMLexportToolStripMenuItem,
            this.toolStripSeparator1,
            this.schließenToolStripMenuItem});
            this.dateiToolStripMenuItem.Name = "dateiToolStripMenuItem";
            resources.ApplyResources(this.dateiToolStripMenuItem, "dateiToolStripMenuItem");
            // 
            // dateiÖffnenToolStripMenuItem
            // 
            resources.ApplyResources(this.dateiÖffnenToolStripMenuItem, "dateiÖffnenToolStripMenuItem");
            this.dateiÖffnenToolStripMenuItem.Name = "dateiÖffnenToolStripMenuItem";
            this.dateiÖffnenToolStripMenuItem.Click += new System.EventHandler(this.dateiÖffnenToolStripMenuItem_Click);
            // 
            // xMLexportToolStripMenuItem
            // 
            resources.ApplyResources(this.xMLexportToolStripMenuItem, "xMLexportToolStripMenuItem");
            this.xMLexportToolStripMenuItem.Name = "xMLexportToolStripMenuItem";
            this.xMLexportToolStripMenuItem.Click += new System.EventHandler(this.xMLexportToolStripMenuItem_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            resources.ApplyResources(this.toolStripSeparator1, "toolStripSeparator1");
            // 
            // schließenToolStripMenuItem
            // 
            resources.ApplyResources(this.schließenToolStripMenuItem, "schließenToolStripMenuItem");
            this.schließenToolStripMenuItem.Name = "schließenToolStripMenuItem";
            this.schließenToolStripMenuItem.Click += new System.EventHandler(this.schließenToolStripMenuItem_Click_1);
            // 
            // einstellungenToolStripMenuItem
            // 
            this.einstellungenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.hilfeToolStripMenuItem,
            this.spracheToolStripMenuItem1,
            this.gewichtungToolStripMenuItem});
            this.einstellungenToolStripMenuItem.Name = "einstellungenToolStripMenuItem";
            resources.ApplyResources(this.einstellungenToolStripMenuItem, "einstellungenToolStripMenuItem");
            // 
            // hilfeToolStripMenuItem
            // 
            this.hilfeToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.handbuchToolStripMenuItem,
            this.videoF2ToolStripMenuItem});
            resources.ApplyResources(this.hilfeToolStripMenuItem, "hilfeToolStripMenuItem");
            this.hilfeToolStripMenuItem.Name = "hilfeToolStripMenuItem";
            // 
            // handbuchToolStripMenuItem
            // 
            this.handbuchToolStripMenuItem.Name = "handbuchToolStripMenuItem";
            resources.ApplyResources(this.handbuchToolStripMenuItem, "handbuchToolStripMenuItem");
            this.handbuchToolStripMenuItem.Click += new System.EventHandler(this.handbuchToolStripMenuItem_Click);
            // 
            // videoF2ToolStripMenuItem
            // 
            this.videoF2ToolStripMenuItem.Name = "videoF2ToolStripMenuItem";
            resources.ApplyResources(this.videoF2ToolStripMenuItem, "videoF2ToolStripMenuItem");
            this.videoF2ToolStripMenuItem.Click += new System.EventHandler(this.videoF2ToolStripMenuItem_Click);
            // 
            // spracheToolStripMenuItem1
            // 
            this.spracheToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deutschToolStripMenuItem1,
            this.englischToolStripMenuItem1});
            this.spracheToolStripMenuItem1.Name = "spracheToolStripMenuItem1";
            resources.ApplyResources(this.spracheToolStripMenuItem1, "spracheToolStripMenuItem1");
            // 
            // deutschToolStripMenuItem1
            // 
            this.deutschToolStripMenuItem1.Checked = true;
            this.deutschToolStripMenuItem1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.deutschToolStripMenuItem1.Name = "deutschToolStripMenuItem1";
            resources.ApplyResources(this.deutschToolStripMenuItem1, "deutschToolStripMenuItem1");
            this.deutschToolStripMenuItem1.Click += new System.EventHandler(this.deutschToolStripMenuItem1_Click);
            // 
            // englischToolStripMenuItem1
            // 
            this.englischToolStripMenuItem1.Name = "englischToolStripMenuItem1";
            resources.ApplyResources(this.englischToolStripMenuItem1, "englischToolStripMenuItem1");
            this.englischToolStripMenuItem1.Click += new System.EventHandler(this.englischToolStripMenuItem1_Click);
            // 
            // gewichtungToolStripMenuItem
            // 
            resources.ApplyResources(this.gewichtungToolStripMenuItem, "gewichtungToolStripMenuItem");
            this.gewichtungToolStripMenuItem.Name = "gewichtungToolStripMenuItem";
            this.gewichtungToolStripMenuItem.Click += new System.EventHandler(this.gewichtungToolStripMenuItem_Click);
            // 
            // scimToolStripMenuItem
            // 
            this.scimToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.startSeiteToolStripMenuItem});
            this.scimToolStripMenuItem.Name = "scimToolStripMenuItem";
            resources.ApplyResources(this.scimToolStripMenuItem, "scimToolStripMenuItem");
            // 
            // startSeiteToolStripMenuItem
            // 
            this.startSeiteToolStripMenuItem.Name = "startSeiteToolStripMenuItem";
            resources.ApplyResources(this.startSeiteToolStripMenuItem, "startSeiteToolStripMenuItem");
            this.startSeiteToolStripMenuItem.Click += new System.EventHandler(this.startSeiteToolStripMenuItem_Click);
            // 
            // xml_export
            // 
            this.xml_export.Cursor = System.Windows.Forms.Cursors.Hand;
            resources.ApplyResources(this.xml_export, "xml_export");
            this.xml_export.Name = "xml_export";
            this.helpProvider1.SetShowHelp(this.xml_export, ((bool)(resources.GetObject("xml_export.ShowHelp"))));
            this.xml_export.TabStop = false;
            this.toolTip.SetToolTip(this.xml_export, resources.GetString("xml_export.ToolTip"));
            this.xml_export.Click += new System.EventHandler(this.xml_export_Click);
            // 
            // info
            // 
            resources.ApplyResources(this.info, "info");
            this.info.ForeColor = System.Drawing.Color.Green;
            this.info.Name = "info";
            this.helpProvider1.SetShowHelp(this.info, ((bool)(resources.GetObject("info.ShowHelp"))));
            // 
            // imageListAmpel
            // 
            this.imageListAmpel.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListAmpel.ImageStream")));
            this.imageListAmpel.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListAmpel.Images.SetKeyName(0, "red");
            this.imageListAmpel.Images.SetKeyName(1, "yellow");
            this.imageListAmpel.Images.SetKeyName(2, "green");
            // 
            // helpProvider1
            // 
            resources.ApplyResources(this.helpProvider1, "helpProvider1");
            // 
            // imageListPlusMinus
            // 
            this.imageListPlusMinus.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imageListPlusMinus.ImageStream")));
            this.imageListPlusMinus.TransparentColor = System.Drawing.Color.Transparent;
            this.imageListPlusMinus.Images.SetKeyName(0, "minus.png");
            this.imageListPlusMinus.Images.SetKeyName(1, "plus.png");
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.WhiteSmoke;
            this.tabPage4.Controls.Add(this.button3);
            resources.ApplyResources(this.tabPage4, "tabPage4");
            this.tabPage4.Name = "tabPage4";
            // 
            // button3
            // 
            resources.ApplyResources(this.button3, "button3");
            this.button3.Name = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Fahrrad
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            resources.ApplyResources(this, "$this");
            this.Controls.Add(this.info);
            this.Controls.Add(this.xml_export);
            this.Controls.Add(this.menu);
            this.Controls.Add(this.tabs);
            this.HelpButton = true;
            this.helpProvider1.SetHelpKeyword(this, resources.GetString("$this.HelpKeyword"));
            this.helpProvider1.SetHelpNavigator(this, ((System.Windows.Forms.HelpNavigator)(resources.GetObject("$this.HelpNavigator"))));
            this.helpProvider1.SetHelpString(this, resources.GetString("$this.HelpString"));
            this.Name = "Fahrrad";
            this.helpProvider1.SetShowHelp(this, ((bool)(resources.GetObject("$this.ShowHelp"))));
            this.tabs.ResumeLayout(false);
            this.tab_xml.ResumeLayout(false);
            this.tab_xml.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pufferP3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pufferP2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pufferP1)).EndInit();
            this.panelXML.ResumeLayout(false);
            this.panelXML.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.save)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xmlOffenOK)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.toolAusfueren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bildSpeichOk)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP33)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownAW3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP32)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownAW2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP31)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownP11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.upDownAW1)).EndInit();
            this.tab_produktion.ResumeLayout(false);
            this.tab1.ResumeLayout(false);
            this.tab_P1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p1ETAusfueren)).EndInit();
            this.tab_P2.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p2ETAusfueren)).EndInit();
            this.tab_P3.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.p3ETAusfueren)).EndInit();
            this.tab_eTeil.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewETeil)).EndInit();
            this.tabPage1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktAuftrag)).EndInit();
            this.tab_arbeitzeit.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.arbPlatzAusfueren)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DataGridViewAP)).EndInit();
            this.tab_bestellverwaltung.ResumeLayout(false);
            this.tab2.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewKTeil)).EndInit();
            this.tab_bestellung.ResumeLayout(false);
            this.tab_bestellung.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.addNr2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zurueck2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveAenderungen2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDirektverkauf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.addNr)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.uebernehmenXML)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.zurueck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.saveAenderungen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewBestellung)).EndInit();
            this.xmlOutput.ResumeLayout(false);
            this.panelXMLerstellen.ResumeLayout(false);
            this.panelXMLerstellen.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewPrAuftraege)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewProduktKapazit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewEinkauf)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewDirekt)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewVertrieb)).EndInit();
            this.Spache.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tab_abweichung.ResumeLayout(false);
            this.tab_abweichung.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAbweichung)).EndInit();
            this.tab_diskount.ResumeLayout(false);
            this.tab_diskount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mengeGrenze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diskGrenze)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.tab_schicht.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.Sprache.ResumeLayout(false);
            this.Sprache.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.menu.ResumeLayout(false);
            this.menu.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.xml_export)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabs;
        private System.Windows.Forms.TabPage tab_xml;
        private System.Windows.Forms.Button xml_suchen;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.Label titlePrognose;
        private System.Windows.Forms.Label titleXmlLaden;
        private System.Windows.Forms.Label aktulleWoche;
        private System.Windows.Forms.Label p3;
        private System.Windows.Forms.Label p2;
        private System.Windows.Forms.Label p1;
        private System.Windows.Forms.NumericUpDown upDownAW3;
        private System.Windows.Forms.NumericUpDown upDownAW2;
        private System.Windows.Forms.NumericUpDown upDownAW1;
        private System.Windows.Forms.MenuStrip menu;
        private System.Windows.Forms.NumericUpDown upDownP33;
        private System.Windows.Forms.NumericUpDown upDownP23;
        private System.Windows.Forms.NumericUpDown upDownP13;
        private System.Windows.Forms.NumericUpDown upDownP32;
        private System.Windows.Forms.NumericUpDown upDownP22;
        private System.Windows.Forms.NumericUpDown upDownP12;
        private System.Windows.Forms.NumericUpDown upDownP31;
        private System.Windows.Forms.NumericUpDown upDownP21;
        private System.Windows.Forms.NumericUpDown upDownP11;
        private System.Windows.Forms.Label prognose1;
        private System.Windows.Forms.Label prognose2;
        private System.Windows.Forms.Label prognose3;
        private System.Windows.Forms.Button prognoseSpeichern;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox xmlTextBox;
        private System.Windows.Forms.PictureBox toolAusfueren;
        private System.Windows.Forms.PictureBox bildSpeichOk;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.PictureBox xmlOffenOK;
        private System.Windows.Forms.Panel panelXML;
        private System.Windows.Forms.ToolStripMenuItem einstellungenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hilfeToolStripMenuItem;
        private System.Windows.Forms.NumericUpDown pufferP3;
        private System.Windows.Forms.NumericUpDown pufferP2;
        private System.Windows.Forms.NumericUpDown pufferP1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox save;
        private System.Windows.Forms.TabPage tab_produktion;
        private System.Windows.Forms.TabControl tab1;
        private System.Windows.Forms.TabPage tab_eTeil;
        private System.Windows.Forms.ImageList imageListAmpel;
        private System.Windows.Forms.ToolStripMenuItem gewichtungToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem handbuchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scimToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem startSeiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem spracheToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deutschToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem dateiToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem schließenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateiÖffnenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem xMLexportToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.HelpProvider helpProvider1;
        private System.Windows.Forms.TabPage tab_bestellverwaltung;
        private System.Windows.Forms.TabControl tab2;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.DataGridView dataGridViewKTeil;
        private System.Windows.Forms.TabPage tab_bestellung;
        private System.Windows.Forms.DataGridView dataGridViewETeil;
        private System.Windows.Forms.TabPage tab_P1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox p1plus_18;
        private System.Windows.Forms.TextBox p1r_18;
        private System.Windows.Forms.TextBox p1ls_18;
        private System.Windows.Forms.TextBox p1iws_18;
        private System.Windows.Forms.TextBox p1ib_18;
        private System.Windows.Forms.TextBox p1pm_18;
        private System.Windows.Forms.TextBox p1vw_18;
        private System.Windows.Forms.TextBox p1plus_7;
        private System.Windows.Forms.TextBox p1r_7;
        private System.Windows.Forms.TextBox p1ls_7;
        private System.Windows.Forms.TextBox p1iws_7;
        private System.Windows.Forms.TextBox p1ib_7;
        private System.Windows.Forms.TextBox p1pm_7;
        private System.Windows.Forms.TextBox p1vw_7;
        private System.Windows.Forms.TextBox p1plus_13;
        private System.Windows.Forms.TextBox p1r_13;
        private System.Windows.Forms.TextBox p1ls_13;
        private System.Windows.Forms.TextBox p1iws_13;
        private System.Windows.Forms.TextBox p1ib_13;
        private System.Windows.Forms.TextBox p1pm_13;
        private System.Windows.Forms.TextBox p1vw_13;
        private System.Windows.Forms.TextBox p1plus_49;
        private System.Windows.Forms.TextBox p1r_49;
        private System.Windows.Forms.TextBox p1ls_49;
        private System.Windows.Forms.TextBox p1iws_49;
        private System.Windows.Forms.TextBox p1ib_49;
        private System.Windows.Forms.TextBox p1pm_49;
        private System.Windows.Forms.TextBox p1vw_49;
        private System.Windows.Forms.TextBox p1plus_4;
        private System.Windows.Forms.TextBox p1r_4;
        private System.Windows.Forms.TextBox p1ls_4;
        private System.Windows.Forms.TextBox p1iws_4;
        private System.Windows.Forms.TextBox p1ib_4;
        private System.Windows.Forms.TextBox p1pm_4;
        private System.Windows.Forms.TextBox p1vw_4;
        private System.Windows.Forms.TextBox p1plus_10;
        private System.Windows.Forms.TextBox p1r_10;
        private System.Windows.Forms.TextBox p1ls_10;
        private System.Windows.Forms.TextBox p1iws_10;
        private System.Windows.Forms.TextBox p1ib_10;
        private System.Windows.Forms.TextBox p1pm_10;
        private System.Windows.Forms.TextBox p1vw_10;
        private System.Windows.Forms.TextBox p1plus_50;
        private System.Windows.Forms.TextBox p1r_50;
        private System.Windows.Forms.TextBox p1ls_50;
        private System.Windows.Forms.TextBox p1iws_50;
        private System.Windows.Forms.TextBox p1ib_50;
        private System.Windows.Forms.TextBox p1pm_50;
        private System.Windows.Forms.TextBox p1vw_50;
        private System.Windows.Forms.TextBox p1plus_16;
        private System.Windows.Forms.TextBox p1r_16;
        private System.Windows.Forms.TextBox p1ls_16;
        private System.Windows.Forms.TextBox p1iws_16;
        private System.Windows.Forms.TextBox p1ib_16;
        private System.Windows.Forms.TextBox p1pm_16;
        private System.Windows.Forms.TextBox p1vw_16;
        private System.Windows.Forms.TextBox p1plus_17;
        private System.Windows.Forms.TextBox p1r_17;
        private System.Windows.Forms.TextBox p1ls_17;
        private System.Windows.Forms.TextBox p1iws_17;
        private System.Windows.Forms.TextBox p1ib_17;
        private System.Windows.Forms.TextBox p1pm_17;
        private System.Windows.Forms.TextBox p1vw_17;
        private System.Windows.Forms.TextBox p1plus_26;
        private System.Windows.Forms.TextBox p1r_26;
        private System.Windows.Forms.TextBox p1ls_26;
        private System.Windows.Forms.TextBox p1iws_26;
        private System.Windows.Forms.TextBox p1ib_26;
        private System.Windows.Forms.TextBox p1pm_26;
        private System.Windows.Forms.TextBox p1vw_26;
        private System.Windows.Forms.TextBox p1plus_51;
        private System.Windows.Forms.TextBox p1r_51;
        private System.Windows.Forms.TextBox p1ls_51;
        private System.Windows.Forms.TextBox p1iws_51;
        private System.Windows.Forms.TextBox p1ib_51;
        private System.Windows.Forms.TextBox p1pm_51;
        private System.Windows.Forms.TextBox p1vw_51;
        private System.Windows.Forms.TextBox p1r_0;
        private System.Windows.Forms.TextBox p1ls_0;
        private System.Windows.Forms.TextBox p1iws_0;
        private System.Windows.Forms.TextBox p1ib_0;
        private System.Windows.Forms.TextBox p1pm_0;
        private System.Windows.Forms.TextBox p1vw_0;
        private System.Windows.Forms.Label label74;
        private System.Windows.Forms.Label label75;
        private System.Windows.Forms.Label label76;
        private System.Windows.Forms.Label label77;
        private System.Windows.Forms.Label label78;
        private System.Windows.Forms.Label label79;
        private System.Windows.Forms.Label label80;
        private System.Windows.Forms.Label label81;
        private System.Windows.Forms.Label label82;
        private System.Windows.Forms.Label label83;
        private System.Windows.Forms.Label label84;
        private System.Windows.Forms.Label label85;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label91;
        private System.Windows.Forms.Label label90;
        private System.Windows.Forms.Label label89;
        private System.Windows.Forms.Label label88;
        private System.Windows.Forms.Label label87;
        private System.Windows.Forms.Label label86;
        private System.Windows.Forms.TabPage tab_P2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label92;
        private System.Windows.Forms.Label label93;
        private System.Windows.Forms.Label label94;
        private System.Windows.Forms.Label label95;
        private System.Windows.Forms.Label label96;
        private System.Windows.Forms.Label label97;
        private System.Windows.Forms.Label label98;
        private System.Windows.Forms.Label label99;
        private System.Windows.Forms.Label label100;
        private System.Windows.Forms.Label label101;
        private System.Windows.Forms.Label label102;
        private System.Windows.Forms.Label label103;
        private System.Windows.Forms.Label label104;
        private System.Windows.Forms.Label label105;
        private System.Windows.Forms.Label label106;
        private System.Windows.Forms.Label label107;
        private System.Windows.Forms.Label label108;
        private System.Windows.Forms.Label label109;
        private System.Windows.Forms.Label label110;
        private System.Windows.Forms.Label label111;
        private System.Windows.Forms.Label label112;
        private System.Windows.Forms.Label label113;
        private System.Windows.Forms.Label label114;
        private System.Windows.Forms.Label label115;
        private System.Windows.Forms.Label label116;
        private System.Windows.Forms.Label label117;
        private System.Windows.Forms.Label label118;
        private System.Windows.Forms.Label label119;
        private System.Windows.Forms.Label label120;
        private System.Windows.Forms.Label label121;
        private System.Windows.Forms.Label label122;
        private System.Windows.Forms.Label label123;
        private System.Windows.Forms.Label label124;
        private System.Windows.Forms.Label label125;
        private System.Windows.Forms.Label label126;
        private System.Windows.Forms.Label label127;
        private System.Windows.Forms.Label label128;
        private System.Windows.Forms.Label label129;
        private System.Windows.Forms.Label label130;
        private System.Windows.Forms.Label label131;
        private System.Windows.Forms.Label label132;
        private System.Windows.Forms.Label label133;
        private System.Windows.Forms.Label label134;
        private System.Windows.Forms.Label label135;
        private System.Windows.Forms.Label label136;
        private System.Windows.Forms.Label label137;
        private System.Windows.Forms.Label label138;
        private System.Windows.Forms.Label label139;
        private System.Windows.Forms.Label label140;
        private System.Windows.Forms.Label label141;
        private System.Windows.Forms.Label label142;
        private System.Windows.Forms.Label label143;
        private System.Windows.Forms.Label label144;
        private System.Windows.Forms.Label label145;
        private System.Windows.Forms.Label label146;
        private System.Windows.Forms.Label label147;
        private System.Windows.Forms.Label label148;
        private System.Windows.Forms.Label label149;
        private System.Windows.Forms.Label label150;
        private System.Windows.Forms.Label label151;
        private System.Windows.Forms.Label label152;
        private System.Windows.Forms.Label label153;
        private System.Windows.Forms.Label label154;
        private System.Windows.Forms.Label label155;
        private System.Windows.Forms.Label label156;
        private System.Windows.Forms.Label label157;
        private System.Windows.Forms.Label label158;
        private System.Windows.Forms.Label label159;
        private System.Windows.Forms.Label label160;
        private System.Windows.Forms.Label label161;
        private System.Windows.Forms.Label label162;
        private System.Windows.Forms.Label label163;
        private System.Windows.Forms.Label label164;
        private System.Windows.Forms.Label label165;
        private System.Windows.Forms.Label label166;
        private System.Windows.Forms.Label label167;
        private System.Windows.Forms.Label label168;
        private System.Windows.Forms.Label label169;
        private System.Windows.Forms.Label label170;
        private System.Windows.Forms.Label label171;
        private System.Windows.Forms.Label label172;
        private System.Windows.Forms.Label label173;
        private System.Windows.Forms.Label label174;
        private System.Windows.Forms.Label label175;
        private System.Windows.Forms.Label label176;
        private System.Windows.Forms.Label label177;
        private System.Windows.Forms.Label label178;
        private System.Windows.Forms.Label label179;
        private System.Windows.Forms.Label label180;
        private System.Windows.Forms.TextBox p2plus_19;
        private System.Windows.Forms.TextBox p2r_19;
        private System.Windows.Forms.TextBox p2ls_19;
        private System.Windows.Forms.TextBox p2iws_19;
        private System.Windows.Forms.TextBox p2ib_19;
        private System.Windows.Forms.TextBox p2pm_19;
        private System.Windows.Forms.TextBox p2vw_19;
        private System.Windows.Forms.TextBox p2plus_8;
        private System.Windows.Forms.TextBox p2r_8;
        private System.Windows.Forms.TextBox p2ls_8;
        private System.Windows.Forms.TextBox p2iws_8;
        private System.Windows.Forms.TextBox p2ib_8;
        private System.Windows.Forms.TextBox p2pm_8;
        private System.Windows.Forms.TextBox p2vw_8;
        private System.Windows.Forms.TextBox p2plus_14;
        private System.Windows.Forms.TextBox p2r_14;
        private System.Windows.Forms.TextBox p2ls_14;
        private System.Windows.Forms.TextBox p2iws_14;
        private System.Windows.Forms.TextBox p2ib_14;
        private System.Windows.Forms.TextBox p2pm_14;
        private System.Windows.Forms.TextBox p2vw_14;
        private System.Windows.Forms.TextBox p2plus_54;
        private System.Windows.Forms.TextBox p2r_54;
        private System.Windows.Forms.TextBox p2ls_54;
        private System.Windows.Forms.TextBox p2iws_54;
        private System.Windows.Forms.TextBox p2ib_54;
        private System.Windows.Forms.TextBox p2pm_54;
        private System.Windows.Forms.TextBox p2vw_54;
        private System.Windows.Forms.TextBox p2plus_5;
        private System.Windows.Forms.TextBox p2r_5;
        private System.Windows.Forms.TextBox p2ls_5;
        private System.Windows.Forms.TextBox p2iws_5;
        private System.Windows.Forms.TextBox p2ib_5;
        private System.Windows.Forms.TextBox p2pm_5;
        private System.Windows.Forms.TextBox p2vw_5;
        private System.Windows.Forms.TextBox p2plus_11;
        private System.Windows.Forms.TextBox p2r_11;
        private System.Windows.Forms.TextBox p2ls_11;
        private System.Windows.Forms.TextBox p2iws_11;
        private System.Windows.Forms.TextBox p2ib_11;
        private System.Windows.Forms.TextBox p2pm_11;
        private System.Windows.Forms.TextBox p2vw_11;
        private System.Windows.Forms.TextBox p2plus_55;
        private System.Windows.Forms.TextBox p2r_55;
        private System.Windows.Forms.TextBox p2ls_55;
        private System.Windows.Forms.TextBox p2iws_55;
        private System.Windows.Forms.TextBox p2ib_55;
        private System.Windows.Forms.TextBox p2pm_55;
        private System.Windows.Forms.TextBox p2vw_55;
        private System.Windows.Forms.TextBox p2plus_16;
        private System.Windows.Forms.TextBox p2r_16;
        private System.Windows.Forms.TextBox p2ls_16;
        private System.Windows.Forms.TextBox p2iws_16;
        private System.Windows.Forms.TextBox p2ib_16;
        private System.Windows.Forms.TextBox p2pm_16;
        private System.Windows.Forms.TextBox p2vw_16;
        private System.Windows.Forms.TextBox p2plus_17;
        private System.Windows.Forms.TextBox p2r_17;
        private System.Windows.Forms.TextBox p2ls_17;
        private System.Windows.Forms.TextBox p2iws_17;
        private System.Windows.Forms.TextBox p2ib_17;
        private System.Windows.Forms.TextBox p2pm_17;
        private System.Windows.Forms.TextBox p2vw_17;
        private System.Windows.Forms.TextBox p2plus_26;
        private System.Windows.Forms.TextBox p2r_26;
        private System.Windows.Forms.TextBox p2ls_26;
        private System.Windows.Forms.TextBox p2iws_26;
        private System.Windows.Forms.TextBox p2ib_26;
        private System.Windows.Forms.TextBox p2pm_26;
        private System.Windows.Forms.TextBox p2vw_26;
        private System.Windows.Forms.TextBox p2plus_56;
        private System.Windows.Forms.TextBox p2r_56;
        private System.Windows.Forms.TextBox p2ls_56;
        private System.Windows.Forms.TextBox p2iws_56;
        private System.Windows.Forms.TextBox p2ib_56;
        private System.Windows.Forms.TextBox p2pm_56;
        private System.Windows.Forms.TextBox p2vw_56;
        private System.Windows.Forms.TextBox p2r_0;
        private System.Windows.Forms.TextBox p2ls_0;
        private System.Windows.Forms.TextBox p2iws_0;
        private System.Windows.Forms.TextBox p2ib_0;
        private System.Windows.Forms.TextBox p2pm_0;
        private System.Windows.Forms.TextBox p2vw_0;
        private System.Windows.Forms.TabPage tab_P3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label181;
        private System.Windows.Forms.Label label182;
        private System.Windows.Forms.Label label183;
        private System.Windows.Forms.Label label184;
        private System.Windows.Forms.Label label185;
        private System.Windows.Forms.Label label186;
        private System.Windows.Forms.Label label187;
        private System.Windows.Forms.Label label188;
        private System.Windows.Forms.Label label189;
        private System.Windows.Forms.Label label190;
        private System.Windows.Forms.Label label191;
        private System.Windows.Forms.Label label192;
        private System.Windows.Forms.Label label193;
        private System.Windows.Forms.Label label194;
        private System.Windows.Forms.Label label195;
        private System.Windows.Forms.Label label196;
        private System.Windows.Forms.Label label197;
        private System.Windows.Forms.Label label198;
        private System.Windows.Forms.Label label199;
        private System.Windows.Forms.Label label200;
        private System.Windows.Forms.Label label201;
        private System.Windows.Forms.Label label202;
        private System.Windows.Forms.Label label203;
        private System.Windows.Forms.Label label204;
        private System.Windows.Forms.Label label205;
        private System.Windows.Forms.Label label206;
        private System.Windows.Forms.Label label207;
        private System.Windows.Forms.Label label208;
        private System.Windows.Forms.Label label209;
        private System.Windows.Forms.Label label210;
        private System.Windows.Forms.Label label211;
        private System.Windows.Forms.Label label212;
        private System.Windows.Forms.Label label213;
        private System.Windows.Forms.Label label214;
        private System.Windows.Forms.Label label215;
        private System.Windows.Forms.Label label216;
        private System.Windows.Forms.Label label217;
        private System.Windows.Forms.Label label218;
        private System.Windows.Forms.Label label219;
        private System.Windows.Forms.Label label220;
        private System.Windows.Forms.Label label221;
        private System.Windows.Forms.Label label222;
        private System.Windows.Forms.Label label223;
        private System.Windows.Forms.Label label224;
        private System.Windows.Forms.Label label225;
        private System.Windows.Forms.Label label226;
        private System.Windows.Forms.Label label227;
        private System.Windows.Forms.Label label228;
        private System.Windows.Forms.Label label229;
        private System.Windows.Forms.Label label230;
        private System.Windows.Forms.Label label231;
        private System.Windows.Forms.Label label232;
        private System.Windows.Forms.Label label233;
        private System.Windows.Forms.Label label234;
        private System.Windows.Forms.Label label235;
        private System.Windows.Forms.Label label236;
        private System.Windows.Forms.Label label237;
        private System.Windows.Forms.Label label238;
        private System.Windows.Forms.Label label239;
        private System.Windows.Forms.Label label240;
        private System.Windows.Forms.Label label241;
        private System.Windows.Forms.Label label242;
        private System.Windows.Forms.Label label243;
        private System.Windows.Forms.Label label244;
        private System.Windows.Forms.Label label245;
        private System.Windows.Forms.Label label246;
        private System.Windows.Forms.Label label247;
        private System.Windows.Forms.Label label248;
        private System.Windows.Forms.Label label249;
        private System.Windows.Forms.Label label250;
        private System.Windows.Forms.Label label251;
        private System.Windows.Forms.Label label252;
        private System.Windows.Forms.Label label253;
        private System.Windows.Forms.Label label254;
        private System.Windows.Forms.Label label255;
        private System.Windows.Forms.Label label256;
        private System.Windows.Forms.Label label257;
        private System.Windows.Forms.Label label258;
        private System.Windows.Forms.Label label259;
        private System.Windows.Forms.Label label260;
        private System.Windows.Forms.Label label261;
        private System.Windows.Forms.Label label262;
        private System.Windows.Forms.Label label263;
        private System.Windows.Forms.Label label264;
        private System.Windows.Forms.Label label265;
        private System.Windows.Forms.Label label266;
        private System.Windows.Forms.Label label267;
        private System.Windows.Forms.Label label268;
        private System.Windows.Forms.Label label269;
        private System.Windows.Forms.TextBox p3plus_20;
        private System.Windows.Forms.TextBox p3r_20;
        private System.Windows.Forms.TextBox p3ls_20;
        private System.Windows.Forms.TextBox p3iws_20;
        private System.Windows.Forms.TextBox p3ib_20;
        private System.Windows.Forms.TextBox p3pm_20;
        private System.Windows.Forms.TextBox p3vw_20;
        private System.Windows.Forms.TextBox p3plus_9;
        private System.Windows.Forms.TextBox p3r_9;
        private System.Windows.Forms.TextBox p3ls_9;
        private System.Windows.Forms.TextBox p3iws_9;
        private System.Windows.Forms.TextBox p3ib_9;
        private System.Windows.Forms.TextBox p3pm_9;
        private System.Windows.Forms.TextBox p3vw_9;
        private System.Windows.Forms.TextBox p3plus_15;
        private System.Windows.Forms.TextBox p3r_15;
        private System.Windows.Forms.TextBox p3ls_15;
        private System.Windows.Forms.TextBox p3iws_15;
        private System.Windows.Forms.TextBox p3ib_15;
        private System.Windows.Forms.TextBox p3pm_15;
        private System.Windows.Forms.TextBox p3vw_15;
        private System.Windows.Forms.TextBox p3plus_29;
        private System.Windows.Forms.TextBox p3r_29;
        private System.Windows.Forms.TextBox p3ls_29;
        private System.Windows.Forms.TextBox p3iws_29;
        private System.Windows.Forms.TextBox p3ib_29;
        private System.Windows.Forms.TextBox p3pm_29;
        private System.Windows.Forms.TextBox p3vw_29;
        private System.Windows.Forms.TextBox p3plus_6;
        private System.Windows.Forms.TextBox p3r_6;
        private System.Windows.Forms.TextBox p3ls_6;
        private System.Windows.Forms.TextBox p3iws_6;
        private System.Windows.Forms.TextBox p3ib_6;
        private System.Windows.Forms.TextBox p3pm_6;
        private System.Windows.Forms.TextBox p3vw_6;
        private System.Windows.Forms.TextBox p3plus_12;
        private System.Windows.Forms.TextBox p3r_12;
        private System.Windows.Forms.TextBox p3ls_12;
        private System.Windows.Forms.TextBox p3iws_12;
        private System.Windows.Forms.TextBox p3ib_12;
        private System.Windows.Forms.TextBox p3pm_12;
        private System.Windows.Forms.TextBox p3vw_12;
        private System.Windows.Forms.TextBox p3plus_30;
        private System.Windows.Forms.TextBox p3r_30;
        private System.Windows.Forms.TextBox p3ls_30;
        private System.Windows.Forms.TextBox p3iws_30;
        private System.Windows.Forms.TextBox p3ib_30;
        private System.Windows.Forms.TextBox p3pm_30;
        private System.Windows.Forms.TextBox p3vw_30;
        private System.Windows.Forms.TextBox p3plus_16;
        private System.Windows.Forms.TextBox p3r_16;
        private System.Windows.Forms.TextBox p3ls_16;
        private System.Windows.Forms.TextBox p3iws_16;
        private System.Windows.Forms.TextBox p3ib_16;
        private System.Windows.Forms.TextBox p3pm_16;
        private System.Windows.Forms.TextBox p3vw_16;
        private System.Windows.Forms.TextBox p3plus_17;
        private System.Windows.Forms.TextBox p3r_17;
        private System.Windows.Forms.TextBox p3ls_17;
        private System.Windows.Forms.TextBox p3iws_17;
        private System.Windows.Forms.TextBox p3ib_17;
        private System.Windows.Forms.TextBox p3pm_17;
        private System.Windows.Forms.TextBox p3vw_17;
        private System.Windows.Forms.TextBox p3plus_26;
        private System.Windows.Forms.TextBox p3r_26;
        private System.Windows.Forms.TextBox p3ls_26;
        private System.Windows.Forms.TextBox p3iws_26;
        private System.Windows.Forms.TextBox p3ib_26;
        private System.Windows.Forms.TextBox p3pm_26;
        private System.Windows.Forms.TextBox p3vw_26;
        private System.Windows.Forms.TextBox p3plus_31;
        private System.Windows.Forms.TextBox p3r_31;
        private System.Windows.Forms.TextBox p3ls_31;
        private System.Windows.Forms.TextBox p3iws_31;
        private System.Windows.Forms.TextBox p3ib_31;
        private System.Windows.Forms.TextBox p3pm_31;
        private System.Windows.Forms.TextBox p3vw_31;
        private System.Windows.Forms.TextBox p3r_0;
        private System.Windows.Forms.TextBox p3ls_0;
        private System.Windows.Forms.TextBox p3iws_0;
        private System.Windows.Forms.TextBox p3ib_0;
        private System.Windows.Forms.TextBox p3pm_0;
        private System.Windows.Forms.TextBox p3vw_0;
        private System.Windows.Forms.PictureBox p1ETAusfueren;
        private System.Windows.Forms.PictureBox p2ETAusfueren;
        private System.Windows.Forms.PictureBox p3ETAusfueren;
        private System.Windows.Forms.TabPage tab_arbeitzeit;
        private System.Windows.Forms.DataGridView DataGridViewAP;
        private System.Windows.Forms.DataGridView dataGridViewBestellung;
        private System.Windows.Forms.PictureBox saveAenderungen;
        private System.Windows.Forms.PictureBox zurueck;
        private System.Windows.Forms.PictureBox uebernehmenXML;
        private System.Windows.Forms.TabPage xmlOutput;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panelXMLerstellen;
        private System.Windows.Forms.DataGridView dataGridViewProduktKapazit;
        private System.Windows.Forms.Label label274;
        private System.Windows.Forms.DataGridView dataGridViewEinkauf;
        private System.Windows.Forms.Label label272;
        private System.Windows.Forms.DataGridView dataGridViewDirekt;
        private System.Windows.Forms.Label label271;
        private System.Windows.Forms.DataGridView dataGridViewVertrieb;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_p1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_p2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dg_p3;
        private System.Windows.Forms.Label label270;
        private System.Windows.Forms.PictureBox arbPlatzAusfueren;
        private System.Windows.Forms.PictureBox addNr;
        private System.Windows.Forms.PictureBox xml_export;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewLinkColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewLinkColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewImageColumn minus;
        private System.Windows.Forms.DataGridViewImageColumn plus;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn s1;
        private System.Windows.Forms.DataGridViewCheckBoxColumn s3;
        private System.Windows.Forms.DataGridViewImageColumn ueber;
        private System.Windows.Forms.ImageList imageListPlusMinus;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.PictureBox addNr2;
        private System.Windows.Forms.PictureBox zurueck2;
        private System.Windows.Forms.PictureBox saveAenderungen2;
        private System.Windows.Forms.Label label275;
        private System.Windows.Forms.DataGridView dataGridViewDirektverkauf;
        private System.Windows.Forms.DataGridViewTextBoxColumn kNr;
        private System.Windows.Forms.DataGridViewTextBoxColumn menge;
        private System.Windows.Forms.DataGridViewCheckBoxColumn eil;
        private System.Windows.Forms.DataGridViewCheckBoxColumn del;
        private System.Windows.Forms.CheckBox dvVerwenden;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewImageColumn dataGridViewImageColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colWarteschlange;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBearbeitung;
        private System.Windows.Forms.DataGridViewTextBoxColumn colPlanung;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.DataGridView dataGridViewProduktAuftrag;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.DataGridView dataGridViewPrAuftraege;
        private System.Windows.Forms.Label lb12;
        private System.Windows.Forms.Label info;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripMenuItem videoF2ToolStripMenuItem;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn knr2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        private System.Windows.Forms.DataGridViewTextBoxColumn pr;
        private System.Windows.Forms.DataGridViewTextBoxColumn str;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn straf;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn ueberStunden;
        private System.Windows.Forms.TabPage Spache;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_abweichung;
        private System.Windows.Forms.Label LabelAbweichung;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label lbl_info;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lbl_100;
        private System.Windows.Forms.Label lbl_50;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Label lbl_10;
        private System.Windows.Forms.TrackBar trackBarAbweichung;
        private System.Windows.Forms.TabPage tab_diskount;
        private System.Windows.Forms.Label LabelDiskont;
        private System.Windows.Forms.Label label273;
        private System.Windows.Forms.NumericUpDown mengeGrenze;
        private System.Windows.Forms.NumericUpDown diskGrenze;
        private System.Windows.Forms.Label label276;
        private System.Windows.Forms.Label label277;
        private System.Windows.Forms.Label label278;
        private System.Windows.Forms.Label label279;
        private System.Windows.Forms.Label label280;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label281;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Button diskSpeichern;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.TabPage tab_schicht;
        private System.Windows.Forms.Label LabelSchichten;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Label label282;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Button btn_schicht_save;
        private System.Windows.Forms.Label lbl_3schicht;
        private System.Windows.Forms.Label lbl_2schicht;
        private System.Windows.Forms.TabPage Sprache;
        private System.Windows.Forms.ToolStripMenuItem englischToolStripMenuItem1;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.Button button3;
    }
}

