﻿namespace ToolFahrrad_v1.Windows
{
    partial class Einstellungen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Einstellungen));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tab_abweichung = new System.Windows.Forms.TabPage();
            this.LabelAbweichung = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lbl_info = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_100 = new System.Windows.Forms.Label();
            this.lbl_50 = new System.Windows.Forms.Label();
            this.btn_ok = new System.Windows.Forms.Button();
            this.lbl_10 = new System.Windows.Forms.Label();
            this.trackBarAbweichung = new System.Windows.Forms.TrackBar();
            this.tab_diskount = new System.Windows.Forms.TabPage();
            this.LabelDiskont = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.mengeGrenze = new System.Windows.Forms.NumericUpDown();
            this.diskGrenze = new System.Windows.Forms.NumericUpDown();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.diskSpeichern = new System.Windows.Forms.Button();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.tab_schicht = new System.Windows.Forms.TabPage();
            this.LabelSchichten = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.numericUpDown2 = new System.Windows.Forms.NumericUpDown();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.btn_schicht_save = new System.Windows.Forms.Button();
            this.lbl_3schicht = new System.Windows.Forms.Label();
            this.lbl_2schicht = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tab_abweichung.SuspendLayout();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAbweichung)).BeginInit();
            this.tab_diskount.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mengeGrenze)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diskGrenze)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.tab_schicht.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            resources.ApplyResources(this.tabControl1, "tabControl1");
            this.tabControl1.Controls.Add(this.tab_abweichung);
            this.tabControl1.Controls.Add(this.tab_diskount);
            this.tabControl1.Controls.Add(this.tab_schicht);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            // 
            // tab_abweichung
            // 
            resources.ApplyResources(this.tab_abweichung, "tab_abweichung");
            this.tab_abweichung.BackColor = System.Drawing.Color.Transparent;
            this.tab_abweichung.Controls.Add(this.LabelAbweichung);
            this.tab_abweichung.Controls.Add(this.panel1);
            this.tab_abweichung.Controls.Add(this.lbl_100);
            this.tab_abweichung.Controls.Add(this.lbl_50);
            this.tab_abweichung.Controls.Add(this.btn_ok);
            this.tab_abweichung.Controls.Add(this.lbl_10);
            this.tab_abweichung.Controls.Add(this.trackBarAbweichung);
            this.tab_abweichung.Name = "tab_abweichung";
            this.tab_abweichung.Click += new System.EventHandler(this.tab_abweichung_Click);
            // 
            // LabelAbweichung
            // 
            resources.ApplyResources(this.LabelAbweichung, "LabelAbweichung");
            this.LabelAbweichung.Name = "LabelAbweichung";
            // 
            // panel1
            // 
            resources.ApplyResources(this.panel1, "panel1");
            this.panel1.Controls.Add(this.lbl_info);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Name = "panel1";
            // 
            // lbl_info
            // 
            resources.ApplyResources(this.lbl_info, "lbl_info");
            this.lbl_info.Name = "lbl_info";
            // 
            // pictureBox1
            // 
            resources.ApplyResources(this.pictureBox1, "pictureBox1");
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.TabStop = false;
            // 
            // lbl_100
            // 
            resources.ApplyResources(this.lbl_100, "lbl_100");
            this.lbl_100.BackColor = System.Drawing.Color.Transparent;
            this.lbl_100.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_100.Name = "lbl_100";
            // 
            // lbl_50
            // 
            resources.ApplyResources(this.lbl_50, "lbl_50");
            this.lbl_50.BackColor = System.Drawing.Color.Transparent;
            this.lbl_50.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_50.Name = "lbl_50";
            // 
            // btn_ok
            // 
            resources.ApplyResources(this.btn_ok, "btn_ok");
            this.btn_ok.Name = "btn_ok";
            this.btn_ok.UseVisualStyleBackColor = true;
            this.btn_ok.Click += new System.EventHandler(this.btn_ok_Click);
            // 
            // lbl_10
            // 
            resources.ApplyResources(this.lbl_10, "lbl_10");
            this.lbl_10.BackColor = System.Drawing.Color.Transparent;
            this.lbl_10.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.lbl_10.Name = "lbl_10";
            // 
            // trackBarAbweichung
            // 
            resources.ApplyResources(this.trackBarAbweichung, "trackBarAbweichung");
            this.trackBarAbweichung.BackColor = System.Drawing.SystemColors.Control;
            this.trackBarAbweichung.Name = "trackBarAbweichung";
            this.trackBarAbweichung.Value = 5;
            this.trackBarAbweichung.Scroll += new System.EventHandler(this.trackBarAbweichung_Scroll);
            // 
            // tab_diskount
            // 
            resources.ApplyResources(this.tab_diskount, "tab_diskount");
            this.tab_diskount.BackColor = System.Drawing.Color.Transparent;
            this.tab_diskount.Controls.Add(this.LabelDiskont);
            this.tab_diskount.Controls.Add(this.label8);
            this.tab_diskount.Controls.Add(this.mengeGrenze);
            this.tab_diskount.Controls.Add(this.diskGrenze);
            this.tab_diskount.Controls.Add(this.label7);
            this.tab_diskount.Controls.Add(this.label6);
            this.tab_diskount.Controls.Add(this.label3);
            this.tab_diskount.Controls.Add(this.label4);
            this.tab_diskount.Controls.Add(this.label5);
            this.tab_diskount.Controls.Add(this.panel3);
            this.tab_diskount.Controls.Add(this.diskSpeichern);
            this.tab_diskount.Controls.Add(this.trackBar1);
            this.tab_diskount.Name = "tab_diskount";
            // 
            // LabelDiskont
            // 
            resources.ApplyResources(this.LabelDiskont, "LabelDiskont");
            this.LabelDiskont.Name = "LabelDiskont";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // mengeGrenze
            // 
            resources.ApplyResources(this.mengeGrenze, "mengeGrenze");
            this.mengeGrenze.Minimum = new decimal(new int[] {
            2,
            0,
            0,
            0});
            this.mengeGrenze.Name = "mengeGrenze";
            this.mengeGrenze.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            this.mengeGrenze.ValueChanged += new System.EventHandler(this.mengeGrenze_ValueChanged);
            // 
            // diskGrenze
            // 
            resources.ApplyResources(this.diskGrenze, "diskGrenze");
            this.diskGrenze.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.diskGrenze.Name = "diskGrenze";
            this.diskGrenze.Value = new decimal(new int[] {
            5,
            0,
            0,
            0});
            this.diskGrenze.ValueChanged += new System.EventHandler(this.diskGrenze_ValueChanged);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.ControlDark;
            this.label5.Name = "label5";
            // 
            // panel3
            // 
            resources.ApplyResources(this.panel3, "panel3");
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.pictureBox3);
            this.panel3.Name = "panel3";
            // 
            // label2
            // 
            resources.ApplyResources(this.label2, "label2");
            this.label2.Name = "label2";
            // 
            // pictureBox3
            // 
            resources.ApplyResources(this.pictureBox3, "pictureBox3");
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.TabStop = false;
            // 
            // diskSpeichern
            // 
            resources.ApplyResources(this.diskSpeichern, "diskSpeichern");
            this.diskSpeichern.Name = "diskSpeichern";
            this.diskSpeichern.UseVisualStyleBackColor = true;
            this.diskSpeichern.Click += new System.EventHandler(this.diskSpeichern_Click);
            // 
            // trackBar1
            // 
            resources.ApplyResources(this.trackBar1, "trackBar1");
            this.trackBar1.BackColor = System.Drawing.SystemColors.Control;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Value = 5;
            this.trackBar1.Scroll += new System.EventHandler(this.trackBar1_Scroll);
            // 
            // tab_schicht
            // 
            resources.ApplyResources(this.tab_schicht, "tab_schicht");
            this.tab_schicht.BackColor = System.Drawing.Color.Transparent;
            this.tab_schicht.Controls.Add(this.LabelSchichten);
            this.tab_schicht.Controls.Add(this.panel2);
            this.tab_schicht.Controls.Add(this.numericUpDown2);
            this.tab_schicht.Controls.Add(this.numericUpDown1);
            this.tab_schicht.Controls.Add(this.btn_schicht_save);
            this.tab_schicht.Controls.Add(this.lbl_3schicht);
            this.tab_schicht.Controls.Add(this.lbl_2schicht);
            this.tab_schicht.Name = "tab_schicht";
            // 
            // LabelSchichten
            // 
            resources.ApplyResources(this.LabelSchichten, "LabelSchichten");
            this.LabelSchichten.Name = "LabelSchichten";
            // 
            // panel2
            // 
            resources.ApplyResources(this.panel2, "panel2");
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.pictureBox2);
            this.panel2.Name = "panel2";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // pictureBox2
            // 
            resources.ApplyResources(this.pictureBox2, "pictureBox2");
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.TabStop = false;
            // 
            // numericUpDown2
            // 
            resources.ApplyResources(this.numericUpDown2, "numericUpDown2");
            this.numericUpDown2.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown2.Maximum = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.numericUpDown2.Minimum = new decimal(new int[] {
            4800,
            0,
            0,
            0});
            this.numericUpDown2.Name = "numericUpDown2";
            this.numericUpDown2.TabStop = false;
            this.numericUpDown2.Value = new decimal(new int[] {
            6000,
            0,
            0,
            0});
            this.numericUpDown2.ValueChanged += new System.EventHandler(this.numericUpDown2_ValueChanged);
            // 
            // numericUpDown1
            // 
            resources.ApplyResources(this.numericUpDown1, "numericUpDown1");
            this.numericUpDown1.Increment = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDown1.Maximum = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            this.numericUpDown1.Minimum = new decimal(new int[] {
            2400,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.TabStop = false;
            this.numericUpDown1.Value = new decimal(new int[] {
            3600,
            0,
            0,
            0});
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // btn_schicht_save
            // 
            resources.ApplyResources(this.btn_schicht_save, "btn_schicht_save");
            this.btn_schicht_save.Name = "btn_schicht_save";
            this.btn_schicht_save.UseVisualStyleBackColor = true;
            this.btn_schicht_save.Click += new System.EventHandler(this.btn_schicht_save_Click);
            // 
            // lbl_3schicht
            // 
            resources.ApplyResources(this.lbl_3schicht, "lbl_3schicht");
            this.lbl_3schicht.Name = "lbl_3schicht";
            // 
            // lbl_2schicht
            // 
            resources.ApplyResources(this.lbl_2schicht, "lbl_2schicht");
            this.lbl_2schicht.Name = "lbl_2schicht";
            // 
            // Einstellungen
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.tabControl1);
            this.Name = "Einstellungen";
            this.tabControl1.ResumeLayout(false);
            this.tab_abweichung.ResumeLayout(false);
            this.tab_abweichung.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAbweichung)).EndInit();
            this.tab_diskount.ResumeLayout(false);
            this.tab_diskount.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mengeGrenze)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diskGrenze)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.tab_schicht.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_abweichung;
        private System.Windows.Forms.Label lbl_10;
        private System.Windows.Forms.TrackBar trackBarAbweichung;
        private System.Windows.Forms.TabPage tab_schicht;
        private System.Windows.Forms.Button btn_ok;
        private System.Windows.Forms.Label lbl_50;
        private System.Windows.Forms.Label lbl_100;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lbl_info;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_2schicht;
        private System.Windows.Forms.Label lbl_3schicht;
        private System.Windows.Forms.Button btn_schicht_save;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.NumericUpDown numericUpDown2;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TabPage tab_diskount;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button diskSpeichern;
        private System.Windows.Forms.TrackBar trackBar1;
        private System.Windows.Forms.NumericUpDown mengeGrenze;
        private System.Windows.Forms.NumericUpDown diskGrenze;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label LabelAbweichung;
        private System.Windows.Forms.Label LabelDiskont;
        private System.Windows.Forms.Label LabelSchichten;
    }
}